'use strict';

/* ========== 状態 ========== */
let data = null;          // 読み込んだJSON全体（保存時はこれをそのまま書き出す）
let fileHandle = null;    // File System Access API のハンドル
let fileName = '';
let dirty = false;
let lastDiskText = '';    // 開いた／前回保存した時点のディスク上の内容（外部変更検知用）

// Local double-click mode opens through file input; direct-save support is detected independently.
const supportsFS = ['http:', 'https:'].includes(window.location?.protocol) && 'showOpenFilePicker' in window;
let saving = false;
let pendingDownload = null;
let activeDataToken = 0;
const FILE_TYPES = [{ description: 'JSONファイル', accept: { 'application/json': ['.json'] } }];

// 系列色。色だけに頼らず、パターンと数値のデータ表を併用する。
const PALETTE = ['#2458a6', '#16715c', '#985900', '#7653a3', '#a33d63', '#56772b', '#08788d', '#994922'];
const AVG_COLOR = '#9aa4b0';
const CHART_TEXT = '#536276';
const CHART_AXIS = '#e8eaf0';
// 全チャート共通のテキスト/フォント設定
const CHART_TEXT_STYLE = { fontFamily: "-apple-system, BlinkMacSystemFont, 'Hiragino Sans', 'Yu Gothic UI', 'Yu Gothic', sans-serif", color: CHART_TEXT };

// 画面の選択状態
const ui = {
  tab: 'overview',
  ovClass: 'all', ovTest: '', ovSubject: 'all',
  inClass: 'all', inTest: '', inSubject: 'all',
  anClass: 'all', anTest: '', anSubject: 'all', anAxis: 'domain',
  trendClass: 'all', trendSearch: '', trendSubject: '', trendKind: 'all',
  trendSelected: new Set(),
  trendCompareTest: '', trendCompareFrom: null, trendComparisonStarted: false,
  metClass: 'all', metricId: '',
  corrX: '', corrY: '',
  listSubject: 'all', listClass: 'all', listMode: 'total', listHeat: true, listPivot: 60, listSort: null,
  listGrade: 'all', listTerm: 'all',
  rtiSubject: 'all', rtiClass: 'all', rtiKind: 'all', rtiBasis: 'latest', rtiSelectedIv: null,
};

let isAdmin = false; // 管理者モード（誤操作防止。本来の保護は共有フォルダの権限で行う）

const SUM_KEY = '__sum__'; // 個人推移の「5教科合計」モード
const TEST_KINDS = { unclassified: '未分類', unit: '単元テスト', midterm: '中間テスト', final: '期末テスト', proficiency: '実力テスト', other: 'その他' };

let scoreIndex = new Map(); // `${studentId}:${testId}` -> score record

/* ========== ユーティリティ ========== */
const $ = (id) => document.getElementById(id);

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function round1(x) {
  return Math.round(x * 10) / 10;
}

function mean(arr) {
  return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;
}

function median(arr) {
  if (!arr.length) return null;
  const s = [...arr].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

function localDateString(date = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}`;
}

function normalizeDateValue(value) {
  if (value == null || value === '') return '';
  if (typeof value === 'number' && typeof XLSX !== 'undefined' && XLSX.SSF) {
    if (!Number.isFinite(value)) return null;
    const d = XLSX.SSF.parse_date_code(value);
    if (!d) return null;
    // Excel's serial 0 and fictitious 1900-02-29 still need the calendar check below.
    value = `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
  }
  const match = String(value).trim().match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})$/);
  if (!match) return null;
  const [, y, m, d] = match;
  const date = new Date(Number(y), Number(m) - 1, Number(d));
  if (date.getFullYear() !== Number(y) || date.getMonth() !== Number(m) - 1 || date.getDate() !== Number(d)) return null;
  return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`;
}

function parseBoundedNumber(raw, max, min = 0) {
  if (String(raw).trim() === '') return { valid: true, value: null };
  const value = Number(raw);
  return {
    valid: Number.isFinite(value) && value >= min && value <= max,
    value,
  };
}

function validMetricValue(type, value) {
  return Number.isFinite(value) && (type !== 'scale' || (Number.isInteger(value) && value >= 1 && value <= 5));
}

/* ---- 効果量（Cohen's d）の共通ヘルパー ---- */
function esFmt(d) {
  return `${d >= 0 ? '+' : ''}${(Math.round(d * 100) / 100).toFixed(2)}`;
}

function esLabel(d) {
  const a = Math.abs(d);
  return a < 0.2 ? 'ごく小さい' : a < 0.5 ? '小' : a < 0.8 ? '中' : '大';
}

function sdOf(arr, m) {
  return Math.sqrt(mean(arr.map((v) => (v - m) ** 2)));
}

function sampleSd(arr, m = mean(arr)) {
  if (arr.length < 2 || m == null) return null;
  return Math.sqrt(arr.reduce((sum, v) => sum + (v - m) ** 2, 0) / (arr.length - 1));
}

// 独立した2群の Cohen's d（プールした標本標準偏差を使用）
function independentCohensD(a, b) {
  if (a.length < 2 || b.length < 2) return null;
  const ma = mean(a), mb = mean(b);
  const sda = sampleSd(a, ma), sdb = sampleSd(b, mb);
  const pooled = Math.sqrt(
    ((a.length - 1) * sda ** 2 + (b.length - 1) * sdb ** 2) /
    (a.length + b.length - 2)
  );
  return pooled > 0 ? (mb - ma) / pooled : null;
}

// 同じ生徒の前後比較に使う Cohen's dz（差分の標本標準偏差を使用）
function pairedCohensDz(pairs) {
  if (pairs.length < 2) return null;
  const diffs = pairs.map(([before, after]) => after - before);
  const md = mean(diffs);
  const sd = sampleSd(diffs, md);
  return sd > 0 ? md / sd : null;
}

function quantile(sorted, p) {
  const pos = (sorted.length - 1) * p;
  const lo = Math.floor(pos);
  const hi = Math.ceil(pos);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (pos - lo);
}

/* ========== データアクセス ========== */
function rebuildIndex() {
  scoreIndex = new Map();
  for (const s of data.scores) scoreIndex.set(`${s.studentId}:${s.testId}`, s);
}

function getScore(sid, tid) {
  return scoreIndex.get(`${sid}:${tid}`) || null;
}

// 集計・グラフでは欠席者の復元用得点を使わない。入力は getScore で元の値を保持する。
function getAttendedScore(sid, tid) {
  const rec = getScore(sid, tid);
  if (!rec || rec.absent) return null;
  const test = testById(tid);
  // 旧JSONの部分合計も統計には使わない。設問明細のない旧集計値はそのまま扱う。
  if ((test?.questions || []).some(q => Object.hasOwn(rec.questions || {}, q.key))) {
    const state = questionScoreState(rec, test);
    return { ...rec, total: state.total, domains: state.domains };
  }
  return rec;
}

function ensureScore(sid, tid) {
  let rec = getScore(sid, tid);
  if (!rec) {
    rec = { studentId: sid, testId: tid, total: null, domains: {}, questions: {} };
    data.scores.push(rec);
    scoreIndex.set(`${sid}:${tid}`, rec);
  }
  if (!rec.domains) rec.domains = {};
  if (!rec.questions) rec.questions = {};
  return rec;
}

// 出席番号（並び順）。number があればそれを、なければ id を流用
function studentNumber(s) {
  const n = s.number != null && s.number !== '' ? s.number : s.id;
  return parseInt(n, 10) || 0;
}

function sortedStudents() {
  return [...data.students].sort((a, b) => {
    const c = (a.className || '').localeCompare(b.className || '', 'ja');
    if (c !== 0) return c;
    return studentNumber(a) - studentNumber(b);
  });
}

function classList() {
  return [...new Set(data.students.map((s) => s.className).filter(Boolean))].sort();
}

function studentsOf(klass) {
  const all = sortedStudents();
  return klass === 'all' ? all : all.filter((s) => s.className === klass);
}

function testById(tid) {
  return data.tests.find((t) => t.id === tid) || null;
}

/* ---- テスト回（実施学年＋テスト名）の扱い ----
   同じ「前期中間テスト」でも1年時と3年時は別の回。テストの gradeYear
   （何年生のときのテストか）を含めた「回キー」でグループ化・並び替えする */
function termKeyOf(t) {
  return (t.gradeYear ? `${t.gradeYear}年・` : '') + t.name;
}

// 回の一覧を時間順（実施学年→登録順）で返す
function termOrderedList(tests = data.tests) {
  const seen = new Map();
  tests.forEach((t, i) => {
    const k = termKeyOf(t);
    if (!seen.has(k)) {
      seen.set(k, { key: k, gy: t.gradeYear || 0, date: t.date || '', idx: i });
    } else if (t.date) {
      const current = seen.get(k);
      if (!current.date || t.date < current.date) current.date = t.date;
    }
  });
  return [...seen.values()].sort((a, b) => {
    const gradeOrder = (a.gy || 99) - (b.gy || 99);
    if (gradeOrder) return gradeOrder;
    if (a.date && b.date && a.date !== b.date) return a.date.localeCompare(b.date);
    if (a.date !== b.date) return a.date ? -1 : 1;
    return a.idx - b.idx;
  }).map((x) => x.key);
}

// テスト配列を回の時間順に並べ替える
function sortTestsByTerm(tests, allTests = data.tests) {
  const order = termOrderedList(allTests);
  return [...tests].sort((a, b) => {
    const termOrder = order.indexOf(termKeyOf(a)) - order.indexOf(termKeyOf(b));
    if (termOrder) return termOrder;
    if (typeof a.date === 'string' && typeof b.date === 'string') return a.date.localeCompare(b.date);
    return 0;
  });
}

function comparisonCandidates(test, tests = data.tests) {
  const ordered = sortTestsByTerm(tests.filter(t => t.subject === test.subject), tests);
  const positions = new Map(ordered.map((t, i) => [t.id, i]));
  if (!positions.has(test.id)) return [];
  // 回の集約と、個々のテストの過去・未来は別に判定する。日付未設定時は従来の回順。
  return ordered.filter(t => t.id !== test.id && (
    typeof t.date === 'string' && t.date && typeof test.date === 'string' && test.date && t.date !== test.date
      ? t.date < test.date
      : positions.get(t.id) < positions.get(test.id)
  )).sort((a, b) => {
    if (typeof a.date === 'string' && a.date && typeof b.date === 'string' && b.date && a.date !== b.date) return a.date.localeCompare(b.date);
    return positions.get(a.id) - positions.get(b.id);
  });
}

function comparisonTarget(test) {
  if (!test) return null;
  const candidates = comparisonCandidates(test);
  if (Object.hasOwn(test, 'compareTo')) return candidates.find(t => t.id === test.compareTo) || null;
  if (!['midterm', 'final', 'proficiency'].includes(test.kind)) return null;
  if (test.kind === 'proficiency' && !test.series?.trim()) return null;
  return candidates.filter(t => t.kind === test.kind && (t.series || '').trim() === (test.series || '').trim()).at(-1) || null;
}

function testKindMatches(test, kind) {
  return !kind || kind === 'all' || (test.kind || 'unclassified') === kind;
}

function fillKindSelect(id, value, filter = false) {
  const select = $(id);
  select.innerHTML = (filter ? '<option value="all">全種類</option>' : '') +
    Object.entries(TEST_KINDS).map(([key, label]) => `<option value="${key}">${label}</option>`).join('');
  select.value = value || (filter ? 'all' : 'unclassified');
}

function refreshComparisonChoices() {
  const test = testById($('cfTest').value);
  if (!test) return;
  const select = $('cfCompare');
  const current = select.value || 'auto';
  select.innerHTML = '<option value="auto">同じ種類から自動で選ぶ</option><option value="none">比較しない</option>' +
    comparisonCandidates(test).map(t => `<option value="${esc(t.id)}">${esc(termKeyOf(t))} / ${TEST_KINDS[t.kind || 'unclassified']} / ${esc(t.date || '日付未設定')}</option>`).join('');
  select.value = [...select.options].some(o => o.value === current) ? current : 'none';
  const draft = { ...test, kind: $('cfKind').value, series: $('cfSeries').value.trim() };
  if (select.value === 'auto') delete draft.compareTo;
  else draft.compareTo = select.value === 'none' ? null : select.value;
  const target = comparisonTarget(draft);
  $('cfStatus').textContent = target ? `比較対象：${termKeyOf(target)}（${target.date || '日付未設定'}）` : '比較対象はありません。単元・その他・未分類、シリーズ未設定の実力テストは自動比較しません。';
}

function loadComparisonForm() {
  const test = testById($('cfTest').value);
  if (!test) return;
  fillKindSelect('cfKind', test.kind);
  $('cfSeries').value = test.series || '';
  $('cfCompare').innerHTML = `<option value="${esc(Object.hasOwn(test, 'compareTo') ? test.compareTo || 'none' : 'auto')}"></option>`;
  refreshComparisonChoices();
}

function openComparisonDialog(testId) {
  if (!data.tests.length) return;
  $('cfTest').innerHTML = sortTestsByTerm(data.tests).map(t => `<option value="${esc(t.id)}">${esc(termKeyOf(t))}（${esc(t.subject)}）</option>`).join('');
  $('cfTest').value = testById(testId) ? testId : data.tests[0].id;
  loadComparisonForm();
  $('comparisonDialog').showModal();
}

function submitComparisonForm(event) {
  event.preventDefault();
  const test = testById($('cfTest').value);
  if (!test) return;
  test.kind = $('cfKind').value;
  test.series = $('cfSeries').value.trim();
  if ($('cfCompare').value === 'auto') delete test.compareTo;
  else test.compareTo = $('cfCompare').value === 'none' ? null : $('cfCompare').value;
  markDirty();
  $('comparisonDialog').close();
  renderAll();
}

// 未入力と明示的な0点を区別する。合計・各分野は必要な設問がすべてそろったときだけ確定。
function questionScoreState(rec, test) {
  const questions = test.questions || [];
  let partialTotal = 0, answered = 0;
  const byDomain = new Map();
  for (const q of questions) {
    if (q.domain) {
      if (!byDomain.has(q.domain)) byDomain.set(q.domain, []);
      byDomain.get(q.domain).push(q);
    }
    const value = rec?.questions?.[q.key];
    if (!Number.isFinite(value)) continue;
    answered++;
    partialTotal += value;
  }
  const domains = {};
  for (const [key, qs] of byDomain) {
    if (qs.every(q => Number.isFinite(rec?.questions?.[q.key]))) {
      domains[key] = qs.reduce((sum, q) => sum + rec.questions[q.key], 0);
    }
  }
  return { answered, partialTotal, total: questions.length && answered === questions.length ? partialTotal : null, domains };
}

function isPartialScore(rec, test) {
  const state = questionScoreState(rec, test);
  return state.answered > 0 && state.answered < (test.questions || []).length;
}

function scoreTotalText(rec, test) {
  if (rec?.absent) return '欠';
  if (isPartialScore(rec, test)) {
    const state = questionScoreState(rec, test);
    return `${state.partialTotal}（入力途中 ${state.answered}/${test.questions.length}問）`;
  }
  return rec?.total != null ? rec.total : '';
}

function recalcScore(rec, test) {
  if (!test.questions?.length) return;
  const state = questionScoreState(rec, test);
  rec.total = state.total;
  rec.domains = state.domains;
}

// 分野満点（domains定義がなければ問題から集計）
function domainMax(test, key) {
  const d = (test.domains || []).find((x) => x.key === key);
  if (d) return d.max;
  return (test.questions || []).filter((q) => q.domain === key).reduce((a, q) => a + q.max, 0);
}

function testDomains(test) {
  if (test.domains && test.domains.length) return test.domains;
  const keys = [...new Set((test.questions || []).map((q) => q.domain).filter(Boolean))];
  return keys.map((k) => ({ key: k, label: k, max: domainMax(test, k) }));
}

/* ========== ECharts ========== */
const chartIds = ['rtiProgressChart', 'histChart', 'ovDomainChart', 'ovTrendChart', 'ovGroupComparisonChart', 'trendChart', 'trendDomainChart',
  'anDomainChart', 'anQuestionChart', 'anBoxChart', 'corrChart'];

let chartLibWarned = false;

// 全チャート共通テーマ（フォント・配色・軸線色を統一）
if (typeof echarts !== 'undefined') {
  echarts.registerTheme('gd', {
    color: PALETTE,
    textStyle: CHART_TEXT_STYLE,
    title: { textStyle: { color: '#1e2330' } },
    legend: { textStyle: { color: CHART_TEXT } },
    categoryAxis: {
      axisLine: { lineStyle: { color: CHART_AXIS } },
      axisTick: { show: false },
      axisLabel: { color: CHART_TEXT },
      splitLine: { show: false },
    },
    valueAxis: {
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: CHART_TEXT },
      splitLine: { lineStyle: { color: CHART_AXIS } },
      nameTextStyle: { color: CHART_TEXT },
    },
    tooltip: {
      backgroundColor: 'rgba(255,255,255,0.96)',
      borderColor: '#e8eaf0',
      borderWidth: 1,
      textStyle: { color: '#1e2330', fontFamily: "-apple-system, BlinkMacSystemFont, 'Hiragino Sans', 'Yu Gothic UI', 'Yu Gothic', sans-serif" },
      extraCssText: 'box-shadow:0 6px 20px rgba(20,28,56,0.12);border-radius:10px;',
    },
  });
}

// グラフ描画ライブラリが読めなかった場合のフォールバック表示
function warnChartLibMissing() {
  if (chartLibWarned) return;
  chartLibWarned = true;
  for (const id of chartIds) {
    const el = $(id);
    if (el) el.innerHTML = '<div style="display:grid;place-items:center;height:100%;color:#6b7684;font-size:13px;text-align:center;padding:16px">グラフ表示用ファイル（vendor/echarts.min.js）が読み込めませんでした。<br>ファイル一式がそろっているか確認してください。</div>';
  }
}

function chart(id) {
  const el = $(id);
  if (typeof echarts === 'undefined') {
    warnChartLibMissing();
    return { setOption() {}, resize() {}, clear() {}, getDataURL() { return ''; }, getOption() { return { series: [] }; } };
  }
  const inst = echarts.getInstanceByDom(el) || echarts.init(el, 'gd');
  if (!inst.accessibleSetOption) {
    const setOption = inst.setOption.bind(inst);
    const clear = inst.clear.bind(inst);
    inst.clear = () => {
      clear();
      document.getElementById(el.id + '-data')?.remove();
      el.removeAttribute('aria-describedby');
    };
    inst.setOption = (option, ...args) => {
      option.aria = { enabled: true, decal: { show: true } };
      option.animation = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      // Rich-text tooltips draw within the canvas instead of interpreting data as HTML.
      option.tooltip = { ...option.tooltip, renderMode: 'richText' };
      setOption(option, ...args);
      if (window.updateChartData) window.updateChartData(el, inst.getOption());
    };
    inst.accessibleSetOption = true;
  }
  return inst;
}

function resizeCharts() {
  if (typeof echarts === 'undefined') return;
  requestAnimationFrame(() => {
    for (const id of chartIds) {
      const el = $(id);
      const inst = el && echarts.getInstanceByDom(el);
      if (inst) inst.resize();
    }
  });
}

window.addEventListener('resize', resizeCharts);

const BASE_GRID = { left: 50, right: 20, top: 30, bottom: 40 };

/* ========== ファイルI/O ========== */
async function openJson() {
  if (dirty && !confirm('保存していない変更があります。破棄して開きますか？')) return;
  if (supportsFS) {
    try {
      const [handle] = await window.showOpenFilePicker({ types: FILE_TYPES });
      const file = await handle.getFile();
      applyJsonText(await file.text(), file.name, handle);
    } catch (e) {
      if (e.name !== 'AbortError') alert('ファイルを開けませんでした: ' + e.message);
    }
  } else {
    $('fileInput').click();
  }
}

function validateDataset(parsed) {
  const errors = [];
  const add = (message) => {
    if (errors.length < 12) errors.push(message);
  };
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return ['ルートがオブジェクトではありません。'];
  }
  for (const key of ['students', 'tests', 'scores']) {
    if (!Array.isArray(parsed[key])) add(`${key} は配列である必要があります。`);
  }
  if (errors.length) return errors;

  if (parsed.name != null && typeof parsed.name !== 'string') add('データ名は文字列である必要があります。');
  const object = v => v !== null && typeof v === 'object' && !Array.isArray(v);
  const optionalText = v => v == null || typeof v === 'string';
  const number = v => v == null || v === '' ||
    (typeof v === 'number' && Number.isSafeInteger(v) && v > 0) ||
    (typeof v === 'string' && /^\d+$/.test(v) && Number.isSafeInteger(Number(v)) && Number(v) > 0);
  const grade = v => v == null || v === '' || (Number.isInteger(v) && v >= 1 && v <= 3);
  if (parsed.version != null && ![1, 2, 3].includes(parsed.version)) add('version は1〜3の整数にしてください。');
  const settings = parsed.settings;
  if (settings?.adminPinHash != null && !validPinHash(settings.adminPinHash)) add('PINのハッシュ形式が不正です。');
  if (settings?.rti != null && !object(settings.rti)) add('RTI設定はオブジェクトにしてください。');
  if (settings != null && (typeof settings !== 'object' || Array.isArray(settings))) add('settings はオブジェクトである必要があります。');
  if (settings?.rti != null) {
    const { tier2, tier3 } = settings.rti;
    if (!Number.isFinite(tier2) || !Number.isFinite(tier3) || tier3 <= 0 || tier2 >= 100 || tier3 >= tier2) {
      add('RTIしきい値は 0 < Tier 3 < Tier 2 < 100 にしてください。');
    }
  }

  const studentIds = new Set();
  parsed.students.forEach((s, i) => {
    if (!s || typeof s !== 'object' || Array.isArray(s)) { add(`students[${i}] がオブジェクトではありません。`); return; }
    if (typeof s.id !== 'string' || !s.id) add(`students[${i}].id が空、または文字列ではありません。`);
    else if (studentIds.has(s.id)) add(`生徒ID「${s.id}」が重複しています。`);
    else studentIds.add(s.id);
    if (typeof s.name !== 'string' || !s.name.trim()) add(`students[${i}].name が空です。`);
    if (s.className != null && typeof s.className !== 'string') add(`students[${i}].className は文字列にしてください。`);
    if (!number(s.number)) add(`students[${i}].number は正の整数・数字の文字列・未設定にしてください。`);
    if (s.classHistory != null && (!Array.isArray(s.classHistory) || s.classHistory.some(h => !object(h) || !optionalText(h.className) || !number(h.number) || !optionalText(h.at) || (h.at && normalizeDateValue(h.at) !== h.at)))) add(`students[${i}].classHistory が不正です。`);
  });

  const testIds = new Set();
  const testsById = new Map();
  parsed.tests.forEach((t, i) => {
    if (!t || typeof t !== 'object' || Array.isArray(t)) { add(`tests[${i}] がオブジェクトではありません。`); return; }
    if (typeof t.id !== 'string' || !t.id) add(`tests[${i}].id が空、または文字列ではありません。`);
    else if (testIds.has(t.id)) add(`テストID「${t.id}」が重複しています。`);
    else { testIds.add(t.id); testsById.set(t.id, t); }
    if (typeof t.name !== 'string' || typeof t.subject !== 'string') add(`tests[${i}] のテスト名・教科は文字列にしてください。`);
    if (!Number.isFinite(t.maxScore) || t.maxScore <= 0) add(`テスト「${t.name || t.id || i}」の満点が不正です。`);
    if (t.kind != null && (typeof t.kind !== 'string' || !Object.hasOwn(TEST_KINDS, t.kind))) add(`テスト「${t.name || t.id || i}」の種類が不正です。`);
    if (t.series != null && typeof t.series !== 'string') add(`テスト「${t.name || t.id || i}」の比較系列が不正です。`);
    if (!grade(t.gradeYear)) add(`tests[${i}].gradeYear は1〜3の整数・未設定にしてください。`);
    if (!optionalText(t.date) || (t.date && normalizeDateValue(t.date) !== t.date)) add(`テスト「${t.name || t.id || i}」の実施日が不正です。`);
    if (t.domains != null && (!Array.isArray(t.domains) || t.domains.some(d => !d || typeof d.key !== 'string' || typeof d.label !== 'string' || !Number.isFinite(d.max) || d.max <= 0))) add(`テスト「${t.name || t.id || i}」の分野が不正です。`);
    if (t.questions != null && !Array.isArray(t.questions)) {
      add(`テスト「${t.name || t.id || i}」の questions が配列ではありません。`);
    } else if (Array.isArray(t.questions)) {
      const qKeys = new Set();
      let qMaxSum = 0;
      for (const q of t.questions) {
        if (!object(q)) { add(`テスト「${t.name || t.id || i}」の問題が不正です。`); continue; }
        if (!q || typeof q.key !== 'string' || !q.key || qKeys.has(q.key)) add(`テスト「${t.name || t.id || i}」の問題キーが空、または重複しています。`);
        else qKeys.add(q.key);
        if (!optionalText(q.label) || !optionalText(q.domain)) add('問題名・分野キーは文字列にしてください。');
        if (q.perspective != null && q.perspective !== '' && !['knowledge', 'thinking'].includes(q.perspective)) add('評価の観点は知識・技能、思考・判断・表現、未設定から選んでください。');
        if (!Number.isFinite(q.max) || q.max <= 0) add(`テスト「${t.name || t.id || i}」の問題配点が不正です。`);
        else qMaxSum += q.max;
      }
      if (Number.isFinite(t.maxScore) && qMaxSum > t.maxScore) add(`テスト「${t.name || t.id || i}」の問題配点合計が満点を超えています。`);
    }
  });

  for (const test of parsed.tests) {
    if (!test || test.compareTo == null) continue;
    const target = testsById.get(test.compareTo);
    if (typeof test.compareTo !== 'string' || !target || target.id === test.id || target.subject !== test.subject) {
      add('比較対象は同じ教科の別のテストを指定してください。');
    } else {
      // Use the parsed dataset here; loading must not depend on the currently open data.
      const validTests = parsed.tests.filter(t => t && typeof t === 'object');
      if (!comparisonCandidates(test, validTests).some(t => t.id === target.id)) add('比較対象は過去のテストを指定してください。');
    }
  }
  const scoreKeys = new Set();
  parsed.scores.forEach((rec, i) => {
    if (!object(rec)) { add(`scores[${i}] がオブジェクトではありません。`); return; }
    if (!studentIds.has(rec.studentId)) add(`scores[${i}] が存在しない生徒IDを参照しています。`);
    const test = testsById.get(rec.testId);
    if (!test) add(`scores[${i}] が存在しないテストIDを参照しています。`);
    if (rec.absent != null && typeof rec.absent !== 'boolean') add(`scores[${i}].absent は真偽値にしてください。`);
    for (const field of ['domains', 'questions']) {
      if (rec[field] != null && (!object(rec[field]) || Object.values(rec[field]).some(v => v != null && (!Number.isFinite(v) || v < 0)))) add(`scores[${i}].${field} は数値・未設定の値を持つオブジェクトにしてください。`);
    }
    const key = `${rec.studentId}:${rec.testId}`;
    if (scoreKeys.has(key)) add(`生徒ID「${rec.studentId}」のテスト「${rec.testId}」が重複しています。`);
    scoreKeys.add(key);
    if (rec.total != null && test && (!Number.isFinite(rec.total) || rec.total < 0 || rec.total > test.maxScore)) {
      add(`scores[${i}].total が0〜${test.maxScore}の範囲外です。`);
    }
    if (rec.questions != null && (typeof rec.questions !== 'object' || Array.isArray(rec.questions))) {
      add(`scores[${i}].questions がオブジェクトではありません。`);
    } else if (test && rec.questions) {
      const qByKey = new Map((Array.isArray(test.questions) ? test.questions : []).filter(Boolean).map((q) => [q.key, q]));
      for (const [qkey, value] of Object.entries(rec.questions)) {
        const q = qByKey.get(qkey);
        if (q && (!Number.isFinite(value) || value < 0 || value > q.max)) {
          add(`scores[${i}].questions.${qkey} が0〜${q.max}の範囲外です。`);
        }
      }
    }
  });

  if (parsed.metrics != null && !Array.isArray(parsed.metrics)) add('metrics は配列である必要があります。');
  const metricIds = new Set();
  for (const m of (Array.isArray(parsed.metrics) ? parsed.metrics : [])) {
    if (!object(m) || !m.values || typeof m.values !== 'object' || Array.isArray(m.values)) {
      add('指標にはオブジェクト形式の values が必要です。'); continue;
    }
    if (typeof m.id !== 'string' || !m.id || metricIds.has(m.id)) add('指標IDが空、または重複しています。');
    metricIds.add(m.id);
    if (typeof m.label !== 'string' || !['number', 'scale'].includes(m.type)) add('指標名または指標の種類が不正です。');
    for (const [sid, value] of Object.entries(m.values)) {
      if (!studentIds.has(sid)) add(`指標「${m.label || m.id}」が存在しない生徒IDを参照しています。`);
      if (!validMetricValue(m.type, value)) {
        add(`指標「${m.label || m.id}」に不正な値があります。`);
      }
    }
  }

  if (parsed.interventions != null && !Array.isArray(parsed.interventions)) add('interventions は配列である必要があります。');
  for (const iv of (Array.isArray(parsed.interventions) ? parsed.interventions : [])) {
    if (!object(iv)) { add('支援記録はオブジェクトにしてください。'); continue; }
    if (iv.kind != null && iv.kind !== 'all' && (typeof iv.kind !== 'string' || !Object.hasOwn(TEST_KINDS, iv.kind))) add('支援記録のテスト種類が不正です。');
    if (iv && !studentIds.has(iv.studentId)) add(`支援記録「${iv.title || iv.id}」が存在しない生徒IDを参照しています。`);
    if (typeof iv.id !== 'string' || typeof iv.title !== 'string' || typeof iv.subject !== 'string') add('支援記録のID・内容・教科は文字列にしてください。');
    // 旧形式の未設定項目は許容し、指定された日付は並び替え可能な形式に限定する。
    for (const field of ['startDate', 'endDate', 'createdAt']) {
      const value = iv[field];
      if (value != null && (typeof value !== 'string' || (value !== '' && normalizeDateValue(value) !== value))) {
        add(`支援記録の ${field} は YYYY-MM-DD 形式の実在する日付、または未設定にしてください。`);
      }
    }
    if (iv.status != null && !['active', 'done'].includes(iv.status)) {
      add('支援記録の状態は active または done にしてください。');
    }
    if (iv.note != null && typeof iv.note !== 'string') add('支援記録のメモは文字列にしてください。');
    if (iv.baseline != null && (!Number.isFinite(iv.baseline) || iv.baseline < 0 || iv.baseline > 100)) {
      add('支援記録の開始時基準値は0〜100の数値、または未設定にしてください。');
    }
  }
  if (parsed.teachingNotes !== undefined) {
    if (typeof window.GD_TEACHING?.validate !== 'function') add('指導メモの検証機能を読み込めません。アプリをすべて展開し直してください。');
    else window.GD_TEACHING.validate(parsed.teachingNotes).forEach(add);
  }
  return errors;
}

function applyJsonText(text, name, handle) {
  const previous = { data, fileHandle, fileName, dirty, lastDiskText, activeDataToken,
    pendingDownload, isAdmin, scoreIndex, ui: { ...ui }, teachingUi: window.GD_TEACHING_UI?.snapshot() };
  let committed = false;
  let parsed;
  try {
    try {
      parsed = JSON.parse(text);
    } catch {
      alert('JSONの形式が正しくありません。');
      return;
    }
    // 旧版の削除処理が残した、所有者のいない支援記録は読み込み時に安全に除外する
    let removedOrphanInterventions = 0;
    if (parsed && Array.isArray(parsed.students) && Array.isArray(parsed.interventions)) {
      const ids = new Set(parsed.students.filter(Boolean).map((s) => s.id));
      const before = parsed.interventions.length;
      parsed.interventions = parsed.interventions.filter((iv) => iv && ids.has(iv.studentId));
      removedOrphanInterventions = before - parsed.interventions.length;
    }
    const validationErrors = validateDataset(parsed);
    if (validationErrors.length) {
      alert('成績データに問題があります。修正してから開いてください。\n\n・' + validationErrors.join('\n・'));
      return;
    }
    let migrated = removedOrphanInterventions > 0;
    if (!parsed.metrics) { parsed.metrics = []; migrated = true; }
    // 移行：出席番号(number)が無い生徒は id を初期値として補う
    for (const s of parsed.students) {
      if (s.number == null || s.number === '') {
        const candidate = Number.parseInt(s.id, 10);
        s.number = Number.isSafeInteger(candidate) && candidate > 0 ? candidate : '';
        migrated = true;
      }
    }
    // 移行（V2 / version 3）：設定と支援記録
    if (!parsed.settings || typeof parsed.settings !== 'object') { parsed.settings = {}; migrated = true; }
    if (!parsed.settings.rti) { parsed.settings.rti = { tier2: 60, tier3: 40 }; migrated = true; }
    if (parsed.settings.adminPinHash === undefined) { parsed.settings.adminPinHash = null; migrated = true; }
    if (!Array.isArray(parsed.interventions)) { parsed.interventions = []; migrated = true; }
    if (!parsed.version || parsed.version < 3) { parsed.version = 3; migrated = true; }
    data = parsed;
    committed = true;
    activeDataToken++;
    pendingDownload = null;
    fileHandle = handle || null;
    fileName = name;
    dirty = migrated;
    lastDiskText = text;  // 読み込んだ時点のディスク内容を記録
    rebuildIndex();

    // 選択状態を初期化
    ui.ovClass = ui.inClass = ui.anClass = ui.trendClass = ui.metClass = 'all';
    ui.inSubject = ui.ovSubject = ui.anSubject = ui.listSubject = 'all';
    ui.listClass = 'all'; ui.listMode = 'total'; ui.listSort = null; ui.listPivot = 60;
    ui.listGrade = 'all'; ui.listTerm = 'all';
    ui.rtiSubject = 'all'; ui.rtiClass = 'all'; ui.rtiBasis = 'latest'; ui.rtiSelectedIv = null;
    ui.trendKind = ui.rtiKind = 'all';
    isAdmin = false; // ファイルを開くたびに教員モードへ戻す
    ui.trendSubject = data.tests.length ? data.tests[0].subject : '';
    const lastTest = data.tests.length ? data.tests[data.tests.length - 1].id : '';
    ui.ovTest = ui.inTest = ui.anTest = lastTest;
    ui.trendSelected = new Set();
    ui.trendCompareTest = ''; ui.trendCompareFrom = null; ui.trendComparisonStarted = false;
    ui.trendSearch = '';
    ui.metricId = data.metrics.length ? data.metrics[0].id : '';
    ui.corrX = data.metrics.length ? 'm:' + data.metrics[0].id : (lastTest ? 't:' + lastTest : '');
    ui.corrY = lastTest ? 't:' + lastTest : '';

    $('emptyState').hidden = true;
    $('appMain').hidden = false;
    $('saveBtn').disabled = false;
    $('rosterBtn').disabled = false;
    $('backupBtn').disabled = false;
    $('roleBtn').disabled = false;
    updateRoleUI(); // ロールに応じたUI（admin-onlyの表示制御）を反映
    $('datasetName').textContent = `${data.name || ''}（${fileName}）`;
    updateSaveStatus();
    renderAll();
    if (removedOrphanInterventions) {
      alert(`削除済みの生徒に紐づいていた支援記録 ${removedOrphanInterventions}件を整理しました。右上の「保存」でデータファイルへ反映してください。`);
    }
    return true;
  } catch {
    if (committed) {
      ({ data, fileHandle, fileName, dirty, lastDiskText, activeDataToken,
        pendingDownload, isAdmin, scoreIndex } = previous);
      Object.assign(ui, previous.ui);
      window.GD_TEACHING_UI?.restore(previous.teachingUi);
      // Repaint the previous dataset where possible; restoring the model must not depend on rendering.
      try {
        $('emptyState').hidden = !!data;
        $('appMain').hidden = !data;
        for (const id of ['saveBtn', 'rosterBtn', 'backupBtn', 'roleBtn']) $(id).disabled = !data;
        $('datasetName').textContent = data ? `${data.name || ''}（${fileName}）` : '';
        updateRoleUI(); updateSaveStatus();
        if (data) renderAll();
      } catch { /* Keep the original data and save target even if repaint also fails. */ }
    }
    alert('JSONを開けませんでした。元のデータ・保存先・未保存の変更は保持しています。');
    return false;
  }
}

function canPickSaveFile() {
  return window.isSecureContext !== false && typeof window.showSaveFilePicker === 'function';
}

function openSaveDialog() {
  if (!data || saving) return;
  const supported = canPickSaveFile();
  $('saveOverwriteBtn').disabled = !supported;
  $('saveAsBtn').disabled = !supported;
  $('saveTarget').textContent = fileHandle ? `上書き先：${fileHandle.name}` : '上書き先は未指定です。最初に既存のJSONを保存先として選択してください。';
  $('saveCapabilityNote').textContent = supported ?
    'このブラウザでは保存先を選択できます。初回は書き込み先のJSONを選び、次からは同じファイルへ上書きできます。' :
    'このブラウザではファイルへの直接保存を利用できません。JSONをダウンロードして保存してください。';
  $('saveDownloadName').value = fileName || 'seiseki-data.json';
  $('downloadConfirmBtn').hidden = !pendingDownload;
  $('saveResult').textContent = pendingDownload ? '先ほどダウンロードしたファイルの保存先と内容を確認してください。' : '';
  $('saveDialog').showModal();
}

function setSaveBusy(value) {
  saving = value;
  for (const id of ['saveOverwriteBtn', 'saveAsBtn', 'saveDownloadBtn', 'downloadConfirmBtn', 'saveCloseBtn']) {
    $(id).disabled = value || (['saveOverwriteBtn', 'saveAsBtn'].includes(id) && !canPickSaveFile());
  }
}

async function saveJson(mode = 'download') {
  if (!data || saving) return;
  const validationErrors = validateDataset(data);
  if (validationErrors.length) { alert('データに問題があるため保存できません。\n\n・' + validationErrors.join('\n・')); return; }
  const text = JSON.stringify(data, null, 2);
  const token = activeDataToken;
  if (mode === 'download') {
    const name = $('saveDownloadName').value.trim();
    if (!name || /[\\/:*?"<>|]/.test(name)) { $('saveResult').textContent = 'ファイル名を入力してください。記号 \\ / : * ? " < > | は使えません。'; return; }
    const blob = new Blob([text], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = /\.json$/i.test(name) ? name : name + '.json';
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 30000);
    pendingDownload = { text, token };
    $('downloadConfirmBtn').hidden = false;
    $('saveResult').textContent = 'ダウンロードを開始しました。保存されたJSONを確認してください。';
    $('saveStatus').textContent = 'JSONを出力しました。保存先でファイルを確認してください。';
    return;
  }
  if (!canPickSaveFile()) { $('saveResult').textContent = '直接保存を利用できません。JSONをダウンロードしてください。'; return; }
  setSaveBusy(true);
  let writable;
  try {
    let target = mode === 'overwrite' ? fileHandle : null;
    if (!target) {
      const suggestedName = mode === 'as' ? (fileName || 'seiseki-data.json').replace(/\.json$/i, '') + '_copy.json' : fileName || 'seiseki-data.json';
      target = await window.showSaveFilePicker({ suggestedName, types: FILE_TYPES });
      if (mode === 'as') {
        const same = fileHandle && typeof target.isSameEntry === 'function' ? await target.isSameEntry(fileHandle) :
          target.name.toLowerCase() === (fileName || '').toLowerCase();
        if (same) { $('saveResult').textContent = '元のファイルを残すため、別のファイル名または保存先を選んでください。'; return; }
      }
    } else if (typeof target.requestPermission === 'function' && await target.requestPermission({mode:'readwrite'}) !== 'granted') {
      $('saveResult').textContent = '書き込みが許可されませんでした。作業中のデータは保持しています。'; return;
    }
    if (mode === 'overwrite') {
      const diskNow = await (await target.getFile()).text();
      if (diskNow !== lastDiskText && !confirm('保存先の内容が、開いた時点または前回保存したJSONと異なります。あなたの内容で上書きしますか？\nキャンセルすると作業中のデータを保持して保存をやめます。')) return;
    }
    if (token !== activeDataToken) return;
    writable = await target.createWritable();
    await writable.write(text);
    await writable.close(); writable = null;
    if (token !== activeDataToken) return;
    fileHandle = target; fileName = target.name; lastDiskText = text;
    pendingDownload = null;
    dirty = JSON.stringify(data, null, 2) !== text;
    $('datasetName').textContent = `${data.name || ''}（${fileName}）`;
    updateSaveStatus(true);
    $('saveDialog').close();
  } catch (error) {
    if (writable) { try { await writable.abort(); } catch {} }
    $('saveResult').textContent = error.name === 'AbortError' ? '保存をキャンセルしました。作業中のデータは保持しています。' :
      '保存できませんでした。作業中のデータは保持しています。別の保存先を選ぶかJSONをダウンロードしてください。';
  } finally { setSaveBusy(false); }
}

function confirmDownloadedJson() {
  if (!pendingDownload) return;
  if (pendingDownload.token !== activeDataToken || pendingDownload.text !== JSON.stringify(data, null, 2)) {
    $('saveResult').textContent = 'ダウンロード後にデータが変更されています。現在の内容をもう一度保存してください。'; return;
  }
  dirty = false; pendingDownload = null;
  updateSaveStatus();
  $('saveStatus').textContent = '✓ ダウンロードしたJSONの保存を確認済み';
  $('saveDialog').close();
}

function markDirty() {
  dirty = true;
  updateSaveStatus();
}

function updateSaveStatus(justSaved) {
  const el = $('saveStatus');
  el.hidden = false;
  if (dirty) {
    el.textContent = '● 未保存の変更';
    el.className = 'save-status is-dirty';
  } else {
    el.textContent = justSaved ? '✓ 保存しました' : '✓ 保存済み';
    el.className = 'save-status is-saved';
  }
}

window.addEventListener('beforeunload', (e) => {
  if (dirty) {
    e.preventDefault();
    e.returnValue = '';
  }
});

document.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key === 's') {
    e.preventDefault();
    openSaveDialog();
  }
});

/* ========== セレクト構築 ========== */
function fillClassSelect(sel, value) {
  sel.innerHTML = `<option value="all">全クラス</option>` +
    classList().map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
  sel.value = value;
}

function fillTestSelect(sel, value) {
  sel.innerHTML = sortTestsByTerm(data.tests).map((t) =>
    `<option value="${esc(t.id)}">${esc(termKeyOf(t))}（${esc(t.subject)}）</option>`).join('');
  if (value && testById(value)) sel.value = value;
}

function subjectList() {
  return [...new Set(data.tests.map((t) => t.subject).filter(Boolean))].sort();
}

function fillSubjectSelect(sel, value) {
  sel.innerHTML = `<option value="all">全教科</option>` +
    subjectList().map((s) => `<option value="${esc(s)}">${esc(s)}</option>`).join('');
  sel.value = subjectList().includes(value) ? value : 'all';
}

// 教科で絞ったテスト一覧をセレクトに反映。選択中テストが範囲外なら先頭に寄せる。
// selectId=テスト用select, subjKey/testKey=ui上のキー名
function fillScopedTestSelect(selectId, subjKey, testKey) {
  const subj = ui[subjKey];
  const tests = sortTestsByTerm(subj === 'all' ? data.tests : data.tests.filter((t) => t.subject === subj));
  $(selectId).innerHTML = tests.map((t) =>
    `<option value="${esc(t.id)}">${esc(termKeyOf(t))}（${esc(t.subject)}）</option>`).join('');
  if (!tests.some((t) => t.id === ui[testKey])) ui[testKey] = tests.length ? tests[0].id : '';
  if (ui[testKey]) $(selectId).value = ui[testKey];
}

// 個人推移の教科セレクト（各教科 ＋ 5教科合計）
function fillTrendSubjectSelect() {
  const subjects = subjectList();
  $('trendSubject').innerHTML =
    subjects.map((s) => `<option value="${esc(s)}">${esc(s)}</option>`).join('') +
    `<option value="${SUM_KEY}">全教科合計</option>`;
  if (ui.trendSubject !== SUM_KEY && !subjects.includes(ui.trendSubject)) {
    ui.trendSubject = subjects.length ? subjects[0] : SUM_KEY;
  }
  $('trendSubject').value = ui.trendSubject;
}

/* ========== 描画：全体 ========== */
function renderAll() {
  fillClassSelect($('ovClass'), ui.ovClass);
  fillSubjectSelect($('ovSubject'), ui.ovSubject);
  fillScopedTestSelect('ovTest', 'ovSubject', 'ovTest');
  fillClassSelect($('inClass'), ui.inClass);
  fillSubjectSelect($('inSubject'), ui.inSubject);
  fillScopedTestSelect('inTest', 'inSubject', 'inTest');
  fillClassSelect($('anClass'), ui.anClass);
  fillSubjectSelect($('anSubject'), ui.anSubject);
  fillScopedTestSelect('anTest', 'anSubject', 'anTest');
  fillClassSelect($('trendClass'), ui.trendClass);
  fillTrendSubjectSelect();
  fillClassSelect($('metClass'), ui.metClass);
  fillSubjectSelect($('listSubject'), ui.listSubject);
  fillListGradeSelect();
  fillListTermSelect();
  fillListClassSelect();
  fillSubjectSelect($('rtiSubject'), ui.rtiSubject);
  fillKindSelect('trendKind', ui.trendKind || 'all', true);
  fillKindSelect('rtiKind', ui.rtiKind || 'all', true);
  fillClassSelect($('rtiClass'), ui.rtiClass);
  $('rtiBasis').value = ui.rtiBasis;
  $('listMode').value = ui.listMode;
  $('listHeat').checked = ui.listHeat;
  $('listPivot').value = ui.listPivot;
  fillAxisSelects();
  fillMetricSelect();
  renderCurrentTab();
}

function renderCurrentTab() {
  if (ui.tab === 'overview') renderOverview();
  else if (ui.tab === 'input') renderInput();
  else if (ui.tab === 'trend') renderTrend();
  else if (ui.tab === 'analysis') renderAnalysis();
  else if (ui.tab === 'metrics') renderMetricsTab();
  else if (ui.tab === 'list') renderList();
  else if (ui.tab === 'rti') renderRti();
  resizeCharts();
}

function comparisonNumber(value, signed = false) {
  if (value == null || !Number.isFinite(value)) return '—';
  const magnitude = Math.abs(value);
  const rounded = Math.round(magnitude * 100) / 100;
  const text = magnitude > 0 && magnitude < 0.01 ? value.toExponential(2) : String(value < 0 ? -rounded : rounded);
  return signed && value > 0 ? '+' + text : text;
}

const COMPARISON_ALPHA = 0.05;

function comparisonDecision(value) {
  if (!Number.isFinite(value) || value < 0 || value > 1) return '判定不可';
  return value < COMPARISON_ALPHA ? '帰無仮説を棄却' : '棄却できず';
}

function comparisonReading(row) {
  if (row.n === 0 || !Number.isFinite(row.meanChange)) return '比較できる点数がありません。';
  const trend = row.meanChange > 0 ? '平均得点率は上がっています。'
    : row.meanChange < 0 ? '平均得点率は下がっています。' : '平均得点率は変わっていません。';
  if (row.n < 2) return trend + '比較が1名のため、差を検定できません。';
  const decision = comparisonDecision(row.pAdjusted);
  if (decision === '判定不可') return trend + (row.status === 'constant'
    ? '全員の変化量が同じか、ばらつきがごく小さいため、差を検定できません。' : '検定に必要な数値を計算できません。');
  return trend + (decision === '帰無仮説を棄却' ? '統計上も前後差が認められました。' : '前後差は確認しきれていません。');
}

function comparisonP(value) {
  if (value == null) return '—';
  if (value < 0.001) return '<0.001';
  for (let digits = 3; digits <= 6; digits++) {
    const text = value.toFixed(digits), rounded = Number(text);
    if ((value < COMPARISON_ALPHA) === (rounded < COMPARISON_ALPHA) && (value > COMPARISON_ALPHA) === (rounded > COMPARISON_ALPHA)) return text;
  }
  return String(value);
}

// 概要と個人の参考欄は、同じ得点・対象者・固定4比較の補正を使う。
function groupComparisonData(students, beforeTest, afterTest) {
  const beforeCounts = { tier1: 0, tier2: 0, tier3: 0 };
  let missingBefore = 0, missingAfter = 0;
  const pairs = [];
  for (const student of students) {
    const before = individualTestScore(student.id, beforeTest).rate;
    const after = individualTestScore(student.id, afterTest).rate;
    if (before == null) { missingBefore++; continue; }
    beforeCounts['tier' + rtiTierOf(before)]++;
    if (after == null) { missingAfter++; continue; }
    pairs.push([before, after]);
  }
  const groups = typeof window.GD_PAIRED?.groupedSummary === 'function'
    ? window.GD_PAIRED.groupedSummary(pairs, data.settings.rti) : null;
  return { pairs, groups, beforeCounts, missingBefore, missingAfter };
}

function groupComparisonHtml(groups, context) {
  if (!groups) return '<p class="form-note">統計計算用ファイルを読み込めません。アプリをすべて展開し直してください。</p>';
  const {beforeCounts,missingBefore,missingAfter,scopeCount,currentCount,beforeMax,afterMax} = context;
  const { tier2, tier3 } = data.settings.rti;
  const labels = {all:'全体',tier1:'Tier 1',tier2:'Tier 2',tier3:'Tier 3'};
  const ranges = {all:'選択中のクラス',tier1:`${tier2}%以上`,tier2:`${tier3}%以上${tier2}%未満`,tier3:`${tier3}%未満`};
  const statusText = row => row.status === 'empty' ? '両方受験0名'
    : row.status === 'insufficient' ? '比較1名のため算出不可'
    : row.status === 'constant' ? (row.sdChange > 0 ? 'ばらつきが計算精度以下' : 'ばらつきなし／計算精度以下') : '';
  const rate = value => value == null ? '—' : comparisonNumber(value) + '%';
  const rows = groups.map(row => {
    const eligible = row.key === 'all' ? scopeCount : beforeCounts[row.key];
    const ci = row.ciLow == null ? '—' : `${comparisonNumber(row.ciLow,true)} ～ ${comparisonNumber(row.ciHigh,true)}`;
    return `<tr data-group-detail="${row.key}"><th scope="row">${labels[row.key]}<small>${esc(ranges[row.key])}</small></th>
      <td data-stat="n">${row.n}名<small>対象${eligible}名中</small></td>
      <td data-stat="before">${esc(rate(row.beforeMean))}</td><td data-stat="after">${esc(rate(row.afterMean))}</td>
      <td data-stat="change">${esc(row.meanChange == null ? '—' : comparisonNumber(row.meanChange,true))}</td>
      <td data-stat="ci">${esc(ci)}</td><td data-stat="p">${esc(comparisonP(row.pAdjusted))}${statusText(row) ? `<small>${statusText(row)}</small>` : ''}</td></tr>`;
  }).join('');
  const cards = groups.map(row => `<article class="group-summary-card" data-group="${row.key}" aria-labelledby="group-summary-${row.key}">
    <h5 id="group-summary-${row.key}">${labels[row.key]}<span data-stat="n">${row.n}名</span></h5>
    <p class="group-reading" data-stat="reading">${comparisonReading(row)}</p>
    <dl class="group-summary-values">
      <div><dt>平均変化量<small>ポイント</small></dt><dd data-stat="change">${esc(comparisonNumber(row.meanChange,true))}</dd></div>
      <div><dt>p値<small>前後差の判定用</small></dt><dd data-stat="p">${esc(comparisonP(row.pAdjusted))}</dd></div>
      <div><dt>効果量<small>変化の大きさ</small></dt><dd data-stat="dz">${esc(comparisonNumber(row.dz,true))}</dd></div>
    </dl></article>`).join('');
  const details = groups.map(row => `<tr data-group-calculation="${row.key}"><th scope="row">${labels[row.key]}</th><td>${esc(comparisonNumber(row.t))}</td><td>${row.df ?? '—'}</td><td>${esc(comparisonP(row.p))}</td><td>${esc(comparisonNumber(row.dz))}</td><td data-stat="decision">${comparisonDecision(row.pAdjusted)}</td></tr>`).join('');
  return `<section class="group-comparison" aria-labelledby="groupComparisonTitle">
    <h4 id="groupComparisonTitle">全体・事前のTier別の変化</h4><p class="group-test-method">同じ生徒の前後を比較</p>
    <p class="group-comparison-intro">前のテストの得点率でグループを分けています。今回の点数ではグループを入れ替えていません。</p>
    <div class="group-summary-grid">${cards}</div>
    <details class="group-reading-help"><summary>数値の見方</summary>
      <p>平均変化量は「今回 − 比較元」です。＋なら上昇、−なら低下を表します。50%から55%になった場合は＋5ポイントです。</p>
      <p>p値は、前後差を調べるt検定の結果です。0.05未満を「統計上も前後差が認められる」目安にしています。全体と3グループを調べる分の調整は計算済みです。「&lt;0.001」は「0.001より小さい」という意味です。</p>
      <p>効果量は、変化量のばらつきを基準にした変化の大きさです。＋なら上昇、−なら低下を表します。p値と合わせて確認し、指導の成果をこの値だけで判断しないでください。</p>
      <p>「前後差を確認しきれない」は「差がない」という証明ではありません。人数や点数のばらつきによっても結果は変わります。</p>
    </details>
    <p class="group-comparison-caution">得点の変化を示す参考情報です。指導による変化かどうかは、この比較だけでは判断できません。</p>
    <details class="group-comparison-details"><summary>詳細を表示</summary>
    <p>グループの区切りは、現在の設定では${esc(tier3)}%・${esc(tier2)}%です。前のテストの得点率で分けます。</p>
    <p>比較元は${esc(beforeMax)}点満点、今回は${esc(afterMax)}点満点です。得点率に直して比較します。</p>
    <p class="comparison-population">概要の平均点は今回の受験者${currentCount}名、ここでの比較は両方を受験した${groups[0].n}名が対象です。</p>
    <div id="ovGroupComparisonChart" class="chart group-comparison-chart"></div>
    <p class="group-scroll-hint">表は横にスクロールできます。</p>
    <div class="group-table-scroll" role="region" aria-label="全体・Tier別の前後比較表" tabindex="0">
      <table class="group-comparison-table"><caption>両方受験した同じ生徒の得点率で比較（差＝今回 − 比較元）</caption>
      <thead><tr><th scope="col">グループ</th><th scope="col">比較人数</th><th scope="col">比較元の平均</th><th scope="col">今回の平均</th><th scope="col">平均変化<br>ポイント</th><th scope="col">平均変化の推定範囲<br>ポイント</th><th scope="col">判定に使うp値</th></tr></thead><tbody>${rows}</tbody></table>
    </div>
    <p class="group-comparison-note">比較元の点数なし${missingBefore}名はグループ分け対象外、比較元のみ点数あり${missingAfter}名は前後比較対象外です。欠席・未入力を除き、0点は含みます。</p>
    <details class="group-interval-help"><summary>平均変化の推定範囲の説明を見る</summary>
      <p>平均変化の推定に、どのくらい幅があるかを表します。狭いほど推定の不確かさが小さくなります。例えば＋2～＋8なら上昇する範囲、−1～＋8なら低下・変化なし・上昇を含む範囲です。生徒一人ひとりの変化の範囲ではありません。</p>
      <p>この範囲は各グループで個別に計算しています。p値は複数の検定をまとめて調整しているため、範囲が0を含まなくても前後差を確認しきれない場合があります。この画面の判定には、右端のp値を使います。</p>
    </details>
    <details class="group-p-help"><summary>判定に使うp値の説明を見る</summary>
      <p>同じ生徒の前後差を調べた結果で、0.05未満を「統計上も前後差が認められる」目安にしています。全体と3グループの計4回を調べると、どこかで誤って差があると判断する機会が増えるため、その分を調整しています。表示したp値は調整済みです。</p>
      <p>p値は変化の大きさや、指導が効いた確率ではありません。上がったか下がったかは平均変化量で確認します。グループ同士の差を検定したものでもありません。</p>
    </details>
    <details class="group-calculation-details"><summary>詳しい計算方法・統計用語を確認</summary>
    <div class="group-test-criteria"><strong>判定基準：5％水準</strong><p>帰無仮説は「前後の得点率の平均変化は0」です。丸める前の補正済みp値が0.05未満なら棄却、0.05以上なら棄却できません。算出できない場合は判定不可です。</p></div>
    <p class="group-comparison-note">p値は全体と3層の計4比較でHolm補正しています。95%信頼区間は各行ごとの未補正区間のため、0を含まなくても補正p値が0.05以上になることがあります。</p>
      <p>得点率の変化を確認する探索的な比較です。テストの範囲・難しさや平均への回帰の影響があり、この結果だけで指導の効果やTier間の効果差は判断できません。</p>
      <p>対応のある両側t検定で、同じ生徒の「今回 − 比較元」の平均変化が0という仮説を検討します。変化が生徒間で独立であること、特に少人数では変化量の分布が極端に偏らず外れ値の影響が大きくないことが前提です。学級全体に共通する影響や欠測による偏りも考慮してください。</p>
      <p>有意差がないことは「指導の効果がない」ことを意味しません。また、各層のp値を比べるだけでは層間の変化の違いは検証できません。事前得点で層分けすると、初回に低かった層の上昇や高かった層の低下に、平均への回帰が混ざることがあります。</p>
      <p>0名では記述値も表示せず、1名では平均と差だけを表示します。変化量が全員同じ、またはばらつきが計算精度以下の場合は、信頼区間・p値・効果量を算出しません。極めて小さい数値は指数表記で示します。</p>
      <p>下表のp値は補正前で、判定欄は補正済みp値に基づきます。上表のHolm補正は、この画面の4比較に対するものです。テスト・クラス・しきい値を変更して繰り返す探索全体は補正しません。信頼区間は平均変化の推定の不確かさを示すもので、個々の生徒の変化の範囲や、4比較を同時に保証する区間ではありません。しきい値を変更すると、比較元の得点率から層を分け直します。</p>
      <div class="group-table-scroll"><table class="group-comparison-table group-detail-table"><caption>計算の詳細</caption><thead><tr><th scope="col">グループ</th><th scope="col">t値</th><th scope="col">自由度</th><th scope="col">p値・両側・未補正</th><th scope="col">効果量 dz</th><th scope="col">判定<br>補正済みp値・5％水準</th></tr></thead><tbody>${details}</tbody></table></div>
    </details>
      <p><a href="files/manual.html#group-comparison" target="_blank" rel="noopener">使い方ガイド：グループの前後比較</a></p>
    </details></section>`;
}

function renderGroupComparisonChart(groups) {
  if (!groups || typeof echarts === 'undefined') return;
  chart('ovGroupComparisonChart').setOption({
    grid:{left:52,right:16,top:48,bottom:32},
    legend:{data:['比較元','今回'],top:0},
    tooltip:{trigger:'axis',valueFormatter:value => value == null ? 'データなし' : comparisonNumber(value) + '%'},
    xAxis:{type:'category',data:['全体','Tier 1','Tier 2','Tier 3']},
    yAxis:{type:'value',name:'平均得点率（%）',min:0,max:100},
    series:[{name:'比較元',type:'bar',data:groups.map(row=>row.beforeMean),itemStyle:{color:'#7b8ba4'},barMaxWidth:36},
      {name:'今回',type:'bar',data:groups.map(row=>row.afterMean),itemStyle:{color:'#2458a6'},barMaxWidth:36}]
  },true);
}

/* ========== 概要タブ ========== */
function renderOverview() {
  window.GD_TEACHING_UI?.render();
  const test = testById(ui.ovTest);
  const students = studentsOf(ui.ovClass);
  const kpiEl = $('kpiGrid');
  const comparisonEl = $('ovComparison');
  const comparisonDetailsOpen = !!comparisonEl.querySelector('.group-comparison-details')?.open;
  const previousGroupChart = $('ovGroupComparisonChart');
  if (previousGroupChart && typeof echarts !== 'undefined') echarts.getInstanceByDom(previousGroupChart)?.dispose();
  comparisonEl.hidden = true;
  comparisonEl.innerHTML = '';
  $('ovSummaryContext').textContent = test
    ? `表示中：${test.subject} ／ ${ui.ovClass === 'all' ? '全クラス' : ui.ovClass} ／ ${termKeyOf(test)}${test.date ? ' ／ ' + test.date : ''}` : '';

  if (!test) {
    kpiEl.innerHTML = '<div class="kpi"><div class="kpi-label">テストがまだ登録されていません</div></div>';
    return;
  }

  const totals = students
    .map((s) => getAttendedScore(s.id, test.id))
    .filter((r) => r && r.total != null)
    .map((r) => r.total);

  const prev = comparisonTarget(test);
  let groups = null;
  if (prev) {
    const comparison = groupComparisonData(students, prev, test);
    const { pairs, beforeCounts, missingBefore, missingAfter } = comparison;
    groups = comparison.groups;
    const testSummary = (item, label, index) => {
      return `<div class="comparison-test" data-position="${index === 0 ? 'before' : 'after'}">
        <span class="comparison-test-label">${label}</span>
        <strong class="comparison-test-title">${esc(termKeyOf(item))}</strong>
        <span class="comparison-test-detail">${esc(item.date || '実施日未設定')}</span>
      </div>`;
    };
    comparisonEl.innerHTML = `<h3 id="ovComparisonTitle">テストの比較</h3>
      <p class="comparison-scope">${esc(test.subject)} ／ ${esc(ui.ovClass === 'all' ? '全クラス' : ui.ovClass)} ／ 両方受験 ${pairs.length}名</p>
      <div class="comparison-tests">${testSummary(prev, '比較元', 0)}<span class="comparison-arrow" aria-hidden="true">→</span>${testSummary(test, '今回（比較先）', 1)}</div>
      ${groupComparisonHtml(groups,{beforeCounts,missingBefore,missingAfter,scopeCount:students.length,currentCount:totals.length,beforeMax:prev.maxScore,afterMax:test.maxScore})}`;
    comparisonEl.hidden = false;
    const details = comparisonEl.querySelector('.group-comparison-details');
    if (details && typeof details.addEventListener === 'function') {
      details.open = comparisonDetailsOpen;
      details.addEventListener('toggle',() => {
        if (!details.isConnected || !details.open) return;
        renderGroupComparisonChart(groups); resizeCharts();
      });
      if (details.open) renderGroupComparisonChart(groups);
    }
  }

  // クラス間の差（全クラス表示時）：最高クラスと最低クラスの平均差を効果量つきで
  let classGapKpi = null;
  if (ui.ovClass === 'all') {
    const perClass = classList().map((k) => {
      const vals = studentsOf(k).map((s) => getAttendedScore(s.id, test.id))
        .filter((r) => r && r.total != null).map((r) => r.total);
      return { k, vals, m: vals.length >= 2 ? mean(vals) : null };
    }).filter((c) => c.m != null);
    if (perClass.length >= 2) {
      perClass.sort((a, b) => a.m - b.m);
      const lo = perClass[0], hi = perClass[perClass.length - 1];
      const dval = independentCohensD(lo.vals, hi.vals);
      if (dval != null) {
        classGapKpi = {
          label: 'クラス間の差', value: round1(hi.m - lo.m), unit: `点（${hi.k}−${lo.k}）`,
          extra: `<div class="kpi-es es-link" title="クリックで効果量の説明を表示">効果量 d = ${esFmt(dval)}（${esLabel(dval)}）</div>`,
        };
      }
    }
  }

  const kpis = [
    { label: '受験者数', value: totals.length, unit: `名 / ${students.length}名` },
    { label: '平均点', value: totals.length ? round1(mean(totals)) : '—', unit: `/ ${test.maxScore}` },
    { label: '中央値', value: totals.length ? round1(median(totals)) : '—', unit: `/ ${test.maxScore}` },
    { label: '最高点', value: totals.length ? Math.max(...totals) : '—', unit: '' },
    { label: '最低点', value: totals.length ? Math.min(...totals) : '—', unit: '' },
  ];
  if (classGapKpi) kpis.push(classGapKpi);
  kpiEl.innerHTML = kpis.map((k) =>
    `<div class="kpi"><div class="kpi-label">${esc(k.label)}</div>
     <div class="kpi-value">${esc(k.value)}<small>${esc(k.unit)}</small></div>${k.extra || ''}</div>`).join('');

  renderHistogram(test, totals);
  renderDomainBar('ovDomainChart', test, students);
  renderOverviewTrend();
}

function renderHistogram(test, totals) {
  const binSize = Math.max(1, Math.ceil(test.maxScore / 10));
  const bins = [];
  for (let lo = 0; lo < test.maxScore; lo += binSize) {
    const hi = Math.min(lo + binSize - 1, test.maxScore);
    bins.push({ lo, hi: lo + binSize >= test.maxScore ? test.maxScore : hi, count: 0 });
  }
  for (const t of totals) {
    const idx = Math.min(bins.length - 1, Math.floor(t / binSize));
    bins[idx].count++;
  }
  // 平均の位置に縦線を引く（カテゴリ軸なのでビン内の相対位置に換算）
  const avg = totals.length ? mean(totals) : null;
  const avgMark = avg != null ? {
    silent: true, symbol: 'none',
    lineStyle: { color: '#1a1a2e', type: 'dashed', width: 1.5 },
    label: { formatter: `平均 ${round1(avg)}`, position: 'end', rotate: 0, fontSize: 11, color: '#1a1a2e', distance: 4 },
    data: [{ xAxis: Math.min(bins.length - 1 + 0.49, avg / binSize - 0.5) }],
  } : undefined;

  chart('histChart').setOption({
    grid: BASE_GRID,
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: bins.map((b) => `${b.lo}–${b.hi}`),
      axisLabel: { rotate: 40, fontSize: 11 },
    },
    yAxis: { type: 'value', name: '人数', minInterval: 1 },
    series: [{
      type: 'bar',
      data: bins.map((b) => b.count),
      itemStyle: { color: PALETTE[0], borderRadius: [4, 4, 0, 0] },
      barWidth: '70%',
      markLine: avgMark,
    }],
  }, true);
}

// 分野別平均得点率の棒グラフ（概要・分析共用）
function renderDomainBar(chartId, test, students, highlightWeakest, axis = 'domain') {
  const summary = test.questions?.length ? window.GD_CLASSIFICATION.summarize(test, students.map(s => getAttendedScore(s.id, test.id)), axis).filter(g => axis !== 'perspective' || g.key) : (axis === 'perspective' ? [] : null);
  const domains = summary || testDomains(test);
  const rates = summary ? summary.map(d => d.rate == null ? null : round1(d.rate)) : domains.map((d) => {
    const vals = students
      .map((s) => getAttendedScore(s.id, test.id))
      .filter((r) => r && r.domains && r.domains[d.key] != null)
      .map((r) => r.domains[d.key] / domainMax(test, d.key) * 100);
    return vals.length ? round1(mean(vals)) : null;
  });
  const minRate = Math.min(...rates.filter((r) => r != null));
  chart(chartId).setOption({
    grid: BASE_GRID,
    tooltip: { trigger: 'axis', valueFormatter: (v) => v + '%' },
    xAxis: { type: 'category', data: domains.map((d) => d.label) },
    yAxis: { type: 'value', max: 100, name: '得点率%' },
    series: [{
      type: 'bar',
      data: rates.map((r) => ({
        value: r,
        itemStyle: {
          color: highlightWeakest && r === minRate ? '#c0392b' : PALETTE[1],
          borderRadius: [4, 4, 0, 0],
        },
      })),
      barWidth: '50%',
      label: { show: true, position: 'top', formatter: '{c}%' },
    }],
  }, true);
  return { domains, rates };
}

function renderOverviewTrend() {
  // 教科をまたいで混ざらないよう、選択中テストの教科に絞って推移を描く（回の時間順）
  const test = testById(ui.ovTest);
  const subject = test ? test.subject : (subjectList()[0] || '');
  const subjectTests = sortTestsByTerm(data.tests.filter((t) => t.subject === subject));

  const classes = classList();
  const series = [];
  const targets = ui.ovClass === 'all' ? classes : [ui.ovClass];

  targets.forEach((klass, i) => {
    const students = studentsOf(klass);
    series.push({
      name: klass,
      type: 'line',
      symbol: 'circle',
      symbolSize: 8,
      connectNulls: true,
      // 線の終端にクラス名を直接ラベル（凡例との往復を不要に）
      endLabel: { show: true, formatter: klass, fontSize: 11, color: '#1a1a2e', fontWeight: 600, distance: 6 },
      labelLayout: { moveOverlap: 'shiftY' },
      data: subjectTests.map((t) => {
        const vals = students.map((s) => getAttendedScore(s.id, t.id))
          .filter((r) => r && r.total != null).map((r) => r.total);
        return vals.length ? round1(mean(vals)) : null;
      }),
      itemStyle: { color: PALETTE[i % PALETTE.length] },
    });
  });

  if (ui.ovClass === 'all') {
    series.push({
      name: '全体',
      type: 'line',
      symbol: 'none',
      lineStyle: { type: 'dashed', color: AVG_COLOR },
      itemStyle: { color: AVG_COLOR },
      connectNulls: true,
      data: subjectTests.map((t) => {
        const vals = data.students.map((s) => getAttendedScore(s.id, t.id))
          .filter((r) => r && r.total != null).map((r) => r.total);
        return vals.length ? round1(mean(vals)) : null;
      }),
    });
  }

  const card = $('ovTrendChart').closest('.card');
  if (card) card.querySelector('h3').textContent = `テスト別 平均点の推移（${subject}）`;

  // どの系列にも値がない回は表示しない（クラス絞り込み時、他学年の回を省く）
  let ovLabels = subjectTests.map(termKeyOf);
  const ovUsed = ovLabels.map((_, i) => series.some((sr) => sr.data[i] != null));
  if (ovUsed.some((u) => !u)) {
    ovLabels = ovLabels.filter((_, i) => ovUsed[i]);
    for (const sr of series) sr.data = sr.data.filter((_, i) => ovUsed[i]);
  }

  chart('ovTrendChart').setOption({
    grid: { ...BASE_GRID, right: 56, bottom: ovLabels.length > 6 ? 60 : 40 }, // 終端ラベルの逃げ場
    tooltip: { trigger: 'axis' },
    legend: { top: 0 },
    xAxis: { type: 'category', data: ovLabels, boundaryGap: false, axisLabel: { rotate: ovLabels.length > 6 ? 30 : 0, fontSize: 11 } },
    yAxis: { type: 'value', name: '平均点' },
    series,
  }, true);
}

/* ========== 成績入力タブ ========== */
function renderInput() {
  const test = testById(ui.inTest);
  const wrap = $('scoreTableWrap');
  const statusEl = $('inputStatus');
  $('deleteTestBtn').disabled = !test;

  if (!test) {
    wrap.innerHTML = '<div class="table-empty">テストがありません。「＋ テストを追加」から登録してください。</div>';
    if (statusEl) statusEl.textContent = '';
    return;
  }

  const students = studentsOf(ui.inClass);
  const qs = test.questions || [];
  const hasQ = qs.length > 0;

  let html = '<table class="score-table"><thead><tr>';
  html += '<th>No.</th><th style="text-align:left">氏名</th><th>クラス</th>';
  for (const q of qs) {
    html += `<th>${esc(q.label)}<span class="th-max">/${q.max}</span></th>`;
  }
  html += hasQ
    ? `<th>合計<span class="th-max">/${test.maxScore}</span></th>`
    : `<th>合計<span class="th-max">/${test.maxScore}（直接入力）</span></th>`;
  html += '<th>得点率</th><th>欠席</th></tr></thead><tbody>';

  students.forEach((s, rowIdx) => {
    const rec = getScore(s.id, test.id);
    const isAbsent = !!(rec && rec.absent);
    const attended = getAttendedScore(s.id, test.id);

    html += `<tr data-sid="${esc(s.id)}" class="${isAbsent ? 'is-absent' : ''}">`;
    html += `<td class="cell-no">${esc(s.number != null && s.number !== '' ? s.number : rowIdx + 1)}</td>`;
    html += `<td class="cell-name">${esc(s.name)}</td>`;
    html += `<td class="cell-class">${esc(s.className || '')}</td>`;
    qs.forEach((q, colIdx) => {
      const v = rec && rec.questions ? rec.questions[q.key] : null;
      // 欠席行は値を表示しない（データは保持し、欠席解除で復元）
      html += `<td><input class="cell-input" type="number" min="0" max="${q.max}"
        data-row="${rowIdx}" data-col="${colIdx}" data-sid="${esc(s.id)}" data-q="${esc(q.key)}"
        value="${isAbsent ? '' : (v != null ? v : '')}" ${isAbsent ? 'disabled' : ''}></td>`;
    });
    if (hasQ) {
      const totalText = scoreTotalText(rec, test);
      html += `<td class="cell-total" data-total="${esc(s.id)}">${totalText}</td>`;
    } else {
      const v = rec && rec.total != null ? rec.total : '';
      html += `<td><input class="cell-input" type="number" min="0" max="${test.maxScore}"
        data-row="${rowIdx}" data-col="0" data-sid="${esc(s.id)}" data-q="__total__"
        value="${isAbsent ? '' : v}" ${isAbsent ? 'disabled' : ''}></td>`;
    }
    const rate = isAbsent ? '—' : (attended?.total != null ? round1(attended.total / test.maxScore * 100) + '%' : '');
    html += `<td class="cell-rate" data-rate="${esc(s.id)}">${rate}</td>`;
    html += `<td><input type="checkbox" class="absent-check" data-sid="${esc(s.id)}" ${isAbsent ? 'checked' : ''}></td>`;
    html += '</tr>';
  });
  html += '</tbody></table>';
  if (!students.length) html = '<div class="table-empty">生徒がいません。</div>';
  wrap.innerHTML = html;

  renderInputStatus(test, students);
}

function renderInputStatus(test, students = studentsOf(ui.inClass)) {
  const status = $('inputStatus');
  if (!status) return;
  let entered = 0, partial = 0, absent = 0, blank = 0;
  for (const student of students) {
    const rec = getScore(student.id, test.id);
    if (rec?.absent) absent++;
    else if (isPartialScore(rec, test)) partial++;
    else if (getAttendedScore(student.id, test.id)?.total != null) entered++;
    else blank++;
  }
  const blankLabel = blank ? `<strong class="status-blank">未入力 ${blank}名</strong>` : '未入力 0名';
  status.innerHTML = students.length
    ? `入力済 ${entered}名　/　入力途中 ${partial}名　/　欠席 ${absent}名　/　${blankLabel}　（対象 ${students.length}名）`
    : '';
}

// セル入力 → スコア更新
function handleCellInput(input) {
  const test = testById(ui.inTest);
  if (!test) return;
  const sid = input.dataset.sid;
  const qkey = input.dataset.q;
  const raw = input.value.trim();
  const max = qkey === '__total__' ? test.maxScore
    : (test.questions.find((q) => q.key === qkey) || {}).max || 0;
  const parsed = parseBoundedNumber(raw, max);
  const val = parsed.value;

  input.classList.toggle('is-over', !parsed.valid);
  input.setAttribute('aria-invalid', String(!parsed.valid));
  input.title = parsed.valid ? '' : `0〜${max}の範囲で入力してください`;
  // 範囲外の値は画面で警告するだけでなく、データへ入れない
  if (!parsed.valid) return;
  const rec = ensureScore(sid, test.id);

  if (qkey === '__total__') {
    rec.total = val;
  } else {
    if (val == null) delete rec.questions[qkey];
    else rec.questions[qkey] = val;
    recalcScore(rec, test);
    const totalCell = document.querySelector(`[data-total="${CSS.escape(sid)}"]`);
    if (totalCell) totalCell.textContent = scoreTotalText(rec, test);
  }
  const rateCell = document.querySelector(`[data-rate="${CSS.escape(sid)}"]`);
  if (rateCell) rateCell.textContent = rec.total != null ? round1(rec.total / test.maxScore * 100) + '%' : '';
  renderInputStatus(test);
  markDirty();
}

// 欠席チェックの切り替え
function handleAbsentToggle(checkbox) {
  const test = testById(ui.inTest);
  if (!test) return;
  const sid = checkbox.dataset.sid;
  const rec = ensureScore(sid, test.id);
  if (checkbox.checked) {
    rec.absent = true;
    // 欠席フラグで統計から除外する。合計のみの得点も、保存後の解除に備えて保持する。
  } else {
    delete rec.absent;
    recalcScore(rec, test);
  }
  markDirty();
  renderInput(); // 行の表示（入力可否・合計・状況）を更新
}

// Excel風キーボード操作：Enterで下、Shift+Enterで上のセルへ
function handleCellKeydown(e) {
  if (e.key !== 'Enter') return;
  const input = e.target;
  if (!input.classList.contains('cell-input')) return;
  e.preventDefault();
  const row = Number(input.dataset.row);
  const col = Number(input.dataset.col);
  const nextRow = e.shiftKey ? row - 1 : row + 1;
  const next = $('scoreTableWrap').querySelector(
    `.cell-input[data-row="${nextRow}"][data-col="${col}"]:not([disabled])`);
  if (next) {
    next.focus();
    next.select();
  } else {
    input.blur();
  }
}

// Excel貼り付け：起点セルから右・下へ流し込む
function handleCellPaste(e, input) {
  const text = (e.clipboardData || window.clipboardData).getData('text');
  if (!text || (!text.includes('\t') && !text.includes('\n'))) return; // 単一値は通常入力に任せる
  e.preventDefault();

  const test = testById(ui.inTest);
  const students = studentsOf(ui.inClass);
  const qs = test.questions || [];
  const hasQ = qs.length > 0;
  const startRow = Number(input.dataset.row);
  const startCol = Number(input.dataset.col);

  const rows = text.replace(/\r/g, '').split('\n').filter((r) => r.length);
  let invalidCount = 0, changed = false;
  rows.forEach((rowText, ri) => {
    const student = students[startRow + ri];
    if (!student) return;
    let rec = getScore(student.id, test.id);
    const editableRec = () => rec || (rec = ensureScore(student.id, test.id));
    rowText.split('\t').forEach((cell, ci) => {
      const v = cell.trim();
      if (v === '' || isNaN(Number(v))) return;
      if (hasQ) {
        const q = qs[startCol + ci];
        if (q) {
          const parsed = parseBoundedNumber(v, q.max);
          if (!parsed.valid) { invalidCount++; return; }
          editableRec().questions[q.key] = parsed.value;
          changed = true;
        }
      } else if (ci === 0) {
        const parsed = parseBoundedNumber(v, test.maxScore);
        if (!parsed.valid) { invalidCount++; return; }
        editableRec().total = parsed.value;
        changed = true;
      }
    });
    if (hasQ && rec) recalcScore(rec, test);
  });
  if (changed) markDirty();
  renderInput();
  if (invalidCount) alert(`範囲外の点数 ${invalidCount}件は取り込みませんでした。各問題の0点〜満点の範囲で入力してください。`);
}

/* ---- テスト追加ダイアログ ---- */
function builderDomainKeys() {
  // 分野キー＝分野名。テストが違っても同じ分野名なら同じ分野として扱われ、
  // 分野別の推移が年をまたいでつながる
  return [...$('tfDomains').querySelectorAll('.builder-row')].map((row) => {
    const label = row.querySelector('.bd-label').value.trim();
    return { key: label, label, max: Number(row.querySelector('.bd-max').value) || 0 };
  });
}

function addDomainRow(label = '', max = '') {
  const div = document.createElement('div');
  div.className = 'builder-row';
  div.innerHTML = `
    <input type="text" class="bd-label" placeholder="分野名（例：読解）" value="${esc(label)}">
    <input type="number" class="bd-max" placeholder="満点" min="1" value="${esc(max)}">
    <button type="button" class="row-del" title="削除">✕</button>`;
  div.querySelector('.row-del').onclick = () => { div.remove(); refreshQuestionDomainSelects(); };
  div.querySelector('.bd-label').oninput = refreshQuestionDomainSelects;
  $('tfDomains').appendChild(div);
}

function addQuestionRow(label = '', max = '', perspective = '') {
  const div = document.createElement('div');
  div.className = 'builder-row question-builder-row';
  div.innerHTML = `
    <label>問題・採点する内訳<input type="text" class="bq-label" placeholder="例：大問1-(1)" value="${esc(label)}"></label>
    <label>配点<input type="number" class="bq-max" placeholder="配点" min="1" value="${esc(max)}"></label>
    <label>分野<select class="bq-domain"></select></label>
    <label>評価の観点<select class="bq-perspective"></select></label>
    <button type="button" class="row-del" title="削除">✕</button>`;
  div.querySelector('.row-del').onclick = () => div.remove();
  div.querySelector('.bq-perspective').replaceChildren(...window.GD_CLASSIFICATION.perspectives.map(p => new Option(p.label, p.key, false, p.key === perspective)));
  $('tfQuestions').appendChild(div);
  refreshQuestionDomainSelects();
}

function refreshQuestionDomainSelects() {
  const domains = builderDomainKeys();
  for (const sel of $('tfQuestions').querySelectorAll('.bq-domain')) {
    const cur = sel.value;
    sel.replaceChildren(new Option('分野なし', ''),
      ...domains.map(d => new Option(d.label || '(無名)', d.key)));
    if ([...sel.options].some((o) => o.value === cur)) sel.value = cur;
  }
}

// 同じ教科の直近テストから分野・問題・配点をコピー（分野名を揃えるための近道）
function copyPrevStructure() {
  const subj = $('tfSubject').value.trim();
  if (!subj) { alert('先に「教科」を入力してください。'); return; }
  const prev = [...data.tests].reverse().find((t) =>
    t.subject === subj && ((t.domains && t.domains.length) || (t.questions && t.questions.length)));
  if (!prev) { alert(`「${subj}」のテストはまだ登録されていません。`); return; }
  $('tfDomains').innerHTML = '';
  $('tfQuestions').innerHTML = '';
  for (const d of (prev.domains || [])) addDomainRow(d.label, d.max);
  const dLabelOf = new Map((prev.domains || []).map((d) => [d.key, d.label]));
  for (const q of (prev.questions || [])) {
    addQuestionRow(q.label, q.max, q.perspective || '');
    const sel = $('tfQuestions').lastElementChild.querySelector('.bq-domain');
    const label = dLabelOf.get(q.domain) || q.domain || '';
    if ([...sel.options].some((o) => o.value === label)) sel.value = label;
  }
  $('tfMax').value = prev.maxScore || 100;
}

function openTestDialog() {
  $('tfName').value = '';
  $('tfSubject').value = data.tests.length ? data.tests[data.tests.length - 1].subject : '';
  const lastGy = data.tests.length ? data.tests[data.tests.length - 1].gradeYear : null;
  $('tfGrade').value = lastGy ? String(lastGy) : '';
  $('tfDate').value = '';
  $('tfMax').value = 100;
  fillKindSelect('tfKind');
  $('tfSeries').value = '';
  $('tfDomains').innerHTML = '';
  $('tfQuestions').innerHTML = '';
  $('testDialog').showModal();
}

function submitTestDialog(e) {
  e.preventDefault();
  // 分野名の重複は1つにまとめる（キー＝分野名）
  const seenD = new Set();
  const domains = builderDomainKeys().filter((d) => d.label && !seenD.has(d.label) && seenD.add(d.label));
  const questions = [...$('tfQuestions').querySelectorAll('.builder-row')].map((row, i) => ({
    key: 'q' + (i + 1),
    label: row.querySelector('.bq-label').value.trim() || `問${i + 1}`,
    max: Number(row.querySelector('.bq-max').value) || 0,
    domain: row.querySelector('.bq-domain').value || undefined,
    perspective: row.querySelector('.bq-perspective').value || undefined,
  })).filter((q) => q.max > 0);
  const maxScore = Number($('tfMax').value) || 100;
  const questionMaxSum = questions.reduce((sum, q) => sum + q.max, 0);
  if (questions.length && questionMaxSum !== maxScore) {
    alert(`問題の配点合計（${questionMaxSum}点）とテストの満点（${maxScore}点）を一致させてください。`);
    return;
  }
  const domainMismatch = domains.find((d) => {
    const assignedMax = questions.filter((q) => q.domain === d.key).reduce((sum, q) => sum + q.max, 0);
    return assignedMax > 0 && assignedMax !== d.max;
  });
  if (domainMismatch) {
    const assignedMax = questions.filter((q) => q.domain === domainMismatch.key).reduce((sum, q) => sum + q.max, 0);
    alert(`分野「${domainMismatch.label}」の満点（${domainMismatch.max}点）と、所属する問題の配点合計（${assignedMax}点）が一致しません。`);
    return;
  }

  const test = {
    id: 't' + Date.now(),
    name: $('tfName').value.trim(),
    subject: $('tfSubject').value.trim(),
    kind: $('tfKind').value || 'unclassified', series: $('tfSeries').value.trim(),
    maxScore,
    domains,
    questions,
  };
  const gy = parseInt($('tfGrade').value, 10);
  if (gy >= 1 && gy <= 3) test.gradeYear = gy;
  const date = $('tfDate').value;
  if (date) test.date = date;
  data.tests.push(test);
  ui.inTest = test.id;
  // 追加したテストが教科フィルタで隠れないよう、その教科に合わせる
  if (ui.inSubject !== 'all' && ui.inSubject !== test.subject) ui.inSubject = test.subject;
  ui.ovTest = ui.ovTest || test.id;
  ui.anTest = ui.anTest || test.id;
  markDirty();
  $('testDialog').close();
  renderAll();
}

function deleteCurrentTest() {
  if (!requireAdmin()) return;
  const test = testById(ui.inTest);
  if (!test) return;
  if (!confirm(`「${test.name}」と入力済みの得点をすべて削除します。よろしいですか？`)) return;
  data.tests = data.tests.filter((t) => t.id !== test.id);
  for (const remaining of data.tests) if (remaining.compareTo === test.id) remaining.compareTo = null;
  data.scores = data.scores.filter((s) => s.testId !== test.id);
  rebuildIndex();
  const last = data.tests.length ? data.tests[data.tests.length - 1].id : '';
  if (ui.inTest === test.id) ui.inTest = last;
  if (ui.ovTest === test.id) ui.ovTest = last;
  if (ui.anTest === test.id) ui.anTest = last;
  markDirty();
  renderAll();
}

/* ========== 個人推移タブ ========== */
function renderTrend() {
  if (!ui.trendComparisonStarted) useOverviewComparison();
  const ids = new Set(data.students.map(s => s.id));
  for (const sid of ui.trendSelected) if (!ids.has(sid)) ui.trendSelected.delete(sid);
  renderStudentList();
  renderTrendSupport();
  renderTrendComparison();
  renderTrendChart();
  renderTrendDomainChart();
  // カルテ印刷は生徒1名選択時のみ
  $('printKarteBtn').disabled = ui.trendSelected.size !== 1;
}

// 個人の1組は記述値だけを表示する。グループの検定や効果量を転用しない。
function individualTestScore(sid, test) {
  const stored = getScore(sid, test.id);
  if (stored?.absent) return { rate: null, total: null, reason: '欠席' };
  const rec = getAttendedScore(sid, test.id);
  if (!rec || rec.total == null) return { rate: null, total: null, reason: '未入力・入力途中' };
  const max = test.maxScore;
  if (!Number.isFinite(rec.total) || !Number.isFinite(max) || max <= 0 || rec.total < 0 || rec.total > max) {
    return { rate: null, total: null, reason: '得点を確認してください' };
  }
  return { rate: rec.total / max * 100, total: rec.total, reason: '' };
}

function individualTestDetail(test) {
  return [test.subject, test.date || '日付未設定', TEST_KINDS[test.kind] || '未分類', test.series || ''].filter(Boolean).join('・');
}

function useOverviewComparison() {
  ui.trendComparisonStarted = true;
  const test = testById(ui.ovTest);
  if (!test) return;
  ui.trendSubject = test.subject;
  ui.trendKind = 'all';
  ui.trendClass = ui.ovClass;
  ui.trendCompareTest = test.id;
  ui.trendCompareFrom = comparisonTarget(test)?.id || '';
  fillTrendSubjectSelect();
  fillKindSelect('trendKind', ui.trendKind, true);
  fillClassSelect($('trendClass'), ui.trendClass);
}

function individualComparisonContext(student, before, after, from, to) {
  const context = { row: null, gap: null, position: null, reason: '', positionReason: '' };
  const scope = studentsOf(ui.trendClass);
  if (!scope.some(s => s.id === student.id)) {
    context.reason = '選択中のクラスに本人が含まれていません。本人を含むクラス、または全クラスを選んでください。';
    return context;
  }
  if (from.rate == null) {
    context.reason = '比較元の得点率がないため、本人の所属グループを決められません。';
    return context;
  }
  const tier = rtiTierOf(from.rate);
  const groups = groupComparisonData(scope, before, after).groups;
  if (!groups) {
    context.reason = '統計計算用ファイルを読み込めません。アプリをすべて展開し直してください。';
    return context;
  }
  const row = groups.find(g => g.tier === tier);
  const { tier2, tier3 } = data.settings.rti;
  Object.assign(context, { row, tier, range: tier === 1 ? `${tier2}%以上` : tier === 2 ? `${tier3}%以上${tier2}%未満` : `${tier3}%未満`,
    className: ui.trendClass === 'all' ? '全クラス' : ui.trendClass });
  if (to.rate == null) {
    context.positionReason = '本人の今回の得点率がないため、平均との差と位置は表示できません。';
  } else if (row.n < 2) {
    context.positionReason = '比較できる生徒が本人だけのため、平均との差と位置は表示しません。';
  } else {
    context.gap = to.rate - from.rate - row.meanChange;
    if (row.n < 3) {
      context.positionReason = '比較人数が2名のため、変化の相対位置は表示しません。このアプリでは3名から表示します。';
    } else if (row.status !== 'ok' || !(row.sdChange > 0)) {
      context.positionReason = '変化量のばらつきがないか計算精度以下のため、変化の相対位置は表示できません。';
    } else {
      const position = context.gap / row.sdChange;
      if (Number.isFinite(position)) context.position = position;
      else context.positionReason = '計算に必要な数値を確認できないため、変化の相対位置は表示できません。';
    }
  }
  return context;
}

function renderIndividualGroupReference(before, after, to, context) {
  const reference = $('trendGroupReference');
  reference.hidden = false;
  const heading = '<h4 id="trendGroupReferenceTitle">所属グループの結果（参考）</h4>';
  if (context.reason) { reference.innerHTML = heading + `<p>${esc(context.reason)}</p>`; return; }
  const { row, tier, range, className } = context;
  reference.innerHTML = `${heading}<p class="individual-reference-label">以下はグループの集計です。本人の検定結果ではありません。</p>
    <p class="individual-reference-scope">${esc(className)} ／ 比較元の得点率で分けた Tier ${tier}（${esc(range)}） ／ 両方受験 ${row.n}名</p>
    <p class="individual-reference-tests">${esc(termKeyOf(before))} → ${esc(termKeyOf(after))}</p>
    ${to.rate == null ? '<p class="individual-reference-exclusion">本人は今回の得点率がないため、このグループの比較人数には含まれていません。</p>' : ''}
    <p class="individual-reference-reading">${esc(comparisonReading(row))}</p>
    <dl class="group-summary-values">
      <div><dt>平均変化量<small>ポイント</small></dt><dd data-stat="group-change">${esc(comparisonNumber(row.meanChange, true))}</dd></div>
      <div><dt>p値<small>グループの前後差の判定用</small></dt><dd data-stat="group-p">${esc(comparisonP(row.pAdjusted))}</dd></div>
      <div><dt>効果量<small>グループの変化の大きさ</small></dt><dd data-stat="group-dz">${esc(comparisonNumber(row.dz, true))}</dd></div>
    </dl>
    <details class="individual-reference-help"><summary>グループの数値の見方</summary>
      <p>本人と同じ2つのテストを使い、選択中のクラス範囲で、比較元の得点率が同じTierの生徒を集計します。今回の得点率でグループを入れ替えません。欠席・未入力・入力途中を除き、両方に得点がある同じ生徒だけを比較します。0点は含めます。</p>
      <p>平均変化量はグループの「今回 − 比較元」です。p値はグループの前後差を調べるt検定の結果で、0.05未満を前後差が認められる目安にしています。「&lt;0.001」は0.001より小さいという意味です。概要と同じく、全体と3グループを調べる分の調整は計算済みです。</p>
      <p>効果量は変化量のばらつきを基準にしたグループの変化の大きさです。比較人数が0・1名、または変化量のばらつきがないなどの場合、p値や効果量は「—」となります。</p>
      <p>グループで差が認められても、本人に同じ変化があったとは判断できません。差を確認しきれないことも、差がないという証明ではありません。この比較だけで、指導による変化かどうかは判断できません。</p>
    </details>`;
}

function renderTrendComparison() {
  const scope = $('trendComparisonScope');
  const controls = $('trendComparisonControls');
  const result = $('trendComparisonResult');
  const help = $('trendComparisonHelp');
  const reference = $('trendGroupReference');
  reference.hidden = true;
  reference.innerHTML = '';
  $('trendUseOverview').disabled = !testById(ui.ovTest);
  controls.hidden = help.hidden = true;
  result.innerHTML = '';
  if (ui.trendSelected.size !== 1) {
    scope.textContent = ui.trendSelected.size ? '本人の2回の変化を見るには、名簿の選択を1人にしてください。' : '名簿から生徒を1人選んでください。';
    return;
  }
  const student = data.students.find(s => s.id === [...ui.trendSelected][0]);
  if (!student) { scope.textContent = '名簿から生徒を選び直してください。'; return; }
  scope.textContent = [student.name + 'さん', student.className || '', student.number == null || student.number === '' ? '' : student.number + '番', ui.trendSubject === SUM_KEY ? '全教科合計' : ui.trendSubject].filter(Boolean).join(' ／ ');
  if (ui.trendSubject === SUM_KEY) {
    result.textContent = '2回の比較は、教科を選ぶと表示できます。全教科合計の推移は下のグラフで確認できます。';
    return;
  }
  const tests = sortTestsByTerm(data.tests.filter(t => t.subject === ui.trendSubject && testKindMatches(t, ui.trendKind)));
  const after = tests.find(t => t.id === ui.trendCompareTest) || tests.at(-1);
  if (!after) { result.textContent = '選択した教科・種類にテストがありません。'; return; }
  if (after.id !== ui.trendCompareTest) { ui.trendCompareTest = after.id; ui.trendCompareFrom = null; }
  const candidates = comparisonCandidates(after);
  if (ui.trendCompareFrom === null) ui.trendCompareFrom = comparisonTarget(after)?.id || '';
  const before = candidates.find(t => t.id === ui.trendCompareFrom);
  const option = t => `<option value="${esc(t.id)}">${esc(termKeyOf(t))}（${esc(individualTestDetail(t))}）</option>`;
  $('trendCompareTest').innerHTML = tests.map(option).join('');
  $('trendCompareTest').value = after.id;
  $('trendCompareFrom').innerHTML = '<option value="">比較元を選択してください</option>' + candidates.map(option).join('');
  $('trendCompareFrom').value = before?.id || '';
  controls.hidden = help.hidden = false;
  if (!before) {
    result.textContent = candidates.length ? '比較元のテストを選択してください。自動で比較元が決まらない場合も、同じ教科の過去のテストを選べます。' : '同じ教科の過去のテストがないため、この回は比較できません。';
    return;
  }
  const from = individualTestScore(student.id, before);
  const to = individualTestScore(student.id, after);
  const context = individualComparisonContext(student, before, after, from, to);
  const change = from.rate == null || to.rate == null ? null : to.rate - from.rate;
  const reading = change == null
    ? [from.reason ? '比較元は' + from.reason : '', to.reason ? '今回は' + to.reason : ''].filter(Boolean).join('、') + 'のため、2回を比較できません。'
    : change > 0 ? 'この2回では、本人の得点率が上がっています。'
    : change < 0 ? 'この2回では、本人の得点率が下がっています。' : 'この2回では、本人の得点率は同じです。';
  const scoreCard = (test, score, position, label) => `<section class="individual-test" data-position="${position}"><h4>${label}</h4>
    <p class="individual-test-title">${esc(termKeyOf(test))}</p><p class="individual-test-detail">${esc(individualTestDetail(test))}</p>
    <p class="individual-value" data-stat="rate">${esc(comparisonNumber(score.rate))}${score.rate == null ? '' : '<small>%</small>'}</p>
    <p class="individual-raw-score" data-stat="score">${score.rate == null ? esc(score.reason) : esc(comparisonNumber(score.total)) + ' / ' + esc(comparisonNumber(test.maxScore)) + '点'}</p></section>`;
  const differentType = (before.kind || 'unclassified') !== (after.kind || 'unclassified') || (before.series || '').trim() !== (after.series || '').trim();
  const relativeReading = context.gap == null ? '' : context.gap > 0 ? '変化量は、同じTierの平均を上回っています。'
    : context.gap < 0 ? '変化量は、同じTierの平均を下回っています。' : '同じTierの平均と同じ変化量です。';
  const scopeNote = context.row ? `${context.className} ／ 比較元の Tier ${context.tier} ／ 両方受験 ${context.row.n}名${to.rate == null ? '' : '（本人を含む）'}` : '';
  result.innerHTML = `<div class="individual-test-context">${scoreCard(before, from, 'before', '比較元')}${scoreCard(after, to, 'after', '今回')}</div>
    <p class="individual-reading">${esc(reading)}${esc(relativeReading)}</p>
    ${scopeNote ? `<p class="individual-metrics-scope">比較の基準：${esc(scopeNote)}</p>` : ''}<div class="individual-values">
    <section class="individual-change"><h4>本人の変化</h4><p class="individual-test-detail">得点率：今回 − 比較元</p>
    <p class="individual-value" data-stat="change">${esc(comparisonNumber(change, true))}<small>ポイント</small></p></section>
    <section><h4>同じTierの平均との差</h4><p class="individual-test-detail">本人の変化 − 平均変化</p>
    <p class="individual-value" data-stat="gap">${esc(comparisonNumber(context.gap, true))}<small>ポイント</small></p></section>
    <section><h4>変化の相対位置（参考）</h4><p class="individual-test-detail">0が平均、＋は平均より大きい変化</p>
    <p class="individual-value" data-stat="position">${esc(comparisonNumber(context.position, true))}${context.position == null ? '' : '<small>SD</small>'}</p></section></div>
    ${context.reason || context.positionReason ? `<p class="individual-metrics-note">${esc(context.reason || context.positionReason)}</p>` : ''}
    ${differentType ? '<p class="individual-type-note">種類・シリーズが異なります。比較に適した2回か確認してください。</p>' : ''}
    <p class="comparison-caution">相対位置はグループ内での比較用の参考値です。テストの範囲・難しさも変わるため、個人の有意差や指導効果を判定するものではありません。</p>`;
  renderIndividualGroupReference(before, after, to, context);
}

function renderStudentList() {
  const listEl = $('studentList');
  const kw = ui.trendSearch.trim();
  const students = studentsOf(ui.trendClass).filter((s) => !kw || s.name.includes(kw));
  listEl.innerHTML = students.map((s) => `
    <li data-sid="${esc(s.id)}" class="${ui.trendSelected.has(s.id) ? 'is-checked' : ''}">
      <input type="checkbox" ${ui.trendSelected.has(s.id) ? 'checked' : ''} tabindex="-1">
      <span class="sl-num">${esc(s.number != null && s.number !== '' ? s.number : '')}</span>
      <span>${esc(s.name)}</span>
      <span class="sl-class">${esc(s.className || '')}</span>
    </li>`).join('');
}

function sortedInterventions(records = data.interventions) {
  return [...records].sort((a, b) => {
    if ((a.status === 'active') !== (b.status === 'active')) return a.status === 'active' ? -1 : 1;
    return (b.startDate || '').localeCompare(a.startDate || '');
  });
}

function renderTrendSupport() {
  const summary = $('trendSupportSummary');
  const records = $('trendSupportRecords');
  const previousHistoryOpen = records.querySelector('details')?.open || false;
  records.innerHTML = '';
  $('trendSupportStatus').textContent = '';
  $('trendSupportBody').hidden = true;
  $('trendAddSupport').disabled = true;
  const student = ui.trendSelected.size === 1 && data.students.find(s => s.id === [...ui.trendSelected][0]);
  if (!student) {
    summary.textContent = '生徒を1名選ぶと、支援の追加と記録の確認ができます。';
    delete records.dataset.sid;
    return;
  }
  const keepHistoryOpen = records.dataset.sid === student.id && previousHistoryOpen;
  records.dataset.sid = student.id;
  const ivs = sortedInterventions(data.interventions.filter(iv => iv.studentId === student.id));
  const active = ivs.filter(iv => iv.status === 'active');
  const done = ivs.filter(iv => iv.status !== 'active');
  const number = student.number == null || student.number === '' ? '' : ' ／ ' + student.number + '番';
  summary.textContent = `${student.name}さん ／ ${student.className || 'クラス未設定'}${number} ／ 実施中 ${active.length}件・完了 ${done.length}件`;
  $('trendSupportBody').hidden = false;
  $('trendAddSupport').disabled = false;
  const recordHtml = iv => `<article class="individual-support-record" data-iv="${esc(iv.id)}">
    <div class="individual-support-record-heading"><h4>${esc(iv.title)}</h4><span class="iv-status ${iv.status === 'active' ? 'active' : 'done'}">${iv.status === 'active' ? '実施中' : '完了'}</span></div>
    <p class="individual-support-meta">${esc(iv.subject === 'all' ? '全教科' : iv.subject)} ／ ${esc(TEST_KINDS[iv.kind] || '全種類')} ／ 開始 ${esc(iv.startDate || '未設定')}${iv.endDate ? ' ／ 完了 ' + esc(iv.endDate) : ''}</p>
    ${iv.note ? `<p class="individual-support-note">${esc(iv.note)}</p>` : ''}
    <div class="individual-support-actions">
      ${iv.status === 'active' ? `<button type="button" class="btn btn-ghost btn-sm iv-done-btn" data-iv="${esc(iv.id)}">完了にする</button>` : `<button type="button" class="btn btn-ghost btn-sm iv-reopen-btn" data-iv="${esc(iv.id)}">再開</button>`}
      <button type="button" class="btn btn-ghost btn-sm iv-progress-btn" data-iv="${esc(iv.id)}">RTIで推移を見る</button>
    </div></article>`;
  records.innerHTML = `<h4 class="individual-support-list-title">実施中の支援</h4>${active.length ? active.map(recordHtml).join('') : '<p class="card-note">実施中の支援はありません。</p>'}
    ${done.length ? `<details class="individual-support-history" ${keepHistoryOpen ? 'open' : ''}><summary>完了した支援（${done.length}件）</summary>${done.map(recordHtml).join('')}</details>` : ''}`;
}

// 回の合計は全教科が入力済みのときだけ有効。一覧と推移で同じ判定を使う。
function completeTermTotal(sid, tests) {
  if (!tests.length) return null;
  let sum = 0;
  for (const t of tests) {
    const r = getAttendedScore(sid, t.id);
    if (!r || r.absent || r.total == null) return null;
    sum += r.total;
  }
  return sum;
}

// 個人推移の横軸定義：教科別はその教科のテスト、全教科合計は同じ回
// （実施学年＋テスト名）でまとめる。どちらも回の時間順（1年→2年→3年）に並ぶ
function trendAxis() {
  const subj = ui.trendSubject;
  const selectedTests = data.tests.filter(t => testKindMatches(t, ui.trendKind));
  if (subj === SUM_KEY) {
    const keys = termOrderedList(selectedTests);
    const byKey = new Map(keys.map((k) => [k, []]));
    for (const t of selectedTests) byKey.get(termKeyOf(t)).push(t);
    return {
      labels: keys,
      yName: '合計点',
      valueOf: (sid) => keys.map((k) => completeTermTotal(sid, byKey.get(k))),
    };
  }
  const tests = sortTestsByTerm(selectedTests.filter((t) => t.subject === subj));
  return {
    labels: tests.map(termKeyOf),
    yName: '得点',
    valueOf: (sid) => tests.map((t) => {
      const r = getAttendedScore(sid, t.id);
      return r && r.total != null ? r.total : null;
    }),
  };
}

function renderTrendChart() {
  const axis = trendAxis();
  const selected = [...ui.trendSelected]
    .map((sid) => data.students.find((s) => s.id === sid))
    .filter(Boolean);

  const series = selected.map((s, i) => ({
    name: s.name,
    type: 'line',
    symbol: 'circle',
    symbolSize: 8,
    connectNulls: true,
    data: axis.valueOf(s.id),
    itemStyle: { color: PALETTE[i % PALETTE.length] },
  }));

  // クラス平均（フィルタ中のクラス範囲）
  const scope = studentsOf(ui.trendClass);
  const scopeVals = scope.map((s) => axis.valueOf(s.id));
  series.push({
    name: ui.trendClass === 'all' ? '全体平均' : `${ui.trendClass}平均`,
    type: 'line',
    symbol: 'none',
    lineStyle: { type: 'dashed', color: AVG_COLOR, width: 2 },
    itemStyle: { color: AVG_COLOR },
    connectNulls: true,
    data: axis.labels.map((_, idx) => {
      const vals = scopeVals.map((arr) => arr[idx]).filter((v) => v != null);
      return vals.length ? round1(mean(vals)) : null;
    }),
  });

  // どの系列にも値がない回は表示しない（例：1年生にはまだ2・3年時の回が無い）
  let labels = axis.labels;
  const used = labels.map((_, i) => series.some((sr) => sr.data[i] != null));
  if (used.some((u) => !u)) {
    labels = labels.filter((_, i) => used[i]);
    for (const sr of series) sr.data = sr.data.filter((_, i) => used[i]);
  }

  chart('trendChart').setOption({
    grid: { ...BASE_GRID, top: 50, bottom: labels.length > 6 ? 60 : 40 },
    tooltip: { trigger: 'axis' },
    legend: { top: 0, type: 'scroll' },
    xAxis: { type: 'category', data: labels, boundaryGap: false, axisLabel: { rotate: labels.length > 6 ? 30 : 0, fontSize: 11 } },
    yAxis: { type: 'value', name: axis.yName },
    series,
  }, true);

  const card = $('trendChart').closest('.card');
  const subjLabel = ui.trendSubject === SUM_KEY ? '全教科合計' : ui.trendSubject;
  card.querySelector('h3').textContent = selected.length
    ? `得点の推移：${subjLabel}（クラス平均と比較）`
    : `得点の推移：${subjLabel} — 左の名簿から生徒を選択してください`;
}

// 1名選択時のみ：分野別得点率の推移（教科別のみ。5教科合計では非表示）
function renderTrendDomainChart() {
  const card = $('trendDomainCard');
  if (ui.trendSelected.size !== 1 || ui.trendSubject === SUM_KEY) {
    card.hidden = true;
    return;
  }
  const sid = [...ui.trendSelected][0];
  const student = data.students.find((s) => s.id === sid);
  if (!student) { card.hidden = true; return; }
  const subjectTests = sortTestsByTerm(data.tests.filter((t) => t.subject === ui.trendSubject && testKindMatches(t, ui.trendKind)));
  card.hidden = false;
  $('trendDomainTitle').textContent = `${student.name}さんの分野別 得点率の推移（${ui.trendSubject}）`;

  // 当該教科の分野キーを集約（同一keyは同一分野とみなす）
  const keyLabel = new Map();
  for (const t of subjectTests) for (const d of testDomains(t)) {
    if (!keyLabel.has(d.key)) keyLabel.set(d.key, d.label);
  }

  const series = [...keyLabel].map(([key, label], i) => ({
    name: label,
    type: 'line',
    symbol: 'circle',
    symbolSize: 8,
    connectNulls: true,
    data: subjectTests.map((t) => {
      const r = getAttendedScore(sid, t.id);
      if (!r || !r.domains || r.domains[key] == null) return null;
      const max = domainMax(t, key);
      return max ? round1(r.domains[key] / max * 100) : null;
    }),
    itemStyle: { color: PALETTE[i % PALETTE.length] },
  }));

  // 本人にデータがない回は表示しない
  let dLabels = subjectTests.map(termKeyOf);
  const dUsed = dLabels.map((_, i) => series.some((sr) => sr.data[i] != null));
  if (dUsed.some((u) => !u)) {
    dLabels = dLabels.filter((_, i) => dUsed[i]);
    for (const sr of series) sr.data = sr.data.filter((_, i) => dUsed[i]);
  }

  chart('trendDomainChart').setOption({
    grid: { ...BASE_GRID, top: 50, bottom: dLabels.length > 6 ? 60 : 40 },
    tooltip: { trigger: 'axis', valueFormatter: (v) => v + '%' },
    legend: { top: 0 },
    xAxis: { type: 'category', data: dLabels, boundaryGap: false, axisLabel: { rotate: dLabels.length > 6 ? 30 : 0, fontSize: 11 } },
    yAxis: { type: 'value', max: 100, name: '得点率%' },
    series,
  }, true);
}

/* ========== 分野・問題分析タブ ========== */
function renderAnalysis() {
  const test = testById(ui.anTest);
  const banner = $('weakBanner');
  if (!test) {
    banner.hidden = true;
    return;
  }
  const students = studentsOf(ui.anClass);

  const axis = ui.anAxis || 'domain';
  $('anClassificationAxis').value = axis;
  $('anClassificationTitle').textContent = (axis === 'perspective' ? '評価の観点別' : '分野別') + ' 平均得点率';
  const summary = window.GD_CLASSIFICATION.summarize(test, students.map(s => getAttendedScore(s.id, test.id)), axis).filter(g => axis !== 'perspective' || g.key);
  const unassigned = (test.questions || []).filter(q => axis === 'perspective' ? !q.perspective : !q.domain).length;
  $('anClassificationSummary').textContent = !test.questions?.length
    ? '合計点のみのテストです。観点別の集計には、小問または採点する内訳ごとの点数が必要です。'
    : `${test.questions.length}項目 ／ ${axis === 'perspective' ? '観点' : '分野'}未設定 ${unassigned}項目・${(test.questions || []).filter(q => axis === 'perspective' ? !q.perspective : !q.domain).reduce((sum, q) => sum + q.max, 0)}点分。${axis === 'perspective' ? '観点未設定の項目は観点別の得点率に含めません。' : ''}総合点は重複して加算しません。`;
  const { domains, rates } = renderDomainBar('anDomainChart', test, students, true, axis);
  $('anClassificationTable').innerHTML = summary.length ? `<table class="data-table classification-table"><caption>${axis === 'perspective' ? '評価の観点' : '分野'}ごとの集計</caption><thead><tr><th>分類</th><th>項目数</th><th>満点</th><th>集計人数</th><th>平均得点率</th></tr></thead><tbody>${summary.map(g => `<tr><th scope="row">${esc(g.label)}</th><td>${g.count}</td><td>${esc(g.max)}点</td><td>${g.n}名</td><td>${g.rate == null ? '—' : round1(g.rate) + '%'}</td></tr>`).join('')}</tbody></table>` : '';
  const qResult = renderQuestionBar(test, students);
  renderQuestionBox(test, students);

  // 弱点バナー
  const validD = domains.map((d, i) => ({ d, r: rates[i] })).filter((x) => x.r != null);
  const validQ = qResult.filter((x) => x.rate != null);
  if (validD.length || validQ.length) {
    let msg = '';
    if (validD.length) {
      const weak = validD.reduce((a, b) => (a.r <= b.r ? a : b));
      msg += `得点率が最も低い${axis === 'perspective' ? '観点' : '分野'}は <strong>${esc(weak.d.label)}</strong>（平均得点率 ${weak.r}%）`;
    }
    if (validQ.length) {
      const weakQ = validQ.reduce((a, b) => (a.rate <= b.rate ? a : b));
      msg += `${msg ? '、' : ''}最も正答率が低い問題は <strong>${esc(weakQ.label)}</strong>（${weakQ.rate}%）`;
    }
    msg = '📌 ' + msg + ' です。';

    // 前回テスト比：分野ごとの伸びを効果量で（同じ分野キーを持つ直前テストと比較）
    const prev = comparisonTarget(test);
    if (prev && axis === 'domain') {
      const moves = [];
      for (const d of testDomains(test)) {
        const prevMax = domainMax(prev, d.key);
        const curMax = domainMax(test, d.key);
        if (!prevMax || !curMax) continue;
        const pairs = [];
        for (const s of students) {
          const a = getAttendedScore(s.id, prev.id);
          const b = getAttendedScore(s.id, test.id);
          if (a && a.domains && a.domains[d.key] != null && b && b.domains && b.domains[d.key] != null) {
            pairs.push([a.domains[d.key] / prevMax * 100, b.domains[d.key] / curMax * 100]);
          }
        }
        if (pairs.length >= 5) {
          const dz = pairedCohensDz(pairs);
          if (dz != null) moves.push({ label: d.label, d: dz, n: pairs.length });
        }
      }
      if (moves.length) {
        const biggest = moves.reduce((a, b) => Math.abs(a.d) >= Math.abs(b.d) ? a : b);
        const line = `<br>比較：${esc(termKeyOf(prev))}。得点率の差が大きい分野：<strong>${esc(biggest.label)}</strong>（両方受験${biggest.n}名・効果量 dz=${esFmt(biggest.d)}、参考値）。範囲・難しさの違いも含む得点の変化です。<span class="es-link">効果量とは？</span>`;
        msg += line;
      }
    }

    banner.innerHTML = msg;
    banner.hidden = false;
  } else {
    banner.hidden = true;
  }
}

function renderQuestionBar(test, students) {
  const qs = test.questions || [];
  const result = qs.map((q) => {
    const vals = students.map((s) => getAttendedScore(s.id, test.id))
      .filter((r) => r && r.questions && r.questions[q.key] != null)
      .map((r) => r.questions[q.key] / q.max * 100);
    return { label: q.label, rate: vals.length ? round1(mean(vals)) : null };
  });
  const minRate = Math.min(...result.filter((x) => x.rate != null).map((x) => x.rate));
  chart('anQuestionChart').setOption({
    grid: BASE_GRID,
    tooltip: { trigger: 'axis', valueFormatter: (v) => v + '%' },
    xAxis: { type: 'category', data: result.map((x) => x.label), axisLabel: { rotate: 20, fontSize: 11 } },
    yAxis: { type: 'value', max: 100, name: '得点率%' },
    series: [{
      type: 'bar',
      data: result.map((x) => ({
        value: x.rate,
        itemStyle: {
          color: x.rate === minRate ? '#c0392b' : PALETTE[0],
          borderRadius: [4, 4, 0, 0],
        },
      })),
      barWidth: '55%',
      label: { show: true, position: 'top', formatter: '{c}%' },
    }],
  }, true);
  return result;
}

function formatBoxTooltip(params) {
  const values = Array.isArray(params.data) ? params.data : params.value;
  if (!Array.isArray(values) || values[0] == null) return params.name + ': データ不足';
  const [min, q1, med, q3, max] = values;
  return `${params.name}<br>最小 ${min}% ／ 第1四分位 ${q1}%<br>中央値 ${med}%<br>第3四分位 ${q3}% ／ 最大 ${max}%`;
}

function renderQuestionBox(test, students) {
  const qs = test.questions || [];
  const boxData = [];
  const labels = [];
  for (const q of qs) {
    const vals = students.map((s) => getAttendedScore(s.id, test.id))
      .filter((r) => r && r.questions && r.questions[q.key] != null)
      .map((r) => r.questions[q.key] / q.max * 100)
      .sort((a, b) => a - b);
    labels.push(q.label);
    if (vals.length < 4) {
      boxData.push([null, null, null, null, null]);
      continue;
    }
    boxData.push([
      round1(vals[0]),
      round1(quantile(vals, 0.25)),
      round1(quantile(vals, 0.5)),
      round1(quantile(vals, 0.75)),
      round1(vals[vals.length - 1]),
    ]);
  }
  chart('anBoxChart').setOption({
    grid: BASE_GRID,
    tooltip: {
      trigger: 'item',
      formatter: formatBoxTooltip,
    },
    xAxis: { type: 'category', data: labels, axisLabel: { rotate: 20, fontSize: 11 } },
    yAxis: { type: 'value', max: 100, name: '得点率%' },
    series: [{
      type: 'boxplot',
      data: boxData,
      itemStyle: { color: '#dceaf7', borderColor: PALETTE[0] },
    }],
  }, true);
}

/* ========== 相関分析タブ ========== */
function metricById(mid) {
  return data.metrics.find((m) => m.id === mid) || null;
}

// 軸の選択肢：テスト合計とすべての指標
function fillAxisSelects() {
  const opts =
    data.metrics.map((m) => `<option value="m:${esc(m.id)}">${esc(m.label)}［${metricKindLabel(m)}］</option>`).join('') +
    data.tests.map((t) => `<option value="t:${esc(t.id)}">${esc(termKeyOf(t))}・${esc(t.subject)}（合計）</option>`).join('');
  for (const [sel, val] of [[$('corrX'), ui.corrX], [$('corrY'), ui.corrY]]) {
    sel.innerHTML = opts;
    if (val && [...sel.options].some((o) => o.value === val)) sel.value = val;
  }
  ui.corrX = $('corrX').value;
  ui.corrY = $('corrY').value;
}

// 指標の種類ラベル（画面表示用）
function metricKindLabel(m) {
  return m.type === 'scale' ? '5段階' : '数値';
}

function fillMetricSelect() {
  const sel = $('metricSel');
  sel.innerHTML = data.metrics.map((m) =>
    `<option value="${esc(m.id)}">${esc(m.label)}［${metricKindLabel(m)}］</option>`).join('');
  if (ui.metricId && metricById(ui.metricId)) sel.value = ui.metricId;
  ui.metricId = sel.value;
}

// 軸指定（"m:id" / "t:id"）から値の取得関数を作る
function axisInfo(v) {
  if (!v) return null;
  const [kind, id] = [v.slice(0, 1), v.slice(2)];
  if (kind === 'm') {
    const m = metricById(id);
    if (!m) return null;
    return {
      label: m.label,
      isScale: m.type === 'scale',
      get: (sid) => {
        const raw = m.values ? m.values[sid] : null;
        return raw == null || raw === '' ? null : Number(raw);
      },
    };
  }
  const t = testById(id);
  if (!t) return null;
  return {
    label: `${termKeyOf(t)}・${t.subject}（合計）`,
    isScale: false,
    get: (sid) => {
      const r = getAttendedScore(sid, t.id);
      return r && r.total != null ? r.total : null;
    },
  };
}

function pearson(pairs) {
  const n = pairs.length;
  if (n < 3) return null;
  const mx = mean(pairs.map((p) => p[0]));
  const my = mean(pairs.map((p) => p[1]));
  let sxy = 0, sxx = 0, syy = 0;
  for (const [x, y] of pairs) {
    sxy += (x - mx) * (y - my);
    sxx += (x - mx) ** 2;
    syy += (y - my) ** 2;
  }
  if (!sxx || !syy) return null;
  return sxy / Math.sqrt(sxx * syy);
}

function corrStrength(r) {
  const a = Math.abs(r);
  const dir = r > 0 ? '正' : '負';
  if (a >= 0.7) return `強い${dir}の相関`;
  if (a >= 0.4) return `中程度の${dir}の相関`;
  if (a >= 0.2) return `弱い${dir}の相関`;
  return 'ほとんど相関なし';
}

// 教員向けの平易な解釈文
function corrInterpretation(xLabel, yLabel, r) {
  const a = Math.abs(r);
  if (a < 0.2) return `${xLabel} と ${yLabel} には、はっきりした関係は見られません。`;
  const adv = a >= 0.7 ? 'はっきりと' : a >= 0.4 ? 'ある程度' : 'ゆるやかに';
  const yDir = r > 0 ? '高い' : '低い';
  return `${xLabel}が大きい生徒ほど ${yLabel} が${yDir}傾向が、${adv}見られます。（あくまで傾向で、例外もあります）`;
}

// 離散値（5段階など）の点が重ならないよう、生徒IDから安定した微小ズレを作る
function jitterFor(sid) {
  let h = 0;
  for (let i = 0; i < sid.length; i++) h = (h * 31 + sid.charCodeAt(i)) >>> 0;
  return ((h % 1000) / 1000 - 0.5) * 0.36;
}

function renderMetricsTab() {
  renderMetricTable();
  renderCorrelation();
}

function renderCorrelation() {
  const x = axisInfo(ui.corrX);
  const y = axisInfo(ui.corrY);
  const banner = $('corrBanner');
  if (!x || !y) {
    banner.hidden = true;
    chart('corrChart').clear();
    return;
  }

  const scope = studentsOf(ui.metClass);
  const jx = !!x.isScale, jy = !!y.isScale;
  const points = []; // {x,y,name,className}（xyは実値）
  const byClass = new Map();
  for (const s of scope) {
    const xv = x.get(s.id);
    const yv = y.get(s.id);
    if (xv == null || yv == null || isNaN(xv) || isNaN(yv)) continue;
    points.push({ x: xv, y: yv, name: s.name, className: s.className || '' });
    const k = s.className || '（クラスなし）';
    if (!byClass.has(k)) byClass.set(k, []);
    // 離散値は描画座標にジッターを足す（ツールチップは実値 ox/oy を表示）
    byClass.get(k).push({
      value: [xv + (jx ? jitterFor(s.id) : 0), yv + (jy ? jitterFor(s.id) : 0)],
      ox: xv, oy: yv, name: s.name,
    });
  }

  const series = [...byClass].map(([klass, pts], i) => ({
    name: klass,
    type: 'scatter',
    symbolSize: 11,
    data: pts,
    itemStyle: { color: PALETTE[i % PALETTE.length], opacity: 0.7 },
  }));

  const r = pearson(points.map((p) => [p.x, p.y]));
  let mx = null, my = null, slope = 0;
  if (r != null) {
    const xs = points.map((p) => p.x);
    const ys = points.map((p) => p.y);
    mx = mean(xs); my = mean(ys);
    const sx = Math.sqrt(mean(xs.map((v) => (v - mx) ** 2)));
    const sy = Math.sqrt(mean(ys.map((v) => (v - my) ** 2)));
    slope = r * sy / sx;
    const x0 = Math.min(...xs), x1 = Math.max(...xs);
    // 傾向線＋平均の十字線
    series.push({
      name: '傾向線',
      type: 'line',
      symbol: 'none',
      silent: true,
      lineStyle: { type: 'dashed', color: AVG_COLOR, width: 2 },
      itemStyle: { color: AVG_COLOR },
      data: [[x0, my + slope * (x0 - mx)], [x1, my + slope * (x1 - mx)]],
      markLine: {
        silent: true,
        symbol: 'none',
        lineStyle: { type: 'dashed', color: '#cfd3dc', width: 1 },
        label: { formatter: '平均', color: CHART_TEXT, fontSize: 10 },
        data: [{ xAxis: round1(mx) }, { yAxis: round1(my) }],
      },
    });
  }

  chart('corrChart').setOption({
    grid: { ...BASE_GRID, top: 50, left: 60 },
    tooltip: {
      trigger: 'item',
      formatter: (p) => {
        if (p.seriesName === '傾向線') return '';
        const d = p.data || {};
        return `<strong>${esc(p.name)}</strong>（${esc(p.seriesName)}）<br>${esc(x.label)}: ${d.ox}<br>${esc(y.label)}: ${d.oy}`;
      },
    },
    legend: { top: 0, type: 'scroll' },
    xAxis: { type: 'value', name: x.label, nameLocation: 'middle', nameGap: 28, scale: true },
    yAxis: { type: 'value', name: y.label, scale: true },
    series,
  }, true);

  // バナー：係数＋強さバー＋平易な解釈
  if (r == null) {
    banner.innerHTML = `データが足りません（両方の値がある生徒が3名以上必要です。現在 ${points.length} 名）`;
    banner.hidden = false;
  } else {
    const rTxt = `${r >= 0 ? '+' : ''}${(Math.round(r * 100) / 100).toFixed(2)}`;
    const pct = Math.round(Math.abs(r) * 100);
    const barColor = Math.abs(r) >= 0.7 ? 'var(--primary)' : Math.abs(r) >= 0.4 ? 'var(--warn)' : 'var(--text-faint)';
    banner.innerHTML =
      `<div class="corr-head"><strong>${esc(x.label)} × ${esc(y.label)}</strong>　相関係数 <strong>r = ${rTxt}</strong></div>` +
      `<div class="corr-strength"><div class="corr-bar"><span style="width:${pct}%;background:${barColor}"></span></div>` +
      `<span class="corr-strength-label">${corrStrength(r)}・対象 ${points.length} 名</span></div>` +
      `<div class="corr-interp">${esc(corrInterpretation(x.label, y.label, r))}</div>`;
    banner.hidden = false;
  }

  renderCorrOutliers(points, x, y, r, mx, my, slope);
  renderChiSquare(points, x, y);
}

// 傾向線から外れる生徒を抽出して表示
function renderCorrOutliers(points, x, y, r, mx, my, slope) {
  const card = $('corrOutlierCard');
  // 明確な傾向があるときだけ意味を持つ
  if (r == null || Math.abs(r) < 0.2 || points.length < 5) {
    card.hidden = true;
    return;
  }
  const withRes = points.map((p) => ({ ...p, res: p.y - (my + slope * (p.x - mx)) }));
  const sd = Math.sqrt(mean(withRes.map((p) => p.res ** 2))) || 1;
  const thr = sd * 1.2;
  const below = withRes.filter((p) => p.res <= -thr).sort((a, b) => a.res - b.res).slice(0, 6);
  const above = withRes.filter((p) => p.res >= thr).sort((a, b) => b.res - a.res).slice(0, 6);

  if (!below.length && !above.length) {
    card.hidden = true;
    return;
  }
  const chip = (p) => `<span class="outlier-chip">${esc(p.name)}<small>${esc(p.className)}</small></span>`;
  let html = '';
  if (below.length) {
    html += `<div class="outlier-col"><div class="outlier-head outlier-low">${esc(x.label)}の割に ${esc(y.label)} が低い</div>` +
      `<div class="outlier-chips">${below.map(chip).join('')}</div></div>`;
  }
  if (above.length) {
    html += `<div class="outlier-col"><div class="outlier-head outlier-high">${esc(x.label)}の割に ${esc(y.label)} が高い</div>` +
      `<div class="outlier-chips">${above.map(chip).join('')}</div></div>`;
  }
  $('corrOutliers').innerHTML = html;
  card.hidden = false;
}

/* ---- 指標の入力 ---- */
function renderMetricTable() {
  const wrap = $('metricTableWrap');
  const m = metricById(ui.metricId);
  $('deleteMetricBtn').disabled = !m;

  if (!m) {
    wrap.innerHTML = '<div class="table-empty">指標がありません。「＋ 指標を追加」から登録してください。</div>';
    return;
  }
  if (!m.values) m.values = {};

  const isScale = m.type === 'scale';
  const students = studentsOf(ui.metClass);
  let html = '<table class="score-table"><thead><tr>';
  html += `<th>No.</th><th style="text-align:left">氏名</th><th>クラス</th>`;
  html += `<th>${esc(m.label)}<span class="th-max">${isScale ? '5段階（1〜5）' : '数値'}</span></th>`;
  html += '</tr></thead><tbody>';
  students.forEach((s, rowIdx) => {
    const v = m.values[s.id];
    html += `<tr>
      <td class="cell-no">${esc(s.number != null && s.number !== '' ? s.number : rowIdx + 1)}</td>
      <td class="cell-name">${esc(s.name)}</td>
      <td class="cell-class">${esc(s.className || '')}</td>
      <td><input class="cell-input metric-input" type="number" ${isScale ? 'min="1" max="5" step="1"' : 'step="any"'}
        data-row="${rowIdx}" data-sid="${esc(s.id)}" value="${v != null ? v : ''}"></td>
    </tr>`;
  });
  html += '</tbody></table>';
  if (!students.length) html = '<div class="table-empty">生徒がいません。</div>';
  wrap.innerHTML = html;
}

function handleMetricInput(input) {
  const m = metricById(ui.metricId);
  if (!m) return;
  if (!m.values) m.values = {};
  const sid = input.dataset.sid;
  const raw = input.value.trim();
  const value = raw === '' ? null : Number(raw);
  const valid = value === null || validMetricValue(m.type, value);
  input.classList.toggle('is-over', !valid);
  input.setAttribute('aria-invalid', String(!valid));
  input.title = valid ? '' : (m.type === 'scale' ? '1〜5の整数で入力してください' : '数値を入力してください');
  if (!valid) return;
  if (value === null) {
    delete m.values[sid];
  } else {
    m.values[sid] = value;
  }
  markDirty();
  renderCorrelation();
}

// 縦1列貼り付け（起点から下方向）
function handleMetricPaste(e, input) {
  const text = (e.clipboardData || window.clipboardData).getData('text');
  if (!text || !text.includes('\n')) return;
  e.preventDefault();
  const m = metricById(ui.metricId);
  if (!m) return;
  if (!m.values) m.values = {};
  const students = studentsOf(ui.metClass);
  const startRow = Number(input.dataset.row);
  const rows = text.replace(/\r/g, '').split('\n');
  let invalidCount = 0, changed = false;
  rows.forEach((rowText, ri) => {
    const s = students[startRow + ri];
    if (!s) return;
    const v = rowText.split('\t')[0].trim();
    if (v === '') return;
    const num = Number(v);
    if (!validMetricValue(m.type, num)) {
      invalidCount++;
      return;
    }
    m.values[s.id] = num;
    changed = true;
  });
  if (changed) markDirty();
  renderMetricTable();
  renderCorrelation();
  if (invalidCount) alert(`不正な値 ${invalidCount}件は取り込みませんでした。${m.type === 'scale' ? '5段階は1〜5の整数で入力してください。' : '数値を入力してください。'}`);
}

function submitMetricDialog(e) {
  e.preventDefault();
  const m = {
    id: 'm' + Date.now(),
    label: $('mfLabel').value.trim(),
    type: $('mfType').value,
    values: {},
  };
  data.metrics.push(m);
  ui.metricId = m.id;
  ui.corrX = 'm:' + m.id;
  markDirty();
  $('metricDialog').close();
  fillAxisSelects();
  fillMetricSelect();
  renderMetricsTab();
  resizeCharts();
}

function deleteCurrentMetric() {
  if (!requireAdmin()) return;
  const m = metricById(ui.metricId);
  if (!m) return;
  if (!confirm(`指標「${m.label}」と入力済みの値をすべて削除します。よろしいですか？`)) return;
  data.metrics = data.metrics.filter((x) => x.id !== m.id);
  ui.metricId = data.metrics.length ? data.metrics[0].id : '';
  if (ui.corrX === 'm:' + m.id) ui.corrX = data.metrics.length ? 'm:' + data.metrics[0].id : '';
  if (ui.corrY === 'm:' + m.id) ui.corrY = '';
  markDirty();
  fillAxisSelects();
  fillMetricSelect();
  renderMetricsTab();
  resizeCharts();
}

/* ========== データ一覧タブ ========== */
// クラス名の先頭数字を学年として扱う（例：2B → 2）
function gradeOf(s) {
  const m = (s.className || '').match(/^\d+/);
  return m ? m[0] : '';
}

function gradeList() {
  return [...new Set(data.students.map(gradeOf).filter(Boolean))].sort();
}

function listScopedTests() {
  return sortTestsByTerm(data.tests.filter((t) =>
    (ui.listSubject === 'all' || t.subject === ui.listSubject) &&
    (ui.listTerm === 'all' || termKeyOf(t) === ui.listTerm)));
}

function fillListGradeSelect() {
  const sel = $('listGrade');
  sel.innerHTML = `<option value="all">全学年</option>` +
    gradeList().map((g) => `<option value="${esc(g)}">${esc(g)}年</option>`).join('');
  sel.value = gradeList().includes(ui.listGrade) ? ui.listGrade : 'all';
  ui.listGrade = sel.value;
}

function fillListTermSelect() {
  const sel = $('listTerm');
  sel.innerHTML = `<option value="all">全テスト</option>` +
    termOrderedList().map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join('');
  sel.value = termOrderedList().includes(ui.listTerm) ? ui.listTerm : 'all';
  ui.listTerm = sel.value;
}

// クラスの選択肢は選択中の学年に絞る
function fillListClassSelect() {
  const sel = $('listClass');
  const classes = classList().filter((c) => ui.listGrade === 'all' || c.startsWith(ui.listGrade));
  sel.innerHTML = `<option value="all">全クラス</option>` +
    classes.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join('');
  if (!classes.includes(ui.listClass)) ui.listClass = 'all';
  sel.value = ui.listClass;
}

// 一覧の列定義
function listColumns() {
  const cols = [
    { key: 'number', label: 'No.', kind: 'meta' },
    { key: 'name', label: '氏名', kind: 'name' },
    { key: 'className', label: 'クラス', kind: 'meta' },
  ];
  for (const t of listScopedTests()) cols.push({ key: 't:' + t.id, label: `${esc(termKeyOf(t))}<span class="th-sub">${esc(t.subject)}</span>`, kind: 'test', test: t });
  // 特定の回を選び全教科を表示しているときは、その回の合計列（例：500点満点）を出す
  if (ui.listTerm !== 'all' && ui.listSubject === 'all') {
    const termTests = listScopedTests();
    const maxSum = termTests.reduce((a, t) => a + (t.maxScore || 0), 0);
    if (termTests.length >= 2 && maxSum > 0) {
      cols.push({ key: 'termTotal', label: `合計<span class="th-sub">/${maxSum}</span>`, kind: 'termTotal', tests: termTests, maxSum });
    }
  }
  for (const m of data.metrics) cols.push({ key: 'm:' + m.id, label: esc(m.label), kind: 'metric', metric: m });
  cols.push({ key: 'avg', label: '平均', kind: 'avg' });
  return cols;
}

// セルの値 {raw, rate, absent}（rawは点／指標値、rateは得点率）
function listCell(col, s) {
  if (col.kind === 'test') {
    const raw = getScore(s.id, col.test.id);
    if (raw?.absent) return { absent: true };
    const r = getAttendedScore(s.id, col.test.id);
    if (!r || r.total == null) return {};
    return { raw: r.total, rate: r.total / col.test.maxScore * 100 };
  }
  if (col.kind === 'metric') {
    const v = col.metric.values ? col.metric.values[s.id] : null;
    return v == null || v === '' ? {} : { raw: Number(v), metric: true };
  }
  if (col.kind === 'termTotal') {
    // 回の合計：全教科の点がそろっている生徒のみ表示（欠席・未入力が混ざると満点比が歪むため）
    const sum = completeTermTotal(s.id, col.tests);
    return sum == null ? {} : { raw: sum, rate: sum / col.maxSum * 100 };
  }
  if (col.kind === 'avg') {
    const totals = [], rates = [];
    for (const t of listScopedTests()) {
      const r = getAttendedScore(s.id, t.id);
      if (r && !r.absent && r.total != null) { totals.push(r.total); rates.push(r.total / t.maxScore * 100); }
    }
    if (!totals.length) return {};
    return { raw: round1(mean(totals)), rate: round1(mean(rates)) };
  }
  return {};
}

// 得点率→ヒートマップ色。基準点を境に 赤（低い）↔ ほぼ白 ↔ ティール（高い）のダイバージング配色。
// 赤緑の組み合わせを避け、色覚多様性でも読み分けられる（セルには数値も併記される）
function heatColor(rate, pivot) {
  const r = Math.max(0, Math.min(100, rate));
  const p = Math.max(1, Math.min(99, pivot == null ? 60 : pivot)); // 0/100は割り算回避
  if (r < p) {
    const t = (p - r) / p; // 基準点からの離れ具合 0..1
    return `hsl(354, 62%, ${Math.round(97 - t * 15)}%)`;  // 赤系：離れるほど濃く
  }
  const t = (r - p) / (100 - p);
  return `hsl(174, 45%, ${Math.round(97 - t * 15)}%)`;    // ティール系：離れるほど濃く
}

function listSortedStudents() {
  let base = studentsOf(ui.listClass);
  if (ui.listGrade !== 'all') base = base.filter((s) => gradeOf(s) === ui.listGrade);
  if (!ui.listSort) return base;
  const { key, dir } = ui.listSort;
  const col = listColumns().find((c) => c.key === key);
  const arr = [...base];
  if (key === 'name') {
    arr.sort((a, b) => a.name.localeCompare(b.name, 'ja'));
    if (dir === 'desc') arr.reverse();
    return arr;
  }
  if (key === 'className') {
    arr.sort((a, b) => (a.className || '').localeCompare(b.className || '', 'ja') || studentNumber(a) - studentNumber(b));
    if (dir === 'desc') arr.reverse();
    return arr;
  }
  if (key === 'number') {
    arr.sort((a, b) => studentNumber(a) - studentNumber(b));
    if (dir === 'desc') arr.reverse();
    return arr;
  }
  // スコア系：値あり／なしを分け、値ありだけ並べ替え、なし（欠席・未入力）は常に末尾
  if (!col) return arr;
  const withVal = [], noVal = [];
  for (const s of arr) (listCell(col, s).raw == null ? noVal : withVal).push(s);
  withVal.sort((a, b) => listCell(col, a).raw - listCell(col, b).raw);
  if (dir === 'desc') withVal.reverse();
  return [...withVal, ...noVal];
}

function renderList() {
  const wrap = $('listTableWrap');
  const cols = listColumns();
  const students = listSortedStudents();
  const pct = ui.listMode === 'rate';

  let html = '<table class="score-table list-table"><thead><tr>';
  for (const c of cols) {
    const sorted = ui.listSort && ui.listSort.key === c.key;
    const arrow = sorted ? (ui.listSort.dir === 'asc' ? ' ▲' : ' ▼') : '';
    const cls = ['list-th', c.kind === 'name' ? 'th-name' : '', sorted ? 'is-sorted' : ''].filter(Boolean).join(' ');
    html += `<th class="${cls}" data-key="${esc(c.key)}">${c.label}${arrow}</th>`;
  }
  html += '</tr></thead><tbody>';

  for (const s of students) {
    html += '<tr>';
    for (const c of cols) {
      if (c.kind === 'meta' && c.key === 'number') {
        html += `<td class="cell-no">${esc(s.number != null && s.number !== '' ? s.number : '')}</td>`;
      } else if (c.kind === 'name') {
        html += `<td class="cell-name">${esc(s.name)}</td>`;
      } else if (c.key === 'className') {
        html += `<td class="cell-class">${esc(s.className || '')}</td>`;
      } else {
        const cv = listCell(c, s);
        let text = '', style = '';
        if (cv.absent) {
          text = '<span class="list-absent">欠</span>';
        } else if (cv.raw == null) {
          text = '';
        } else if (c.kind === 'metric') {
          text = String(cv.raw);
        } else {
          text = pct ? round1(cv.rate) + '%' : String(cv.raw);
          if (ui.listHeat && cv.rate != null) style = ` style="background:${heatColor(cv.rate, ui.listPivot)}"`;
        }
        const strong = (c.kind === 'avg' || c.kind === 'termTotal') ? ' cell-strong' : '';
        html += `<td class="list-cell${strong}"${style}>${text}</td>`;
      }
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  if (!students.length) html = '<div class="table-empty">生徒がいません。</div>';
  wrap.innerHTML = html;
}

function handleListSort(key) {
  if (ui.listSort && ui.listSort.key === key) {
    ui.listSort.dir = ui.listSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    // スコア系は降順から、氏名/クラス/番号は昇順から
    const asc = (key === 'name' || key === 'className' || key === 'number');
    ui.listSort = { key, dir: asc ? 'asc' : 'desc' };
  }
  renderList();
}

function safeExcelRows(rows) {
  return rows.map(row => row.map(value => {
    if (value == null) return '';
    if (typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value))) return value;
    throw new Error('Excelに出力する値は文字列または有限な数値にしてください。');
  }));
}

function exportList() {
  if (typeof XLSX === 'undefined') { alert('Excel出力ライブラリの読み込みに失敗しました。'); return; }
  const cols = listColumns();
  const students = listSortedStudents();
  const pct = ui.listMode === 'rate';
  const header = cols.map((c) =>
    c.kind === 'test' ? `${termKeyOf(c.test)}(${c.test.subject})` :
    c.kind === 'termTotal' ? `合計(${c.maxSum}点満点)` :
    c.label.replace(/<[^>]*>/g, ''));
  const rows = [header];
  for (const s of students) {
    const row = [];
    for (const c of cols) {
      if (c.key === 'number') row.push(s.number != null ? s.number : '');
      else if (c.kind === 'name') row.push(s.name);
      else if (c.key === 'className') row.push(s.className || '');
      else {
        const cv = listCell(c, s);
        if (cv.absent) row.push('欠');
        else if (cv.raw == null) row.push('');
        else if (c.kind === 'metric') row.push(cv.raw);
        else row.push(pct ? round1(cv.rate) : cv.raw);
      }
    }
    rows.push(row);
  }
  const ws = XLSX.utils.aoa_to_sheet(safeExcelRows(rows));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'データ一覧');
  const cls = ui.listClass === 'all' ? '全クラス' : ui.listClass;
  const subj = ui.listSubject === 'all' ? '全教科' : ui.listSubject;
  XLSX.writeFile(wb, `データ一覧_${subj}_${cls}.xlsx`.replace(/[\\/:*?"<>|]/g, '_'));
}

/* ========== 権限（管理者モード） ========== */
function legacyPinHash(text) {
  // Preserve the exact representation written by earlier non-Web-Crypto environments.
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (const ch of text) {
    const c = ch.charCodeAt(0);
    h1 = Math.imul(h1 ^ c, 2654435761);
    h2 = Math.imul(h2 ^ c, 1597334677);
  }
  return (h1 >>> 0).toString(16) + (h2 >>> 0).toString(16);
}

function isLegacyPinHash(hash) {
  // Two unpadded, lower-case uint32 hexadecimal values, each 1–8 characters.
  // A multi-character component cannot start with zero.
  return typeof hash === 'string' && /^(?:0|[1-9a-f][0-9a-f]{0,7})(?:0|[1-9a-f][0-9a-f]{0,7})$/.test(hash);
}

function validPinHash(hash) {
  return typeof hash === 'string' && (/^[a-f0-9]{64}$/i.test(hash) || isLegacyPinHash(hash));
}

async function sha256Hex(text) {
  try {
    if (crypto && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
      return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch { /* 非セキュアコンテキスト等 → フォールバック */ }
  return legacyPinHash(text);
}

function updateRoleUI() {
  document.body.classList.toggle('is-admin', isAdmin);
  const btn = $('roleBtn');
  btn.textContent = isAdmin ? '管理者モード' : '教員モード';
  btn.classList.toggle('is-admin-badge', isAdmin);
  $('settingsBtn').hidden = !isAdmin;
  $('settingsBtn').disabled = !isAdmin;
  $('rosterBtn').disabled = !isAdmin || !data;
}

function requireAdmin() {
  if (isAdmin) return true;
  alert('この操作は管理者モードでのみ行えます。右上の「教員モード」から切り替えてください。');
  return false;
}

function openAdminDialog() {
  const hasPin = !!data.settings.adminPinHash;
  $('adminDialogNote').textContent = hasPin
    ? 'PINを入力すると、名簿管理・削除・設定などの管理機能が使えるようになります。'
    : 'PINが未設定です。最初のPIN（数字4〜8桁）を決めて入力してください。以後のPINは誤操作防止用です。JSONの暗号化やアクセス制限は行いません。';
  $('adminPinInput').value = '';
  $('adminDialog').showModal();
  $('adminPinInput').focus();
}

async function submitAdminDialog(e) {
  e.preventDefault();
  const pin = $('adminPinInput').value.trim();
  if (!/^\d{4,8}$/.test(pin)) { alert('PINは数字4〜8桁で入力してください。'); return; }
  const hash = await sha256Hex('gd-v2:' + pin);
  if (!data.settings.adminPinHash) {
    data.settings.adminPinHash = hash;
    markDirty();
    isAdmin = true;
    alert('PINを設定し、管理者モードに切り替えました。忘れないよう控えてください。');
  } else if (isLegacyPinHash(data.settings.adminPinHash)
    ? data.settings.adminPinHash === legacyPinHash('gd-v2:' + pin)
    : data.settings.adminPinHash.toLowerCase() === hash) {
    isAdmin = true;
  } else {
    alert('PINが違います。');
    return;
  }
  $('adminDialog').close();
  updateRoleUI();
  if (ui.tab === 'rti') renderRti();
}

/* ---- 設定（管理者） ---- */
function openSettingsDialog() {
  if (!requireAdmin()) return;
  $('setTier3').value = data.settings.rti.tier3;
  $('setTier2').value = data.settings.rti.tier2;
  $('setPin').value = '';
  $('settingsDialog').showModal();
}

async function submitSettingsDialog(e) {
  e.preventDefault();
  const t3 = parseInt($('setTier3').value, 10);
  const t2 = parseInt($('setTier2').value, 10);
  if (isNaN(t3) || isNaN(t2) || t3 < 1 || t2 > 99 || t3 >= t2) {
    alert('しきい値は「Tier 3 ＜ Tier 2」（例：40 と 60）になるように入力してください。');
    return;
  }
  data.settings.rti.tier3 = t3;
  data.settings.rti.tier2 = t2;
  const pin = $('setPin').value.trim();
  if (pin) {
    if (!/^\d{4,8}$/.test(pin)) { alert('PINは数字4〜8桁で入力してください。'); return; }
    data.settings.adminPinHash = await sha256Hex('gd-v2:' + pin);
  }
  markDirty();
  $('settingsDialog').close();
  if (ui.tab === 'rti') renderRti();
  else if (ui.tab === 'overview') renderOverview();
  else if (ui.tab === 'trend') renderTrendComparison();
}

/* ========== 支援（RTI）タブ ========== */
// テスト回ごとの得点率の系列を返す。
// 各テストは独立していて時系列ではないため、「全教科」のときは同じ回
// （前期中間など同名テスト）の教科をまとめて平均し、回の並びとして扱う
function termSeriesFor(sid, subject, kind = ui.rtiKind) {
  const subj = subject !== undefined ? subject : ui.rtiSubject;
  const selectedTests = data.tests.filter(t => testKindMatches(t, kind));
  if (subj !== 'all') {
    const tests = sortTestsByTerm(selectedTests.filter((t) => t.subject === subj));
    return {
      labels: tests.map(termKeyOf),
      rates: tests.map((t) => {
        const r = getAttendedScore(sid, t.id);
        return r && !r.absent && r.total != null && t.maxScore ? r.total / t.maxScore * 100 : null;
      }),
    };
  }
  // 全教科：同じ回（実施学年＋テスト名）でまとめて平均得点率
  const keys = termOrderedList(selectedTests);
  const byKey = new Map(keys.map((k) => [k, []]));
  for (const t of selectedTests) byKey.get(termKeyOf(t)).push(t);
  const rates = keys.map((k) => {
    const vals = [];
    for (const t of byKey.get(k)) {
      const r = getAttendedScore(sid, t.id);
      if (r && !r.absent && r.total != null && t.maxScore) vals.push(r.total / t.maxScore * 100);
    }
    return vals.length ? mean(vals) : null;
  });
  return { labels: keys, rates };
}

// 生徒の判定値（得点率%）と直近の前回比を返す（テスト回ベース）
function rtiRateFor(sid, subject, basis, kind = ui.rtiKind) {
  const vals = termSeriesFor(sid, subject, kind).rates.filter((v) => v != null);
  if (!vals.length) return { rate: null, delta: null };
  const useBasis = basis !== undefined ? basis : ui.rtiBasis;
  const rate = useBasis === 'avg' ? mean(vals) : vals[vals.length - 1];
  const subj = subject !== undefined ? subject : ui.rtiSubject;
  const latest = sortTestsByTerm(data.tests.filter(t => t.subject === subj && testKindMatches(t, kind)))
    .filter(t => getAttendedScore(sid, t.id)?.total != null).at(-1);
  const previous = comparisonTarget(latest);
  const previousScore = previous && getAttendedScore(sid, previous.id);
  const currentScore = latest && getAttendedScore(sid, latest.id);
  const delta = previousScore?.total != null ? currentScore.total / latest.maxScore * 100 - previousScore.total / previous.maxScore * 100 : null;
  return { rate, delta, comparison: previous ? termKeyOf(previous) : '' };
}

function rtiTierOf(rate) {
  if (rate == null) return null;
  const { tier2, tier3 } = data.settings.rti;
  if (rate < tier3) return 3;
  if (rate < tier2) return 2;
  return 1;
}

function hasActiveIntervention(sid) {
  return data.interventions.some((iv) => iv.studentId === sid && iv.status === 'active');
}

function renderRti() {
  const { tier2, tier3 } = data.settings.rti;
  $('rtiDesc3').textContent = `${tier3}%未満`;
  $('rtiDesc2').textContent = `${tier3}〜${tier2 - 1}%`;
  $('rtiDesc1').textContent = `${tier2}%以上`;

  const students = studentsOf(ui.rtiClass);
  const buckets = { 1: [], 2: [], 3: [] };
  let noData = 0;
  for (const s of students) {
    const { rate, delta, comparison } = rtiRateFor(s.id);
    const tier = rtiTierOf(rate);
    if (tier == null) { noData++; continue; }
    buckets[tier].push({ s, rate, delta, comparison });
  }
  // 低い順（支援優先度が高い順）に並べる
  for (const k of [1, 2, 3]) buckets[k].sort((a, b) => a.rate - b.rate);

  for (const tier of [1, 2, 3]) {
    const list = buckets[tier];
    $('rtiCount' + tier).textContent = `${list.length}名`;
    $('rtiCards' + tier).innerHTML = list.map(({ s, rate, delta, comparison }) => {
      const deltaHtml = delta == null ? ''
        : delta >= 3 ? `<span class="rti-delta up">▲${round1(delta)}</span>`
        : delta <= -3 ? `<span class="rti-delta down">▼${round1(Math.abs(delta))}</span>`
        : `<span class="rti-delta flat">→</span>`;
      const ivBadge = hasActiveIntervention(s.id) ? '<span class="rti-iv-badge" title="支援実施中">支援中</span>' : '';
      return `<button class="rti-card" data-sid="${esc(s.id)}">
        <span class="rti-card-name">${esc(s.name)}</span>
        <span class="rti-card-class">${esc(s.className || '')}</span>
        <span class="rti-card-rate">${round1(rate)}%</span>
        ${deltaHtml}${delta == null ? '' : `<span class="card-note">${esc(comparison)}との得点率差（ポイント）</span>`}${ivBadge}
      </button>`;
    }).join('') || '<div class="rti-empty">該当なし</div>';
  }
  const explain = document.querySelector('.rti-explain');
  if (explain) {
    let nd = explain.querySelector('.rti-nodata-note');
    if (!nd) { nd = document.createElement('span'); nd.className = 'rti-nodata-note'; explain.appendChild(nd); }
    nd.textContent = noData ? `／ データ未入力で判定できない生徒：${noData}名` : '';
  }

  renderRtiLog();
  renderRtiProgress();
}

/* ---- 支援記録 ---- */
function openIvDialog(sid, context = {}) {
  const s = data.students.find((x) => x.id === sid);
  if (!s) return;
  $('ivDialogTitle').textContent = `支援の記録：${s.name}`;
  $('ivTitle').value = '';
  $('ivNote').value = '';
  $('ivStart').value = localDateString();
  const subjects = subjectList();
  $('ivSubject').innerHTML = `<option value="all">全教科</option>` +
    subjects.map((x) => `<option value="${esc(x)}">${esc(x)}</option>`).join('');
  const subject = context.subject ?? ui.rtiSubject;
  $('ivSubject').value = subject === 'all' || subjects.includes(subject) ? subject : 'all';
  fillKindSelect('ivKind', context.kind ?? ui.rtiKind ?? 'all', true);
  $('ivForm').dataset.sid = sid;
  $('ivForm').dataset.dataToken = String(activeDataToken);
  refreshIvSummary();
  $('ivDialog').showModal();
}

function refreshIvSummary() {
  const student = data.students.find(s => s.id === $('ivForm').dataset.sid);
  if (!student) return;
  const { rate } = rtiRateFor(student.id, $('ivSubject').value, 'latest', $('ivKind').value);
  const number = student.number == null || student.number === '' ? '' : '・' + student.number + '番';
  $('ivStudentSummary').textContent = `${student.name}（${student.className || 'クラス未設定'}${number}） ／ 開始時の水準：${rate == null ? 'データなし' : round1(rate) + '%'} ／ ${TEST_KINDS[$('ivKind').value] || '全種類'}`;
}

function refreshInterventionViews(message = '') {
  if (ui.tab === 'trend') {
    renderTrendSupport();
    $('trendSupportStatus').textContent = message;
  } else if (ui.tab === 'rti') renderRti();
}

function submitIvDialog(e) {
  e.preventDefault();
  const sid = $('ivForm').dataset.sid;
  if ($('ivForm').dataset.dataToken !== String(activeDataToken) || !data.students.some(s => s.id === sid)) {
    alert('開いているデータが変わりました。記録先の生徒を選び直してください。');
    $('ivDialog').close();
    return;
  }
  const subject = $('ivSubject').value;
  const kind = $('ivKind').value;
  const title = $('ivTitle').value.trim();
  const startDate = $('ivStart').value;
  if (!title || !startDate || normalizeDateValue(startDate) !== startDate) {
    alert('支援の内容と、実在する開始日を入力してください。');
    return;
  }
  if ((subject !== 'all' && !subjectList().includes(subject)) || (kind !== 'all' && !Object.hasOwn(TEST_KINDS, kind))) {
    alert('対象教科・テスト種類を選び直してください。');
    return;
  }
  const { rate } = rtiRateFor(sid, subject, 'latest', kind);
  const idBase = 'iv' + Date.now();
  let id = idBase, suffix = 1;
  while (data.interventions.some(iv => iv.id === id)) id = idBase + '-' + suffix++;
  const iv = {
    id,
    studentId: sid,
    title,
    subject,
    kind,
    startDate,
    note: $('ivNote').value.trim(),
    baseline: rate != null ? round1(rate) : null, // 開始時の水準（効果確認の基準線）
    status: 'active',
    createdAt: localDateString(),
  };
  data.interventions.push(iv);
  ui.rtiSelectedIv = iv.id;
  markDirty();
  $('ivDialog').close();
  refreshInterventionViews('支援を記録しました。右上の「保存」でJSONへ保存してください。');
  if (ui.tab === 'trend') $('trendAddSupport').focus({ preventScroll: true });
}

function handleInterventionClick(e) {
  const done = e.target.closest('.iv-done-btn');
  const reopen = e.target.closest('.iv-reopen-btn');
  const del = e.target.closest('.iv-del-btn');
  const progress = e.target.closest('.iv-progress-btn');
  const action = done || reopen || del || progress;
  if (action) {
    const iv = data.interventions.find(x => x.id === action.dataset.iv);
    if (!iv) return;
    if (e.currentTarget.id === 'trendSupportRecords' && (ui.trendSelected.size !== 1 || !ui.trendSelected.has(iv.studentId))) return;
    if (progress) {
      ui.rtiSelectedIv = iv.id;
      document.querySelector('.tab-btn[data-tab="rti"]').click();
      $('rtiProgressTitle').focus();
      return;
    }
    if (del) {
      if (!requireAdmin() || !confirm(`支援記録「${iv.title}」を削除しますか？`)) return;
      data.interventions = data.interventions.filter(x => x.id !== iv.id);
      if (ui.rtiSelectedIv === iv.id) ui.rtiSelectedIv = null;
    } else if (done) { iv.status = 'done'; iv.endDate = localDateString(); }
    else { iv.status = 'active'; delete iv.endDate; }
    markDirty();
    refreshInterventionViews(del ? '支援記録を削除しました。' : done ? '支援を完了にしました。' : '支援を再開しました。');
    if (ui.tab === 'trend') $('trendAddSupport').focus({ preventScroll: true });
    return;
  }
  const row = e.target.closest('.iv-row');
  if (row) { ui.rtiSelectedIv = row.dataset.iv; renderRti(); resizeCharts(); }
}

function renderRtiLog() {
  const wrap = $('rtiLogWrap');
  const ivs = sortedInterventions();
  if (!ivs.length) {
    wrap.innerHTML = '<div class="table-empty">支援の記録はまだありません。上の生徒カードをクリックして追加します。</div>';
    return;
  }
  let html = '<table class="score-table iv-table"><thead><tr>' +
    '<th>状態</th><th style="text-align:left">生徒</th><th>クラス</th><th style="text-align:left">支援内容</th>' +
    '<th>教科</th><th>開始日</th><th>開始時</th><th></th></tr></thead><tbody>';
  for (const iv of ivs) {
    const s = data.students.find((x) => x.id === iv.studentId);
    if (!s) continue;
    const selected = ui.rtiSelectedIv === iv.id;
    html += `<tr class="iv-row ${selected ? 'is-selected' : ''} ${iv.status === 'done' ? 'is-done' : ''}" data-iv="${esc(iv.id)}">
      <td>${iv.status === 'active' ? '<span class="iv-status active">実施中</span>' : '<span class="iv-status done">完了</span>'}</td>
      <td class="cell-name">${esc(s.name)}</td>
      <td class="cell-class">${esc(s.className || '')}</td>
      <td style="text-align:left">${esc(iv.title)}${iv.note ? `<div class="iv-note">${esc(iv.note)}</div>` : ''}</td>
      <td>${esc(iv.subject === 'all' ? '全教科' : iv.subject)}</td>
      <td>${esc(iv.startDate || '')}</td>
      <td>${iv.baseline != null ? esc(iv.baseline) + '%' : '—'}</td>
      <td class="iv-actions">
        ${iv.status === 'active'
          ? `<button class="btn btn-ghost btn-sm iv-done-btn" data-iv="${esc(iv.id)}">完了にする</button>`
          : `<button class="btn btn-ghost btn-sm iv-reopen-btn" data-iv="${esc(iv.id)}">再開</button>`}
        <button class="btn btn-danger-ghost btn-sm admin-only iv-del-btn" data-iv="${esc(iv.id)}">削除</button>
      </td>
    </tr>`;
  }
  html += '</tbody></table>';
  wrap.innerHTML = html;
}

function renderRtiProgress() {
  const card = $('rtiProgressCard');
  const iv = data.interventions.find((x) => x.id === ui.rtiSelectedIv);
  if (!iv) { card.hidden = true; return; }
  const s = data.students.find((x) => x.id === iv.studentId);
  if (!s) { card.hidden = true; return; }
  card.hidden = false;
  $('rtiProgressTitle').textContent =
    `${s.name}さんの推移（${iv.subject === 'all' ? '全教科' : iv.subject}・${iv.kind && iv.kind !== 'all' ? TEST_KINDS[iv.kind] : '全種類'}）— 支援「${iv.title}」開始 ${iv.startDate || ''}`;

  // テスト回ごとの系列（全教科なら同じ回の教科平均）。テストは独立なので回単位で並べる
  const stuSeries = termSeriesFor(s.id, iv.subject, iv.kind || 'all');
  let labels = stuSeries.labels;
  let rates = stuSeries.rates.map((v) => (v != null ? round1(v) : null));
  // クラス平均（各生徒の回ごとの値を平均）
  const scope = s.className ? data.students.filter((x) => x.className === s.className) : data.students;
  let scopeSeries = scope.map((x) => termSeriesFor(x.id, iv.subject, iv.kind || 'all').rates);
  let avg = labels.map((_, i) => {
    const vals = scopeSeries.map((r) => r[i]).filter((v) => v != null);
    return vals.length ? round1(mean(vals)) : null;
  });
  // 本人・クラスともデータがない回は表示しない（下級生には未実施の回があるため）
  const used = labels.map((_, i) => rates[i] != null || avg[i] != null);
  if (used.some((u) => !u)) {
    labels = labels.filter((_, i) => used[i]);
    rates = rates.filter((_, i) => used[i]);
    avg = avg.filter((_, i) => used[i]);
    // 効果量のクラス分布も、表示系列と同じ回の添字を保つ
    scopeSeries = scopeSeries.map((series) => series.filter((_, i) => used[i]));
  }

  // 支援の効果量：開始時からの変化を「クラスのばらつき」を物差しに標準化（個人版の目安）
  let esNote = '';
  const lastIdx = rates.reduce((acc, v, i) => (v != null ? i : acc), -1);
  if (iv.baseline != null && lastIdx >= 0) {
    const latest = rates[lastIdx];
    // クラスのばらつき＝同じ回のクラス各生徒の値から
    const clsRates = scopeSeries.map((r) => r[lastIdx]).filter((v) => v != null);
    if (clsRates.length >= 3) {
      const sd = sampleSd(clsRates);
      if (sd > 0) {
        const dval = (latest - iv.baseline) / sd;
        esNote = `開始時 ${esc(iv.baseline)}% → 直近 ${round1(latest)}%（${latest >= iv.baseline ? '+' : ''}${round1(latest - iv.baseline)}pt）。` +
          `現在のクラスのばらつきを物差しにした標準化変化量は <strong>${esFmt(dval)}</strong>（個人の変化を見る参考値）` +
          `<span class="es-link">効果量とは？</span>`;
      }
    }
  }
  $('rtiEsNote').innerHTML = esNote;
  $('rtiEsNote').hidden = !esNote;

  const { tier2, tier3 } = data.settings.rti;
  const markLines = [
    { yAxis: tier2, lineStyle: { color: '#d9a10a' }, label: { formatter: `Tier2 ${tier2}%`, fontSize: 10 } },
    { yAxis: tier3, lineStyle: { color: '#c0392b' }, label: { formatter: `Tier3 ${tier3}%`, fontSize: 10 } },
  ];
  if (iv.baseline != null) {
    markLines.push({ yAxis: iv.baseline, lineStyle: { color: '#7c4a9c', type: 'dotted', width: 2 }, label: { formatter: `開始時 ${iv.baseline}%`, fontSize: 10 } });
  }

  chart('rtiProgressChart').setOption({
    grid: { ...BASE_GRID, top: 50, right: 90 },
    tooltip: { trigger: 'axis', valueFormatter: (v) => (v == null ? '—' : v + '%') },
    legend: { top: 0 },
    xAxis: { type: 'category', data: labels, boundaryGap: false, axisLabel: { rotate: labels.length > 5 ? 25 : 0, fontSize: 11 } },
    yAxis: { type: 'value', max: 100, min: 0, name: '得点率%' },
    series: [
      {
        name: s.name, type: 'line', symbol: 'circle', symbolSize: 9, connectNulls: true,
        data: rates, itemStyle: { color: PALETTE[0] }, lineStyle: { width: 3 },
        markLine: { silent: true, symbol: 'none', data: markLines },
      },
      {
        name: 'クラス平均', type: 'line', symbol: 'none', connectNulls: true,
        lineStyle: { type: 'dashed', color: AVG_COLOR }, itemStyle: { color: AVG_COLOR }, data: avg,
      },
    ],
  }, true);
}

/* ========== 名簿管理 ========== */
function nextStudentId() {
  let id;
  do {
    id = typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? 's-' + crypto.randomUUID()
      : `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  } while (data.students.some((s) => s.id === id));
  return id;
}

function studentHasScores(sid) {
  return data.scores.some((sc) => sc.studentId === sid) ||
    data.metrics.some((m) => m.values && m.values[sid] != null) ||
    data.interventions.some((iv) => iv.studentId === sid);
}

function removeStudentData(sid) {
  ui.trendSelected.delete(sid);
  data.students = data.students.filter((s) => s.id !== sid);
  data.scores = data.scores.filter((sc) => sc.studentId !== sid);
  for (const m of data.metrics) if (m.values) delete m.values[sid];
  data.interventions = data.interventions.filter((iv) => iv.studentId !== sid);
}

function openRosterDialog() {
  if (!requireAdmin()) return;
  switchRosterPane('edit');
  clearReassignPreview();
  fillReassignScope();
  $('reassignDate').value = localDateString();
  renderRosterTable();
  $('rosterDialog').showModal();
}

function switchRosterPane(name) {
  for (const b of document.querySelectorAll('.rtab')) b.classList.toggle('is-active', b.dataset.rtab === name);
  for (const p of document.querySelectorAll('.rpane')) p.classList.toggle('is-active', p.id === 'rpane-' + name);
}

// クラスの変遷（過去→現在）を文字列で返す。履歴が無ければ空文字
function classTrail(s) {
  const hist = Array.isArray(s.classHistory) ? s.classHistory : [];
  if (!hist.length) return '';
  const past = hist.map((h) => h.className || '（空）');
  return [...past, `${s.className || '（空）'}（現在）`].join(' → ');
}

function renderRosterTable() {
  const students = sortedStudents();
  $('rosterCount').textContent = `${students.length}名`;
  let html = '<table class="roster-table"><thead><tr>' +
    '<th style="width:56px">番号</th><th>氏名</th><th style="width:84px">クラス</th>' +
    '<th>クラス履歴</th><th style="width:32px"></th>' +
    '</tr></thead><tbody>';
  for (const s of students) {
    const trail = classTrail(s);
    html += `<tr data-sid="${esc(s.id)}">
      <td><input class="col-num" type="number" data-field="number" value="${esc(s.number != null ? s.number : '')}"></td>
      <td><input type="text" data-field="name" value="${esc(s.name)}"></td>
      <td><input type="text" data-field="className" value="${esc(s.className || '')}"></td>
      <td class="roster-history">${trail ? esc(trail) : '<span class="rh-none">—</span>'}</td>
      <td><button class="row-del" title="削除（転出）">✕</button></td>
    </tr>`;
  }
  html += '</tbody></table>';
  if (!students.length) html = '<div class="table-empty">生徒がいません。</div>';
  $('rosterTableWrap').innerHTML = html;
  updateReassignUndo();
}

function handleRosterEdit(input) {
  const sid = input.closest('tr').dataset.sid;
  const s = data.students.find((x) => x.id === sid);
  if (!s) return;
  const field = input.dataset.field;
  let val = input.value.trim();
  if (field === 'number') val = val === '' ? '' : (parseInt(val, 10) || '');
  if (String(s[field] ?? '') === String(val)) return;
  invalidateReassignRoster();
  s[field] = val;
  markDirty();
}

function handleRosterDelete(sid) {
  const s = data.students.find((x) => x.id === sid);
  if (!s) return;
  const warn = studentHasScores(sid)
    ? `${s.name} さんには成績・指標・支援記録のいずれかがあります。削除すると一緒に消えます。\n本当に削除しますか？`
    : `${s.name} さんを名簿から削除しますか？`;
  if (!confirm(warn)) return;
  invalidateReassignRoster();
  removeStudentData(sid);
  if (ui.rtiSelectedIv && !data.interventions.some((iv) => iv.id === ui.rtiSelectedIv)) ui.rtiSelectedIv = null;
  rebuildIndex();
  markDirty();
  renderRosterTable();
  renderAll();
}

function addRosterStudent() {
  invalidateReassignRoster();
  const id = nextStudentId();
  data.students.push({ id, name: '（新入生）', className: '', number: '' });
  markDirty();
  renderRosterTable();
  // 追加した行の氏名欄へフォーカス
  const row = $('rosterTableWrap').querySelector(`tr[data-sid="${CSS.escape(id)}"]`);
  if (row) {
    const nameInput = row.querySelector('[data-field="name"]');
    nameInput.focus();
    nameInput.select();
  }
}

/* ---- クラス替え一括取込 ---- */
let reassignPlan = null;
let reassignUndo = null;
let reassignBackupText = null;
let reassignImportSerial = 0;

function clearReassignPreview() {
  reassignImportSerial++;
  reassignPlan = null; reassignBackupText = null;
  for (const id of ['reassignPreview', 'reassignCommit']) if ($(id)) $(id).hidden = true;
  if ($('reassignApplyBtn')) $('reassignApplyBtn').disabled = true;
  if ($('reassignBackupConfirmed')) { $('reassignBackupConfirmed').checked = false; $('reassignBackupConfirmed').disabled = true; }
}

function updateReassignUndo() {
  if (reassignUndo && (reassignUndo.token !== activeDataToken || reassignUndo.after !== JSON.stringify(data.students))) reassignUndo = null;
  if ($('reassignUndoBtn')) $('reassignUndoBtn').disabled = !reassignUndo;
}

function invalidateReassignRoster() {
  clearReassignPreview(); reassignUndo = null; updateReassignUndo();
}

function fillReassignScope() {
  const select = $('reassignScope'), previous = select.value;
  const options = [['all', '', '名簿全員']];
  for (const grade of [1, 2, 3]) {
    if (data.students.some(s => window.GD_IMPORT.splitClassName(s.className).grade === String(grade))) options.push(['grade', String(grade), `${grade}年生`]);
  }
  for (const klass of classList()) options.push(['class', klass, klass]);
  select.innerHTML = options.map(([type, value, label]) => `<option value="${esc(JSON.stringify([type, value]))}">${esc(label)}</option>`).join('');
  if ([...select.options].some(o => o.value === previous)) select.value = previous;
}

function reassignConfig() {
  const [sourceType, sourceValue] = JSON.parse($('reassignScope').value);
  return { sourceType, sourceValue, grade: Number($('reassignGrade').value), naming: $('reassignNaming').value,
    count: Number($('reassignCount').value), mode: $('reassignMode').value, kind: $('reassignKind').value, date: $('reassignDate').value };
}

async function issueReassignTemplate() {
  if (!requireAdmin()) return;
  clearReassignPreview();
  try {
    const errors = validateDataset(data);
    if (errors.length) throw new Error('現在のデータを修正してから発行してください。\n' + errors.join('\n'));
    const wb = window.GD_EXCEL.reassignTemplate(XLSX, { ...data, students: sortedStudents() }, reassignConfig());
    await window.GD_EXCEL.download(wb, 'クラス替え入力用.xlsx');
  } catch (e) { alert('クラス替え用Excelを発行できませんでした。\n' + e.message); }
}

function showReassignErrors(errors) {
  const el = $('reassignPreview');
  el.innerHTML = '<p class="pv-warn">変更は反映していません。Excelを修正するか、最新の名簿から発行し直してください。</p><ul>' +
    errors.map(message => `<li>${esc(message)}</li>`).join('') + '</ul>';
  el.hidden = false;
}

async function importReassignWorkbook(file) {
  if (!requireAdmin()) return;
  clearReassignPreview();
  const serial = reassignImportSerial, token = activeDataToken, before = JSON.stringify(data.students);
  try {
    const wb = await window.GD_IMPORT.readWorkbook(file, XLSX);
    if (serial !== reassignImportSerial) return;
    if (token !== activeDataToken || before !== JSON.stringify(data.students)) { showReassignErrors(['読み込み中に名簿が変わりました。現在のJSONからExcelを発行し直してください。']); return; }
    const plan = window.GD_ROSTER.planWorkbook(wb, XLSX, data, localDateString());
    if (plan.errors.length) { showReassignErrors(plan.errors); return; }
    const c = plan.config;
    $('reassignScope').value = JSON.stringify([c.sourceType, c.sourceValue]);
    $('reassignGrade').value = String(c.grade); $('reassignNaming').value = c.naming; $('reassignCount').value = String(c.count);
    $('reassignCount').max = c.naming === 'letters' ? '26' : '50';
    $('reassignMode').value = c.mode; $('reassignKind').value = c.kind; $('reassignDate').value = c.date;
    const rows = plan.changes.map(s => `<tr><td>${esc(s.name)}</td><td>${esc(s.fromClass || '未設定')}・${esc(s.fromNumber || '未設定')}番</td><td>${esc(s.className)}・${esc(s.number)}番</td></tr>`).join('');
    const el = $('reassignPreview');
    el.innerHTML = `<p><strong>変更 ${plan.changes.length}名</strong> ／ 変更なし ${plan.unchanged}名 ／ 対象 ${plan.targetCount}名<br>` +
      `${c.kind === 'move' ? '所属変更・旧所属を履歴に記録' : '入力ミスの訂正・履歴は増やしません'} ／ 変更日 ${esc(c.date)}</p>` +
      (rows ? '<div class="table-wrap"><table><thead><tr><th>氏名</th><th>変更前</th><th>変更後</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<p>反映する変更はありません。</p>');
    el.hidden = false;
    if (plan.changes.length) { reassignPlan = { ...plan, before, token }; $('reassignCommit').hidden = false; }
  } catch (e) {
    if (serial === reassignImportSerial && token === activeDataToken) showReassignErrors([e.message]);
  }
}

function saveReassignBackup() {
  if (!requireAdmin() || !reassignPlan) return;
  if (reassignPlan.token !== activeDataToken || reassignPlan.before !== JSON.stringify(data.students)) { clearReassignPreview(); showReassignErrors(['名簿が変更されています。Excelを発行し直してください。']); return; }
  reassignBackupText = null;
  $('reassignBackupConfirmed').checked = false; $('reassignBackupConfirmed').disabled = true;
  $('reassignApplyBtn').disabled = true;
  try {
    const errors = validateDataset(data);
    if (errors.length) { alert('現在のデータを修正してから控えを保存してください。\n' + errors.join('\n')); return; }
    const text = JSON.stringify(data, null, 2);
    downloadBackupJson(text);
    reassignBackupText = text;
    $('reassignBackupConfirmed').checked = false; $('reassignBackupConfirmed').disabled = false;
    $('reassignApplyBtn').disabled = true;
  } catch { alert('控えJSONをダウンロードできませんでした。もう一度お試しください。変更は反映していません。'); }
}

function applyReassign() {
  if (!requireAdmin() || !reassignPlan) return;
  if (reassignPlan.token !== activeDataToken || reassignPlan.before !== JSON.stringify(data.students)) { clearReassignPreview(); showReassignErrors(['名簿が変わっています。変更は反映していません。Excelを発行し直してください。']); return; }
  if (!$('reassignBackupConfirmed').checked || reassignBackupText !== JSON.stringify(data, null, 2)) { $('reassignApplyBtn').disabled = true; alert('反映前の最新JSONの控えを保存し、保存先を確認してください。'); return; }
  const next = window.GD_ROSTER.changedStudents(data.students, reassignPlan);
  const errors = validateDataset({ ...data, students: next });
  if (errors.length) { showReassignErrors(errors); return; }
  if (!confirm(`確認した ${reassignPlan.changes.length}名の所属・番号を反映しますか？\n点数・指標・支援記録は引き継がれます。`)) return;
  reassignUndo = { before: JSON.parse(reassignPlan.before), after: JSON.stringify(next), token: activeDataToken };
  data.students = next;
  markDirty();
  clearReassignPreview();
  fillReassignScope();
  switchRosterPane('edit');
  renderRosterTable();
  renderAll();
  alert('所属の変更を反映しました。内容を確認してJSONを保存してください。通常のクラス別集計は現在の所属で行います。');
}

function undoReassign() {
  if (!requireAdmin()) return;
  updateReassignUndo();
  if (!reassignUndo) { alert('その後に名簿を編集したか、JSONを開き直したため取り消せません。必要なら控えJSONから戻してください。'); return; }
  if (!confirm('直前の一括変更を取り消して、所属・番号・所属履歴を反映前に戻しますか？\nその後に入力した点数・支援記録は保持します。')) return;
  data.students = reassignUndo.before;
  reassignUndo = null; clearReassignPreview(); markDirty();
  fillReassignScope(); renderRosterTable(); renderAll();
  alert('直前の一括変更を取り消しました。必要に応じてJSONを保存してください。');
}

/* ========== バックアップ（日付つき控えのダウンロード） ========== */
function backupJson() {
  if (!data) return;
  downloadBackupJson(JSON.stringify(data, null, 2));
}

function downloadBackupJson(text) {
  const now = new Date();
  const p = (n) => String(n).padStart(2, '0');
  const stamp = `${now.getFullYear()}${p(now.getMonth() + 1)}${p(now.getDate())}-${p(now.getHours())}${p(now.getMinutes())}${p(now.getSeconds())}-${String(now.getMilliseconds()).padStart(3, '0')}`;
  const base = (fileName || 'seiseki-data.json').replace(/\.json$/i, '');
  const blob = new Blob([text], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${base}_backup_${stamp}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 30000);
}

/* ========== 面談カルテ印刷 ========== */
// 画面上のチャートを、固定サイズ・アニメ無効でクリーンに画像化する
function chartImageFrom(domId, width, height) {
  if (typeof echarts === 'undefined') return '';
  const live = echarts.getInstanceByDom($(domId));
  if (!live) return '';
  const opt = live.getOption();
  opt.animation = false;
  const div = document.createElement('div');
  div.style.cssText = `position:absolute;left:-10000px;top:0;width:${width}px;height:${height}px;`;
  document.body.appendChild(div);
  const tmp = echarts.init(div, 'gd');
  tmp.setOption(opt);
  const url = tmp.getDataURL({ pixelRatio: 2, backgroundColor: '#fff' });
  tmp.dispose();
  div.remove();
  return url;
}

const defaultKarteOptions = { basic: true, history: true, records: true, score: true, rate: true, average: true, trend: true, domain: true, memo: true };
let karteOptions = { ...defaultKarteOptions };

function buildKarteHtml(selected = defaultKarteOptions) {
  if (!data || ui.trendSelected.size !== 1) return '';
  const student = data.students.find(s => s.id === [...ui.trendSelected][0]);
  if (!student) return '';
  const opts = { ...defaultKarteOptions, ...selected };
  if (!['basic', 'history', 'records', 'trend', 'domain', 'memo'].some(key => opts[key])) return '';
  const sid = student.id;
  const columns = [{ label: 'テスト', cell: t => `${esc(termKeyOf(t))}（${esc(t.subject)}）` }];
  if (opts.score) columns.push({ label: '得点', cell: (t, r) => `${r.total} / ${t.maxScore}` });
  if (opts.rate) columns.push({ label: '得点率', cell: (t, r) => `${round1(r.total / t.maxScore * 100)}%` });
  if (opts.average) columns.push({ label: 'クラス平均', cell: t => {
    const scope = student.className ? data.students.filter(s => s.className === student.className) : data.students;
    const values = scope.map(s => getAttendedScore(s.id, t.id)).filter(r => r && r.total != null).map(r => r.total);
    return values.length ? round1(mean(values)) : '—';
  }});
  let records = '';
  if (opts.records) {
    const rows = data.tests.filter(t => testKindMatches(t, ui.trendKind) &&
      (!ui.trendSubject || ui.trendSubject === SUM_KEY || t.subject === ui.trendSubject)).flatMap(t => {
      const rec = getAttendedScore(sid, t.id);
      return !rec || rec.total == null ? [] : ['<tr>' + columns.map((col, i) => `<td${i === 0 ? ' class="k-name"' : ''}>${col.cell(t, rec)}</td>`).join('') + '</tr>'];
    });
    records = '<h2>テストの記録</h2><table><thead><tr>' + columns.map(col => `<th>${col.label}</th>`).join('') + '</tr></thead><tbody>' +
      (rows.join('') || `<tr><td colspan="${columns.length}">記録された成績がありません</td></tr>`) + '</tbody></table>';
  }
  const images = [];
  if (opts.trend) {
    const url = chartImageFrom('trendChart', 520, 340);
    if (url) images.push(`<img src="${url}" alt="得点推移">`);
  }
  if (opts.domain && !$('trendDomainCard').hidden) {
    const url = chartImageFrom('trendDomainChart', 520, 340);
    if (url) images.push(`<img src="${url}" alt="分野別推移">`);
  }
  const today = new Date();
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;
  return `<div class="karte"><div class="karte-head"><div class="karte-title">学習の記録（${esc(data.name || '')}）</div>
    <div class="karte-meta">${opts.basic ? `${esc(student.className || '')}　${esc(student.number ?? '')}番<br>氏名：${esc(student.name)}<br>` : ''}
    ${opts.history && classTrail(student) ? 'クラス履歴：' + esc(classTrail(student)) + '<br>' : ''}作成日：${dateStr}</div></div>
    ${records}${images.length ? '<h2>推移グラフ</h2><div class="karte-charts">' + images.join('') + '</div>' : ''}
    ${opts.memo ? '<h2>面談メモ</h2><div class="karte-comment"></div>' : ''}
    <p class="karte-note">※ このカルテは校内の個人情報の取り扱いルールに従って管理・廃棄してください。</p></div>`;
}

function renderKartePreview() {
  for (const input of $('karteOptions').querySelectorAll('[data-karte]')) {
    karteOptions[input.dataset.karte] = input.checked;
    if (['score', 'rate', 'average'].includes(input.dataset.karte)) input.disabled = !karteOptions.records;
  }
  const html = buildKarteHtml(karteOptions);
  $('kartePreview').innerHTML = html;
  $('kartePrintBtn').disabled = !html;
  $('karteStatus').textContent = html ? '' : '表示する項目を1つ以上選んでください。';
}

function openKarteDialog() {
  if (ui.trendSelected.size !== 1) return;
  for (const input of $('karteOptions').querySelectorAll('[data-karte]')) input.checked = karteOptions[input.dataset.karte];
  renderKartePreview();
  $('karteDialog').showModal();
}

function printKarte(options = defaultKarteOptions) {
  const html = buildKarteHtml(options);
  if (!html) return;
  $('printArea').innerHTML = html;
  const imgs = [...$('printArea').querySelectorAll('img')];
  const ready = imgs.map(img => img.complete && img.naturalWidth ? Promise.resolve() :
    img.decode ? img.decode().catch(() => {}) : new Promise(resolve => { img.onload = img.onerror = resolve; }));
  Promise.all(ready).then(() => window.print());
}

/* ========== 入力用Excelテンプレート発行 ========== */
function exportTemplate() {
  const test = testById(ui.inTest);
  if (!test) {
    alert('先にテストを選択（または追加）してください。');
    return;
  }
  if (typeof XLSX === 'undefined') {
    alert('Excel出力ライブラリの読み込みに失敗しました。ファイル一式がそろっているか確認してください。');
    return;
  }
  const students = studentsOf(ui.inClass);
  const qs = test.questions || [];
  const header = ['出席番号', '氏名', 'クラス'];
  if (qs.length) for (const q of qs) header.push(`${q.label}(${q.max})`);
  else header.push(`合計(${test.maxScore})`);
  header.push('生徒ID');

  const rows = [header];
  for (const s of students) {
    const rec = getScore(s.id, test.id);
    const row = [s.number != null ? s.number : '', s.name, s.className || ''];
    if (qs.length) {
      for (const q of qs) row.push(rec && rec.questions && rec.questions[q.key] != null ? rec.questions[q.key] : '');
    } else {
      row.push(rec && rec.total != null ? rec.total : '');
    }
    row.push(s.id);
    rows.push(row);
  }

  const ws = XLSX.utils.aoa_to_sheet(safeExcelRows(rows));
  ws['!cols'] = header.map((h, i) => ({ wch: i === 1 ? 14 : Math.max(8, h.length + 2) }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '点数入力');
  const cls = ui.inClass === 'all' ? '全クラス' : ui.inClass;
  const safe = `${test.name}_${cls}`.replace(/[\\/:*?"<>|]/g, '_');
  XLSX.writeFile(wb, `${safe}_入力用.xlsx`);
}

/* ========== V2: カイ二乗検定（クロス集計） ========== */
// 自由度ごとの臨界値（上段=5%水準、下段=1%水準）
const CHI2_CRIT = {
  1: [3.841, 6.635], 2: [5.991, 9.210], 3: [7.815, 11.345], 4: [9.488, 13.277],
  5: [11.070, 15.086], 6: [12.592, 16.812], 7: [14.067, 18.475], 8: [15.507, 20.090],
  9: [16.919, 21.666], 10: [18.307, 23.209], 11: [19.675, 24.725], 12: [21.026, 26.217],
};

// X=5段階アンケート × Y=テスト のとき、回答×成績帯のクロス表とχ²検定を表示
function renderChiSquare(points, x, y) {
  const card = $('corrChiCard');
  if (!x || !y || !x.isScale || !ui.corrY.startsWith('t:') || points.length < 10) {
    card.hidden = true;
    return;
  }
  const test = testById(ui.corrY.slice(2));
  if (!test) { card.hidden = true; return; }
  const { tier2, tier3 } = data.settings.rti;
  const bandOf = (total) => {
    const rate = total / test.maxScore * 100;
    return rate < tier3 ? 0 : rate < tier2 ? 1 : 2;
  };
  const bandLabels = [`低（${tier3}%未満）`, `中（${tier3}〜${tier2 - 1}%）`, `高（${tier2}%以上）`];

  const xVals = [...new Set(points.map((p) => p.x))].sort((a, b) => a - b);
  let table = xVals.map(() => [0, 0, 0]);
  for (const p of points) table[xVals.indexOf(p.x)][bandOf(p.y)]++;

  // 誰もいない成績帯の列は除いて計算
  const colKeep = [0, 1, 2].filter((c) => table.some((row) => row[c] > 0));
  table = table.map((row) => colKeep.map((c) => row[c]));
  const nRows = table.length, nCols = colKeep.length;
  if (nRows < 2 || nCols < 2) { card.hidden = true; return; }

  const n = points.length;
  const rowSum = table.map((r) => r.reduce((a, b) => a + b, 0));
  const colSum = colKeep.map((_, ci) => table.reduce((a, r) => a + r[ci], 0));
  let chi2 = 0, smallE = 0;
  for (let i = 0; i < nRows; i++) {
    for (let j = 0; j < nCols; j++) {
      const E = rowSum[i] * colSum[j] / n;
      if (E < 5) smallE++;
      if (E > 0) chi2 += (table[i][j] - E) ** 2 / E;
    }
  }
  const df = (nRows - 1) * (nCols - 1);
  const crit = CHI2_CRIT[df];
  let verdict, verdictClass;
  if (crit && chi2 >= crit[1]) { verdict = '関連あり（1%水準で有意）'; verdictClass = 'sig'; }
  else if (crit && chi2 >= crit[0]) { verdict = '関連あり（5%水準で有意）'; verdictClass = 'sig'; }
  else { verdict = '統計的に確かな関連は見られません'; verdictClass = 'ns'; }
  const V = Math.sqrt(chi2 / (n * Math.min(nRows - 1, nCols - 1)));
  const vLabel = V < 0.1 ? 'ごく弱い' : V < 0.3 ? '弱い' : V < 0.5 ? '中程度の' : '強い';

  let html = `<table class="score-table chi-table"><thead><tr><th>${esc(x.label)}</th>` +
    colKeep.map((c) => `<th>${bandLabels[c]}</th>`).join('') + '<th>計</th></tr></thead><tbody>';
  xVals.forEach((v, i) => {
    html += `<tr><td class="cell-name">${esc(v)}</td>` +
      table[i].map((c) => `<td>${c}</td>`).join('') +
      `<td class="cell-strong">${rowSum[i]}</td></tr>`;
  });
  html += `<tr><td class="cell-name">計</td>` +
    colSum.map((c) => `<td class="cell-strong">${c}</td>`).join('') +
    `<td class="cell-strong">${n}</td></tr></tbody></table>`;
  $('chiTableWrap').innerHTML = html;

  // 高評価群（4〜5）と低評価群（1〜2）の平均点差を効果量で
  let groupHtml = '';
  const hiG = points.filter((p) => p.x >= 4).map((p) => p.y);
  const loG = points.filter((p) => p.x <= 2).map((p) => p.y);
  if (hiG.length >= 3 && loG.length >= 3) {
    const m1 = mean(loG), m2 = mean(hiG);
    const dval = independentCohensD(loG, hiG);
    if (dval != null) {
      groupHtml = `<div class="chi-groups">「4〜5」と答えた ${hiG.length}名 と「1〜2」の ${loG.length}名 の平均点差：` +
        `<strong>${round1(m2 - m1)}点</strong>（効果量 d = ${esFmt(dval)}・${esLabel(dval)}）` +
        `<span class="es-link">効果量とは？</span></div>`;
    }
  }

  $('chiResult').innerHTML =
    `<div class="chi-verdict ${verdictClass}">${verdict}</div>` +
    `<div class="chi-stats">χ² = ${(Math.round(chi2 * 100) / 100).toFixed(2)}（自由度 ${df}）<br>` +
    `関連の強さ Cramér&#39;s V = ${(Math.round(V * 100) / 100).toFixed(2)}（${vLabel}関連）</div>` +
    groupHtml +
    `<div class="chi-note">成績帯はRTIしきい値（${tier3}% / ${tier2}%）で区切っています` +
    (smallE > nRows * nCols * 0.2 ? '<br>※ 人数の少ないマスが多いため、結果は参考程度に見てください' : '') + '</div>';
  card.hidden = false;
}

/* ========== V2: テンプレート発行・取込 ========== */
// 新規テスト取込テンプレート（名簿プリフィル済み）を発行
async function issueNewTestTemplate() {
  if (typeof XLSX === 'undefined' || !window.GD_EXCEL) { alert('Excel出力用のファイルが不足しています。配布ZIPを展開し直してください。'); return; }
  try {
    const wb = window.GD_EXCEL.testTemplate(XLSX, sortedStudents());
    await window.GD_EXCEL.download(wb, '新規テスト取込テンプレート.xlsx');
    alert('テスト用Excelをダウンロードしました。\n\n1) 「① テスト設定」の黄色い欄に教科・テスト名・実施日などを入力します。\n2) 「② 点数入力」の7行目に分野、8行目に評価の観点、9行目に配点、10行目に問題名、11行目以降に点数を入力します。1列に1つの点数を入力し、大問合計と内訳を両方入れないでください。満点は配点合計から自動計算します。\n3) 灰色のA〜E列は名簿です。変更せず、F列以降に点数を入力します。列を増やすときは直前の列全体をコピーして追加してください。\n4) 空欄は未入力、0は0点。欠席は1か所に「欠」、他の点数は空欄にします。\n5) 保存して「記入後に取込」で選びます。その後アプリでもJSONを保存してください。');
  } catch (error) {
    alert('Excelを発行できませんでした。配布ZIPを展開し直してからお試しください。\n' + error.message);
  }
}

// テンプレートからテストを取込
async function importTestTemplate(file) {
  const wb = await window.GD_IMPORT.readWorkbook(file, XLSX);
  const { rows } = window.GD_IMPORT.selectSheet(wb, XLSX, ['② 点数入力', '新規テスト']);
  const settingsNames = wb.SheetNames.filter(n => ['① テスト設定', 'テスト設定'].includes(n));
  if (settingsNames.length > 1) { alert('テスト設定のシートが複数あります。1枚にしてください。'); return; }
  if (wb.SheetNames.includes('② 点数入力') && !settingsNames.length) { alert('「① テスト設定」シートが見つかりません。シート名を戻すか、新しいテンプレートを発行してください。'); return; }
  const settingsRows = settingsNames.length ? XLSX.utils.sheet_to_json(wb.Sheets[settingsNames[0]], { header: 1, defval: '' }) : null;
  const layout = window.GD_IMPORT.testLayout(rows, settingsRows);
  if (layout.errors.length) { alert(layout.errors.join('\n')); return; }
  const { metadata, headerIdx, scoreStart, domainRow, perspectiveRow, maxRow, identityColumns } = layout;

  const name = String(metadata['テスト名'] || '').trim();
  const subject = String(metadata['教科'] || '').trim();
  if (!name || !subject) { alert('テスト名・教科が空欄です。「① テスト設定」のB8・B10へ入力してください（従来形式のExcelでは元の設定欄を使用します）。'); return; }
  if (data.tests.some((t) => t.name === name && t.subject === subject)) {
    if (!confirm(`「${name}（${subject}）」は既に存在します。別のテストとして追加しますか？`)) return;
  }

  const header = rows[headerIdx] || [];
  const qCols = [];
  const dataWidth = Math.max(header.length, rows[domainRow]?.length || 0, rows[maxRow]?.length || 0, perspectiveRow == null ? 0 : rows[perspectiveRow]?.length || 0, ...rows.slice(headerIdx + 1).map((r) => r.length));
  for (let c = scoreStart; c < dataWidth; c++) {
    const label = String(header[c] || '').trim();
    if (!label && (String(rows[maxRow]?.[c] ?? '').trim() || String(rows[domainRow]?.[c] ?? '').trim() || (perspectiveRow != null && String(rows[perspectiveRow]?.[c] ?? '').trim()) || rows.slice(headerIdx + 1).some((r) => String(r[c] ?? '').trim()))) { alert(`問題名が空欄の列に分野・評価の観点・配点・点数があります。${headerIdx + 1}行目の問題名を入力してください。`); return; }
    const max = Number(rows[maxRow] ? rows[maxRow][c] : 0);
    if (window.GD_IMPORT.isIdHeader(label)) continue;
    if (label && (!Number.isFinite(max) || max <= 0)) { alert(`問題「${label}」の配点は0より大きい数字で入力してください。`); return; }
    if (label) {
      const perspective = window.GD_IMPORT.parsePerspective(perspectiveRow == null ? '' : rows[perspectiveRow]?.[c]);
      if (perspective === null) { alert(`${perspectiveRow + 1}行目・${XLSX.utils.encode_col(c)}列の評価の観点は、知識・技能、思考・判断・表現、未設定から選んでください。取込は反映していません。`); return; }
      qCols.push({ c, label, max, domain: String(rows[domainRow] ? rows[domainRow][c] : '').trim(), perspective });
    }
  }
  if (!qCols.length) { alert(`問題の列が見つかりません。${headerIdx + 1}行目の問題名と${maxRow + 1}行目の配点を確認してください。`); return; }

  // 分野キー＝分野名（テスト間で同じ分野名なら同じ分野として推移がつながる）
  const domainNames = [...new Set(qCols.map((q) => q.domain).filter(Boolean))];
  const domains = domainNames.map((label) => ({
    key: label, label,
    max: qCols.filter((q) => q.domain === label).reduce((a, q) => a + q.max, 0),
  }));
  const questions = qCols.map((q, i) => ({
    key: 'q' + (i + 1), label: q.label, max: q.max,
    domain: q.domain || undefined, perspective: q.perspective || undefined,
  }));
  const declaredMax = Number(metadata['満点']);
  const questionMaxSum = qCols.reduce((a, q) => a + q.max, 0);
  if (!layout.automaticMax && String(metadata['満点'] ?? '').trim() && (!Number.isFinite(declaredMax) || declaredMax <= 0)) { alert('満点は0より大きい数字、または空欄にしてください。'); return; }
  const maxScore = !layout.automaticMax && declaredMax > 0 ? declaredMax : questionMaxSum;
  if (questionMaxSum > maxScore) {
    alert(`問題の配点合計（${questionMaxSum}点）がテストの満点（${maxScore}点）を超えています。Excelを修正してください。`);
    return;
  }
  const kind = window.GD_IMPORT.parseTestKind(metadata['テスト種類']);
  if (!kind) { alert('テスト種類は単元テスト・中間テスト・期末テスト・実力テスト・その他・未分類から選んでください。'); return; }
  const test = { id: 't' + Date.now(), name, subject, maxScore, domains, questions, kind, series: String(metadata['比較系列'] ?? '').trim() };
  const gradeText = String(metadata['実施学年'] ?? '').trim();
  if (gradeText && !/^[123]$/.test(gradeText)) { alert('実施学年は1〜3の整数、または空欄にしてください。'); return; }
  if (gradeText) test.gradeYear = Number(gradeText);
  const rawDate = metadata['実施日'];
  if (layout.automaticMax && String(rawDate ?? '').trim() === '') { alert('「① テスト設定」の実施日（B14）を入力してください。'); return; }
  const date = normalizeDateValue(rawDate);
  if (rawDate !== '' && rawDate != null) {
    if (!date) {
      alert('実施日は YYYY-MM-DD 形式（例：2026-09-26）で入力してください。');
      return;
    }
    test.date = date;
  }

  const resolved = window.GD_IMPORT.matchedRows(rows, headerIdx, data.students, qCols.map((q) => q.c), identityColumns);
  if (resolved.errors.length) { alert('取込は反映していません。Excelを修正してください。\n\n' + resolved.errors.slice(0, 8).join('\n')); return; }
  const invalidScores = [];
  const newScores = [];
  let absentCount = 0;
  for (const { row, student: stu, rowNumber } of resolved.matched) {
    const nm = rowNumber + '行目';
    const rec = { studentId: stu.id, testId: test.id, total: null, domains: {}, questions: {} };
    let any = false, isAbsent = false;
    qCols.forEach((qc, qi) => {
      const sv = String(row[qc.c] ?? '').trim();
      if (sv === '欠') { isAbsent = true; return; }
      if (sv === '') return;
      const parsed = parseBoundedNumber(sv, questions[qi].max);
      if (!parsed.valid) {
        invalidScores.push(`${nm}・${questions[qi].label}（${sv}／${questions[qi].max}点）`);
        return;
      }
      rec.questions[questions[qi].key] = parsed.value;
      any = true;
    });
    if (isAbsent && any) invalidScores.push(`${nm}：欠席と点数が同じ行にあります。欠席なら全点数を空欄にしてください。`);
    if (isAbsent) {
      rec.absent = true;
      absentCount++;
    } else if (any) {
      recalcScore(rec, test);
    }
    if (any || isAbsent) newScores.push(rec);
  }

  if (invalidScores.length) {
    alert(
      `数字以外・配点の範囲外・欠席との混在が ${invalidScores.length}件あります。取込は反映していません。Excelを修正してください。\n\n` +
      invalidScores.slice(0, 8).join('\n') + (invalidScores.length > 8 ? '\nほか' : '')
    );
    return;
  }

  const ok = confirm(
    `このテストを取り込みますか？\n\n` +
    `テスト名：${name}（${subject}・${maxScore}点満点${test.gradeYear ? `・${test.gradeYear}年時` : '・実施学年 未設定'}${test.date ? `・${test.date}` : ''}）\n` +
    `問題：${questions.length}問 ／ 分野：${domains.length}\n` +
    `点数を取り込む生徒：${newScores.length}名（うち欠席 ${absentCount}名）\n` +
    '空欄は未入力のままです。既存テストの点数は変更しません。');
  if (!ok) return;

  data.tests.push(test);
  data.scores.push(...newScores);
  rebuildIndex();
  ui.inTest = test.id;
  if (ui.inSubject !== 'all' && ui.inSubject !== subject) ui.inSubject = subject;
  markDirty();
  renderAll();
  alert('取込が完了しました。内容を確認して、右上の「保存」を押してください。');
}

// 指標取込テンプレート（テスト用と同じ書式・名簿入り）を発行
async function issueMetricTemplate() {
  if (typeof XLSX === 'undefined' || !window.GD_EXCEL) { alert('Excel出力用のファイルが不足しています。配布ZIPを展開し直してください。'); return; }
  try {
    const wb = window.GD_EXCEL.metricTemplate(XLSX, sortedStudents());
    await window.GD_EXCEL.download(wb, '指標取込テンプレート.xlsx');
    alert('指標用Excelをダウンロードしました。\n\n1) 「指標」シートの9行目・F列以降の黄色い見出しを、実際の指標名に書き換えます。\n2) 10行目以降の黄色い欄に回答を入力します。灰色のA〜E列は名簿です。変更しないでください。\n3) 項目を増やすときは直前の列全体をコピーして右へ追加します。完成イメージは「記入例」にあります。\n4) 未回答は空欄、実際の数値0は0です。値がすべて1〜5の整数なら「5段階」、それ以外は「数値」と自動判定します。\n5) Excelを保存して「記入後に取込」で選びます。取り込み後はアプリのJSONも保存してください。');
  } catch (error) {
    alert('Excelを発行できませんでした。配布ZIPを展開し直してからお試しください。\n' + error.message);
  }
}

// テンプレートから指標を取込（複数列対応）
async function importMetricTemplate(file) {
  const wb = await window.GD_IMPORT.readWorkbook(file, XLSX);
  const { rows } = window.GD_IMPORT.selectSheet(wb, XLSX, ['指標']);
  const { plans, errors } = window.GD_IMPORT.parseMetricRows(rows, data.students, data.metrics);
  if (errors.length) {
    alert('取込は反映していません。\n\n' + errors.slice(0, 8).join('\n'));
    return;
  }

  const lines = plans.map((p) => {
    const kind = p.isScale ? '5段階アンケート' : '数値';
    const why = p.existing ? '既存の指標に上書き（種類はそのまま）'
      : p.isScale ? '新規・すべて1〜5の整数のため'
      : '新規・1〜5の整数以外を含むため';
    return `・${p.label}\n    ${p.count}名分 → 「${kind}」として登録（${why}）` +
      (p.zeroBlocked ? '\n    ※ 0 が入っています。未回答を0にした場合は空欄に直すと5段階として登録できます' : '');
  });
  const ok = confirm(
    `次の内容で取り込みます。よろしいですか？\n\n${lines.join('\n\n')}\n\n` +
    '空欄は未回答のままとし、登録済みの値を消しません。' +
    `\n\n※「5段階アンケート」はカイ二乗検定・クロス集計が使えます。\n` +
    `　種類は取込後、指標名の横の表示で確認できます。`);
  if (!ok) return;

  for (const p of plans) {
    if (p.existing) {
      Object.assign(p.existing.values, p.values);
    } else {
      data.metrics.push({
        id: 'm' + Date.now() + Math.floor(Math.random() * 1000),
        label: p.label,
        type: p.isScale ? 'scale' : 'number',
        values: p.values,
      });
    }
  }
  markDirty();
  fillAxisSelects();
  fillMetricSelect();
  if (ui.tab === 'metrics') renderMetricsTab();
  alert('指標の取込が完了しました。内容を確認して、右上の「保存」を押してください。');
}

/* ========== 新規作成 ========== */
function submitNewDialog(e) {
  e.preventDefault();
  const name = $('nfName').value.trim();
  const lines = $('nfRoster').value.split('\n').map((l) => l.replace(/\r$/, '')).filter((l) => l.trim());
  const students = [], slots = new Set();
  for (let i = 0; i < lines.length; i++) {
    const [n, klass, num] = lines[i].split('\t').map((x) => (x || '').trim());
    if (!n || (num && (!/^\d+$/.test(num) || Number(num) < 1))) { alert(`${i + 1}行目：氏名と出席番号（1以上の整数）を確認してください。`); return; }
    const number = num ? Number(num) : '';
    const slot = klass && number !== '' ? klass + '#' + number : '';
    if (slot && slots.has(slot)) { alert(`${i + 1}行目：同じ組・番号が重複しています。変更は反映していません。`); return; }
    if (slot) slots.add(slot);
    students.push({ id: crypto.randomUUID(), name: n, className: klass || '', number });
  }
  if (!students.length) { alert('名簿を1名以上入力してください。'); return; }
  if (data && !confirm('現在のデータと分けて新しいデータを作成します。未保存の場合はキャンセルして保存してください。新規作成しますか？')) return;
  const fresh = { version: 2, name, students, tests: [], scores: [], metrics: [] };
  $('newDialog').close();
  applyJsonText(JSON.stringify(fresh), 'seiseki-data.json', null);
  markDirty();
}

/* ========== イベント結線 ========== */
function init() {
  // ファイル
  $('openBtn').onclick = openJson;
  $('openBtnEmpty').onclick = openJson;
  $('saveBtn').onclick = openSaveDialog;
  $('saveOverwriteBtn').onclick = () => saveJson('overwrite');
  $('saveAsBtn').onclick = () => saveJson('as');
  $('saveDownloadBtn').onclick = () => saveJson('download');
  $('downloadConfirmBtn').onclick = confirmDownloadedJson;
  $('saveCloseBtn').onclick = () => $('saveDialog').close();
  $('saveDialog').oncancel = event => { if (saving) event.preventDefault(); };
  $('newBtnEmpty').onclick = () => $('newDialog').showModal();
  $('fileInput').onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    file.text().then((text) => applyJsonText(text, file.name, null));
    e.target.value = '';
  };

  // タブ
  for (const btn of document.querySelectorAll('.tab-btn')) {
    btn.onclick = () => {
      ui.tab = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('is-active', b === btn));
      document.querySelectorAll('.tab-panel').forEach((p) =>
        p.classList.toggle('is-active', p.id === 'panel-' + ui.tab));
      renderCurrentTab();
    };
  }

  // セレクト
  $('ovClass').onchange = (e) => { ui.ovClass = e.target.value; renderOverview(); resizeCharts(); };
  $('ovSubject').onchange = (e) => { ui.ovSubject = e.target.value; fillScopedTestSelect('ovTest', 'ovSubject', 'ovTest'); renderOverview(); resizeCharts(); };
  $('ovTest').onchange = (e) => { ui.ovTest = e.target.value; renderOverview(); resizeCharts(); };
  $('inClass').onchange = (e) => { ui.inClass = e.target.value; renderInput(); };
  $('inTest').onchange = (e) => { ui.inTest = e.target.value; renderInput(); };
  $('inSubject').onchange = (e) => { ui.inSubject = e.target.value; fillScopedTestSelect('inTest', 'inSubject', 'inTest'); renderInput(); };
  $('anClass').onchange = (e) => { ui.anClass = e.target.value; renderAnalysis(); resizeCharts(); };
  $('anClassificationAxis').onchange = e => { ui.anAxis = e.target.value; renderAnalysis(); resizeCharts(); };
  $('anSubject').onchange = (e) => { ui.anSubject = e.target.value; fillScopedTestSelect('anTest', 'anSubject', 'anTest'); renderAnalysis(); resizeCharts(); };
  $('anTest').onchange = (e) => { ui.anTest = e.target.value; renderAnalysis(); resizeCharts(); };
  $('trendClass').onchange = (e) => { ui.trendClass = e.target.value; renderTrend(); resizeCharts(); };
  $('trendSubject').onchange = (e) => { ui.trendSubject = e.target.value; ui.trendCompareTest = ''; ui.trendCompareFrom = null; renderTrend(); resizeCharts(); };
  $('trendCompareTest').onchange = e => { ui.trendCompareTest = e.target.value; ui.trendCompareFrom = null; renderTrendComparison(); };
  $('trendCompareFrom').onchange = e => { ui.trendCompareFrom = e.target.value; renderTrendComparison(); };
  $('trendUseOverview').onclick = () => { useOverviewComparison(); renderTrend(); resizeCharts(); };

  // データ一覧
  $('listSubject').onchange = (e) => { ui.listSubject = e.target.value; ui.listSort = null; renderList(); };
  $('listClass').onchange = (e) => { ui.listClass = e.target.value; renderList(); };
  $('listGrade').onchange = (e) => {
    ui.listGrade = e.target.value;
    fillListClassSelect(); // クラスの選択肢を学年に合わせて絞る
    ui.listSort = null;
    renderList();
  };
  $('listTerm').onchange = (e) => { ui.listTerm = e.target.value; ui.listSort = null; renderList(); };
  $('listMode').onchange = (e) => { ui.listMode = e.target.value; renderList(); };
  $('listHeat').onchange = (e) => { ui.listHeat = e.target.checked; renderList(); };
  $('listPivot').oninput = (e) => {
    const v = parseInt(e.target.value, 10);
    ui.listPivot = isNaN(v) ? 60 : Math.max(0, Math.min(100, v));
    renderList();
  };
  $('listExportBtn').onclick = exportList;
  $('listTableWrap').addEventListener('click', (e) => {
    const th = e.target.closest('th[data-key]');
    if (th) handleListSort(th.dataset.key);
  });
  $('trendSearch').oninput = (e) => { ui.trendSearch = e.target.value; renderStudentList(); };
  $('trendClearBtn').onclick = () => { ui.trendSelected.clear(); renderTrend(); resizeCharts(); };

  // 生徒リスト（クリックで選択トグル）
  $('studentList').onclick = (e) => {
    const li = e.target.closest('li');
    if (!li) return;
    const sid = li.dataset.sid;
    if (ui.trendSelected.has(sid)) ui.trendSelected.delete(sid);
    else ui.trendSelected.add(sid);
    renderTrend();
    resizeCharts();
  };

  // 成績入力テーブル（委譲）
  $('scoreTableWrap').addEventListener('input', (e) => {
    if (e.target.classList.contains('cell-input')) handleCellInput(e.target);
  });
  $('scoreTableWrap').addEventListener('change', (e) => {
    if (e.target.classList.contains('absent-check')) handleAbsentToggle(e.target);
  });
  $('scoreTableWrap').addEventListener('keydown', handleCellKeydown);
  $('scoreTableWrap').addEventListener('paste', (e) => {
    if (e.target.classList.contains('cell-input')) handleCellPaste(e, e.target);
  });

  // 相関分析
  $('corrX').onchange = (e) => { ui.corrX = e.target.value; renderCorrelation(); resizeCharts(); };
  $('corrY').onchange = (e) => { ui.corrY = e.target.value; renderCorrelation(); resizeCharts(); };
  $('metClass').onchange = (e) => { ui.metClass = e.target.value; renderMetricsTab(); resizeCharts(); };
  $('metricSel').onchange = (e) => { ui.metricId = e.target.value; renderMetricTable(); };
  $('addMetricBtn').onclick = () => { $('mfLabel').value = ''; $('mfType').value = 'number'; $('metricDialog').showModal(); };
  $('deleteMetricBtn').onclick = deleteCurrentMetric;
  $('metricForm').onsubmit = submitMetricDialog;
  $('mfCancel').onclick = () => $('metricDialog').close();
  $('metricTableWrap').addEventListener('input', (e) => {
    if (e.target.classList.contains('metric-input')) handleMetricInput(e.target);
  });
  $('metricTableWrap').addEventListener('paste', (e) => {
    if (e.target.classList.contains('metric-input')) handleMetricPaste(e, e.target);
  });

  // 効果量の説明（「効果量とは？」「d=…」表示のクリックで開く）
  document.addEventListener('click', (e) => {
    if (e.target.closest('.es-link')) $('esHelpDialog').showModal();
  });
  $('esHelpClose').onclick = () => $('esHelpDialog').close();
  $('esHelpCloseTop').onclick = () => $('esHelpDialog').close();

  // 権限（管理者モード）
  $('roleBtn').onclick = () => {
    if (!data) return;
    if (isAdmin) { isAdmin = false; updateRoleUI(); renderCurrentTab(); return; }
    openAdminDialog();
  };
  $('adminForm').onsubmit = submitAdminDialog;
  $('adminCancel').onclick = () => $('adminDialog').close();
  $('settingsBtn').onclick = openSettingsDialog;
  $('settingsForm').onsubmit = submitSettingsDialog;
  $('settingsCancel').onclick = () => $('settingsDialog').close();

  // 支援（RTI）
  $('rtiSubject').onchange = (e) => { ui.rtiSubject = e.target.value; renderRti(); };
  $('rtiClass').onchange = (e) => { ui.rtiClass = e.target.value; renderRti(); };
  $('rtiBasis').onchange = (e) => { ui.rtiBasis = e.target.value; renderRti(); };
  $('rtiSettingsBtn').onclick = openSettingsDialog;
  document.querySelector('.rti-board').addEventListener('click', (e) => {
    const cardEl = e.target.closest('.rti-card');
    if (cardEl) openIvDialog(cardEl.dataset.sid);
  });
  $('ivForm').onsubmit = submitIvDialog;
  $('ivCancel').onclick = () => $('ivDialog').close();
  $('ivSubject').onchange = refreshIvSummary;
  $('ivKind').onchange = refreshIvSummary;
  $('trendAddSupport').onclick = () => {
    if (ui.trendSelected.size !== 1) return;
    openIvDialog([...ui.trendSelected][0], { subject: ui.trendSubject === SUM_KEY ? 'all' : ui.trendSubject, kind: ui.trendKind || 'all' });
  };
  $('rtiLogWrap').addEventListener('click', handleInterventionClick);
  $('trendSupportRecords').addEventListener('click', handleInterventionClick);

  // バックアップ・カルテ印刷
  $('backupBtn').onclick = backupJson;
  $('ovComparisonBtn').onclick = () => openComparisonDialog(ui.ovTest);
  $('anComparisonBtn').onclick = () => openComparisonDialog(ui.anTest);
  $('cfTest').onchange = loadComparisonForm;
  $('cfKind').onchange = refreshComparisonChoices;
  $('cfSeries').oninput = refreshComparisonChoices;
  $('cfCompare').onchange = refreshComparisonChoices;
  $('comparisonForm').onsubmit = submitComparisonForm;
  $('cfCloseBtn').onclick = () => $('comparisonDialog').close();
  $('trendKind').onchange = event => { ui.trendKind = event.target.value; ui.trendCompareTest = ''; ui.trendCompareFrom = null; renderTrend(); };
  $('rtiKind').onchange = event => { ui.rtiKind = event.target.value; renderRti(); };
  $('printKarteBtn').onclick = openKarteDialog;
  $('karteOptions').onchange = renderKartePreview;
  $('karteCloseBtn').onclick = () => $('karteDialog').close();
  $('kartePrintBtn').onclick = () => { $('karteDialog').close(); printKarte(karteOptions); };

  // 名簿管理
  $('rosterBtn').onclick = openRosterDialog;
  $('rosterCloseBtn').onclick = () => $('rosterDialog').close();
  $('rosterAddBtn').onclick = addRosterStudent;
  for (const b of document.querySelectorAll('.rtab')) b.onclick = () => switchRosterPane(b.dataset.rtab);
  $('rosterTableWrap').addEventListener('input', (e) => {
    if (e.target.dataset.field) handleRosterEdit(e.target);
  });
  $('rosterTableWrap').addEventListener('click', (e) => {
    const btn = e.target.closest('.row-del');
    if (btn) handleRosterDelete(btn.closest('tr').dataset.sid);
  });
  $('reassignTemplateBtn').onclick = issueReassignTemplate;
  $('reassignImportBtn').onclick = () => $('reassignXlsxInput').click();
  $('reassignXlsxInput').onchange = e => { const file = e.target.files[0]; e.target.value = ''; if (file) importReassignWorkbook(file); };
  for (const id of ['reassignScope', 'reassignGrade', 'reassignNaming', 'reassignCount', 'reassignMode', 'reassignKind', 'reassignDate']) {
    $(id).oninput = () => { clearReassignPreview(); $('reassignCount').max = $('reassignNaming').value === 'letters' ? '26' : '50'; };
  }
  $('reassignBackupBtn').onclick = saveReassignBackup;
  $('reassignBackupConfirmed').onchange = () => { $('reassignApplyBtn').disabled = !reassignPlan || !$('reassignBackupConfirmed').checked; };
  $('reassignApplyBtn').onclick = applyReassign;
  $('reassignUndoBtn').onclick = undoReassign;

  // 入力用Excel発行
  $('exportTemplateBtn').onclick = exportTemplate;

  // V2: テンプレート発行・取込
  $('newTestTplBtn').onclick = issueNewTestTemplate;
  $('importTestBtn').onclick = () => $('testXlsxInput').click();
  $('testXlsxInput').onchange = (e) => {
    const f = e.target.files[0];
    if (f) importTestTemplate(f).catch((err) => alert('読み込みに失敗しました: ' + err.message));
    e.target.value = '';
  };
  $('metricTplBtn').onclick = issueMetricTemplate;
  $('importMetricBtn').onclick = () => $('metricXlsxInput').click();
  $('metricXlsxInput').onchange = (e) => {
    const f = e.target.files[0];
    if (f) importMetricTemplate(f).catch((err) => alert('読み込みに失敗しました: ' + err.message));
    e.target.value = '';
  };

  // テスト追加・削除
  $('addTestBtn').onclick = openTestDialog;
  $('deleteTestBtn').onclick = deleteCurrentTest;
  $('testForm').onsubmit = submitTestDialog;
  $('tfCancel').onclick = () => $('testDialog').close();
  $('tfAddDomain').onclick = () => addDomainRow();
  $('tfCopyPrev').onclick = copyPrevStructure;
  $('tfAddQuestion').onclick = () => addQuestionRow();

  // 新規作成
  $('newForm').onsubmit = submitNewDialog;
  $('nfCancel').onclick = () => $('newDialog').close();

  // 貼り付けヘルプ
  $('pasteHelpBtn').onclick = () => $('pasteDialog').showModal();
  $('pasteCloseBtn').onclick = () => $('pasteDialog').close();

  document.documentElement.dataset.dashboardInitialized = 'true';
}

init();
